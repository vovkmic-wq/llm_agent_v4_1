# LLM Coding Agent V4.6 Strict-Schema Local-First ICS

Production coding agent для Windows/Linux/macOS с приоритетом локальной LM Studio
модели и контролируемым fallback в YandexGPT.

## Что нового в V4.6

- единый recursive strict-schema compiler для Executor/Planner/Reviewer/Safety/Reporter;
- все declared JSON fields required для strict provider; optional semantics через `null`;
- regression на live Yandex error `all fields must be required, 'reason' is optional`;
- `types-PyYAML` remediation после IAP и до LLM: install -> pip check -> mypy;
- NumPy `.pyi` syntax issue классифицируется как environment/toolchain problem;
- `types-numpy` запрещён;
- `environment.diagnose_mypy` показывает actual Python, mypy target, NumPy и stubs;
- environment-only blocker завершается kernel-ом без LLM;
- bare shell-команда в chat не выполняется скрытно;
- `[ESCALATE]` содержит причину provider/protocol fallback;
- `/doctor` показывает `strict_schema_compiler=v46`.

Полное ТЗ: `TECHNICAL_SPECIFICATION_V4_6.md`.

## Установка PowerShell

```powershell
cd C:\script\20260808-LLM_Agent_file\llm_agent_v4_6_production
C:\Python312\python.exe -m venv .venv
Set-ExecutionPolicy -Scope Process -ExecutionPolicy RemoteSigned
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip setuptools wheel
python -m pip install -r requirements.txt
python -m pip check
```

## .env

```dotenv
LMSTUDIO_BASE_URL=http://localhost:1234/v1
LMSTUDIO_MODEL=qwen2.5-coder-7b-instruct
LMSTUDIO_EMBEDDING_MODEL=text-embedding-nomic-embed-text-v1.5
LMSTUDIO_API_KEY=

YANDEX_API_KEY=...
YANDEX_FOLDER_ID=...

AGENT_ALLOW_CODE_EXECUTION=true
AGENT_ALLOW_RESEARCH=false
```

Yandex effective base URL по умолчанию: `https://ai.api.cloud.yandex.net/v1`.

## Запуск

```powershell
.\.venv\Scripts\Activate.ps1
python main.py
```

Проверка:

```text
/doctor
/project set ozon_market_analytics
/project show
/spec show
```

## Audit

Read-only:

```text
/task Проверь проект. Выполни compileall, pytest, ruff и mypy. Ничего не изменяй.
```

Writable:

```text
/task Проверь проект по ТЗ, исправляй подтверждённые ошибки и повторяй проверки до PASS либо доказанного blocker.
```

Если baseline mypy сообщает missing `types-PyYAML`, kernel V4.6 после IAP сам пытается
установить allow-listed stub. Ввод `python -m pip install ...` как обычного сообщения
чата не исполняется.

## Тесты

```powershell
python -m pytest -q
python -m compileall -q core providers main.py tests
```

Subprocess E2E запускаются отдельно по marker `subprocess`.

Live LLM tests остаются opt-in:

```powershell
$env:AGENT_RUN_LIVE_LLM_TESTS="true"
python -m pytest -q -m live_llm tests/test_v45_live_structured.py
```

Они требуют реального LM Studio/Yandex окружения и не входят в default release suite.
