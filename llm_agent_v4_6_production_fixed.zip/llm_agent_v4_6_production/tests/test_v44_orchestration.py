from __future__ import annotations

from pathlib import Path

import pytest

from core.agent import Agent
from core.config import settings
from core.execution import ExecutionManager
from core.failure_analyzer import analyze_test_output
from core.memory import MemoryManager
from core.progress_control import ProgressController
from core.protocol import ToolCall
from core.retrieval import LocalRetrievalManager
from core.workspace import WorkspaceManager
from providers.base import CompletionResult


class MinimalRouter:
    def __init__(self, responses: list[str] | None = None) -> None:
        self.responses = list(responses or [])
        self.calls: list[dict] = []

    def call(self, **kwargs):
        self.calls.append(kwargs)
        text = self.responses.pop(0) if self.responses else (
            '{"type":"final","status":"blocked",'
            '"content":"blocked","evidence":[]}'
        )
        return CompletionResult(text=text, raw_model_name=kwargs["model_id"])


def _agent(tmp_path: Path, *, execution: bool = True) -> Agent:
    workspace = WorkspaceManager(tmp_path / "workspace")
    workspace.make_directory("demo")
    workspace.write_file("demo/app.py", "VALUE = 1\n")
    workspace.make_directory("demo/tests")
    workspace.write_file(
        "demo/tests/test_app.py",
        "def test_value():\n    assert 1 == 1\n",
    )
    agent = Agent(
        memory=MemoryManager(tmp_path / "memory"),
        router=MinimalRouter(),
        workspace=workspace,
        planner_enabled=False,
        reviewer_enabled=False,
        execution_enabled=execution,
        research_enabled=False,
    )
    agent.project_context.set_active_project("demo")
    return agent


def test_execution_detection_recognizes_plain_test_word(tmp_path: Path) -> None:
    agent = _agent(tmp_path)
    assert agent._requires_execution(
        "Проверь код, проведи тесты до положительного результата", True
    ) is True


def test_all_engineering_tasks_with_execution_get_baseline(tmp_path: Path) -> None:
    agent = _agent(tmp_path)
    assert agent._should_run_baseline("Исправь код проекта", task_mode=True) is True
    assert agent._should_run_baseline("Создай модуль", task_mode=True) is True
    assert agent._should_run_baseline("Привет", task_mode=False) is False


def test_workspace_batch_read_and_idempotent_directory(tmp_path: Path) -> None:
    workspace = WorkspaceManager(tmp_path / "workspace")
    workspace.write_file("a.py", "A = 1\n")
    workspace.write_file("b.py", "B = 2\n")
    result = workspace.read_files(["a.py", "b.py"])
    assert [item["path"] for item in result["files"]] == ["a.py", "b.py"]
    first = workspace.make_directory("tests")
    second = workspace.make_directory("tests")
    assert first["created"] is True
    assert second["created"] is False
    assert second["already_exists"] is True


def test_compileall_accepts_multiple_paths_in_one_process(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    workspace = WorkspaceManager(tmp_path / "workspace")
    workspace.write_file("a.py", "A = 1\n")
    workspace.write_file("b.py", "B = 2\n")
    manager = ExecutionManager(workspace, enabled=True)
    captured: list[list[str]] = []

    def fake_run(command: list[str], **kwargs):
        captured.append(command)
        return {
            "command": command,
            "cwd": ".",
            "exit_code": 0,
            "ok": True,
            "duration_seconds": 0.01,
            "output": "",
            "truncated": False,
        }

    monkeypatch.setattr(manager, "_run", fake_run)
    manager.run_compileall(paths=["a.py", "b.py"])
    assert len(captured) == 1
    assert captured[0][-2:] == ["a.py", "b.py"]


def test_targeted_dependency_remediation_is_environment_only(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    agent = _agent(tmp_path)
    monkeypatch.setattr(settings.agent.dependencies, "allow_install", True)
    calls: list[str] = []
    mypy_count = 0

    def fake_execute(call: ToolCall, evidence: dict, read_paths=None):
        nonlocal mypy_count
        calls.append(call.tool)
        if call.tool == "execution.run_ruff":
            return _payload(call, True, {"ok": True, "output": "clean"}), True, False
        if call.tool == "execution.run_compileall":
            return _payload(call, True, {"ok": True, "output": ""}), True, False
        if call.tool == "execution.run_pytest":
            return _payload(call, True, {"ok": True, "output": "1 passed"}), True, False
        if call.tool == "execution.run_mypy":
            mypy_count += 1
            if mypy_count == 1:
                output = (
                    'error: Library stubs not installed for "yaml"\n'
                    'Hint: "python3 -m pip install types-PyYAML"\n'
                )
                return _payload(call, False, {"ok": False, "output": output}), False, False
            return _payload(call, True, {"ok": True, "output": "Success"}), True, False
        if call.tool == "environment.install_packages":
            return _payload(
                call,
                True,
                {"ok": True, "environment_mutated": True, "packages": ["types-PyYAML"]},
            ), True, True
        if call.tool == "environment.pip_check":
            return (
                _payload(call, True, {"ok": True, "output": "No broken requirements"}),
                True,
                False,
            )
        raise AssertionError(call.tool)

    monkeypatch.setattr(agent, "_execute_tool", fake_execute)
    digest = analyze_test_output("FAILED tests/test_app.py::test_value")
    results, ok = agent._run_targeted_quality_gates(
        {}, changed_paths=["app.py"], failure_digest=digest
    )
    assert ok is True
    assert calls.count("execution.run_compileall") == 1
    install_index = calls.index("environment.install_packages")
    assert calls[install_index : install_index + 3] == [
        "environment.install_packages",
        "environment.pip_check",
        "execution.run_mypy",
    ]
    assert results[-1]["ok"] is True


def _payload(call: ToolCall, ok: bool, result: dict) -> str:
    import json

    return json.dumps(
        {
            "type": "tool_result",
            "call_id": call.call_id,
            "tool": call.tool,
            "ok": ok,
            "result": result,
        },
        ensure_ascii=False,
    )


def test_progress_controller_has_read_only_and_time_escalation() -> None:
    controller = ProgressController()
    controller.local_round_finished(progress=False, elapsed_seconds=200.0)
    controller.local_read_only_finished(progress=False)
    controller.local_round_finished(progress=False, elapsed_seconds=200.0)
    controller.local_read_only_finished(progress=False)
    assert controller.should_escalate_local(
        max_cycles=6,
        max_read_only_cycles=2,
        max_no_progress_seconds=480.0,
    ) is True
    controller.source_mutated()
    assert controller.state.local_read_only_cycles == 0
    assert controller.state.local_no_progress_seconds == 0.0


def test_completed_stable_action_is_deduplicated_across_revisions() -> None:
    controller = ProgressController(max_same_semantic_action=2)
    call = ToolCall(
        tool="workspace.make_directory",
        arguments={"path": "tests"},
        call_id="mkdir-1",
    )
    allowed, _ = controller.action_allowed(call)
    assert allowed is True
    controller.mark_action_completed(call)
    controller.source_mutated()
    duplicate = call.model_copy(update={"call_id": "mkdir-2"})
    assert controller.completed_action(duplicate) is True


def test_retrieval_lexical_fallback_prioritizes_failure_files(tmp_path: Path) -> None:
    workspace = WorkspaceManager(tmp_path / "workspace")
    workspace.make_directory("demo")
    workspace.write_file("demo/app.py", "def broken():\n    return 1\n")
    workspace.write_file("demo/other.py", "VALUE = 2\n")
    workspace.make_directory("demo/tests")
    workspace.write_file(
        "demo/tests/test_app.py",
        "from app import broken\n\ndef test_broken():\n    assert broken() == 2\n",
    )
    digest = analyze_test_output(
        "FAILED tests/test_app.py::test_broken\napp.py:1: AssertionError",
        project="demo",
    )
    retrieval = LocalRetrievalManager(workspace, "demo", embedding_enabled=False)
    result = retrieval.retrieve("исправь broken", failure_digest=digest, top_k=3)
    paths = [item.path for item in result.items]
    assert "app.py" in paths
    assert "tests/test_app.py" in paths
    assert result.mode == "lexical"


def test_tool_instructions_require_batch_reads(tmp_path: Path) -> None:
    agent = _agent(tmp_path)
    instructions = agent.tools.instructions()
    assert "workspace.read_files" in instructions
    assert "batch" in instructions.casefold()


def test_progress_snapshot_restores_stable_actions() -> None:
    controller = ProgressController(max_same_semantic_action=1)
    call = ToolCall(tool="workspace.make_directory", arguments={"path": "tests"})
    controller.mark_action_completed(call)
    controller.source_mutated()
    snapshot = controller.snapshot()

    restored = ProgressController(max_same_semantic_action=1)
    restored.restore(snapshot)
    assert restored.state.source_revision == 1
    assert restored.completed_action(call) is True


def test_creation_with_tests_is_not_kernel_auto_finalize_classification() -> None:
    assert Agent._is_verification_or_repair_task("Создай модуль и протестируй его") is False
    assert Agent._is_verification_or_repair_task("Проверь модуль и исправь ошибки") is True


def test_retrieval_context_does_not_satisfy_read_before_write(tmp_path: Path) -> None:
    agent = _agent(tmp_path)
    agent.workspace.write_file("demo/app.py", "value = 1\n", overwrite=True)
    call = ToolCall(
        tool="workspace.write_file",
        arguments={"path": "demo/app.py", "content": "value = 2\n", "overwrite": True},
    )
    error = agent._mutation_precondition_error(call, set())
    assert error is not None
    assert "сначала" in error


def test_embedding_failure_falls_back_to_lexical(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    import httpx

    workspace = WorkspaceManager(tmp_path / "workspace")
    workspace.make_directory("demo")
    workspace.write_file("demo/app.py", "def target():\n    return 1\n")

    def fail_post(*args, **kwargs):
        raise httpx.ConnectError("LM Studio embeddings unavailable")

    monkeypatch.setattr("core.retrieval.httpx.post", fail_post)
    retrieval = LocalRetrievalManager(
        workspace,
        "demo",
        embedding_enabled=True,
        embedding_model="text-embedding-nomic-embed-text-v1.5",
    )
    result = retrieval.retrieve("target", top_k=1)
    assert result.mode == "lexical"
    assert result.embedding_error is not None
    assert result.items[0].path == "app.py"


def test_scope_control_blocks_unrelated_non_source_mutation(tmp_path: Path) -> None:
    agent = _agent(tmp_path)
    digest = analyze_test_output(
        "FAILED tests/test_app.py::test_value\ntests/test_app.py:2: AssertionError",
        project="demo",
    )
    call = ToolCall(
        tool="workspace.write_file",
        arguments={"path": "demo/.gitignore", "content": ".venv/\n", "overwrite": True},
    )
    _, error = agent._prepare_scoped_mutation(
        call,
        failure_digest=digest,
        plan=None,
        read_paths={"demo/.gitignore"},
    )
    assert error is not None
    assert "не связана" in error
