from __future__ import annotations

from pathlib import Path

import pytest

from core.agent import Agent
from core.config import settings
from core.execution import ExecutionError, ExecutionManager
from core.failure_analyzer import analyze_test_output
from core.memory import MemoryManager
from core.progress_control import ProgressController, semantic_action_fingerprint
from core.protocol import ToolCall
from core.router import resolve_model_id
from core.workspace import WorkspaceManager
from providers.base import CompletionResult


class EscalationRouter:
    def __init__(self) -> None:
        self.calls: list[str] = []
        self.index = 0

    def call(self, *, model_id: str, system_prompt: str, messages: list[dict[str, str]], **kwargs):
        self.calls.append(model_id)
        self.index += 1
        if self.index == 1:
            return CompletionResult(
                text=(
                    '{"type":"tool","tool":"workspace.read_file","arguments":'
                    '{"path":"a.txt"},"call_id":"r1"}'
                ),
                raw_model_name=model_id,
            )
        if self.index == 2:
            return CompletionResult(
                text=(
                    '{"type":"tool","tool":"workspace.read_file","arguments":'
                    '{"path":"b.txt"},"call_id":"r2"}'
                ),
                raw_model_name=model_id,
            )
        if self.index == 3:
            return CompletionResult(
                text=(
                    '{"type":"tool","tool":"workspace.write_file","arguments":'
                    '{"path":"result.txt","content":"ok"},"call_id":"w1"}'
                ),
                raw_model_name=model_id,
            )
        return CompletionResult(
            text='{"type":"final","status":"success","content":"done","evidence":["w1"]}',
            raw_model_name=model_id,
        )


def test_local_executor_escalates_to_yandex_after_n_no_progress_cycles(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    workspace = WorkspaceManager(tmp_path / "workspace")
    workspace.write_file("a.txt", "a")
    workspace.write_file("b.txt", "b")
    monkeypatch.setattr(settings.agent.local_first, "enabled", True)
    monkeypatch.setattr(
        settings.agent.local_first,
        "primary_model",
        "lmstudio:local-code",
    )
    monkeypatch.setattr(
        settings.agent.local_first,
        "escalation_model",
        "yandexgpt:yandex-pro",
    )
    monkeypatch.setattr(
        settings.agent.local_first,
        "max_local_no_progress_cycles",
        2,
    )
    router = EscalationRouter()
    agent = Agent(
        memory=MemoryManager(tmp_path / "memory"),
        router=router,
        workspace=workspace,
        planner_enabled=False,
        reviewer_enabled=False,
        execution_enabled=False,
        research_enabled=False,
    )
    answer = agent.ask("Создай result.txt", force_task=True)
    assert answer == "done"
    assert router.calls[:2] == ["lmstudio:local-code", "lmstudio:local-code"]
    assert router.calls[2:] == ["yandexgpt:yandex-pro", "yandexgpt:yandex-pro"]


def test_semantic_fingerprint_ignores_call_id() -> None:
    first = ToolCall(
        tool="execution.run_ruff",
        arguments={"cwd": "demo"},
        call_id="ruff-1",
    )
    second = ToolCall(
        tool="execution.run_ruff",
        arguments={"cwd": "demo"},
        call_id="ruff-999",
    )
    assert semantic_action_fingerprint(first) == semantic_action_fingerprint(second)


def test_semantic_action_guard_blocks_third_repeat_without_revision() -> None:
    controller = ProgressController(max_same_semantic_action=2)
    for call_id in ("a", "b"):
        allowed, _ = controller.action_allowed(
            ToolCall(
                tool="execution.run_mypy",
                arguments={"cwd": "demo"},
                call_id=call_id,
            )
        )
        assert allowed is True
    allowed, reason = controller.action_allowed(
        ToolCall(
            tool="execution.run_mypy",
            arguments={"cwd": "demo"},
            call_id="c",
        )
    )
    assert allowed is False
    assert "Семантически" in str(reason)
    controller.source_mutated()
    allowed, _ = controller.action_allowed(
        ToolCall(
            tool="execution.run_mypy",
            arguments={"cwd": "demo"},
            call_id="d",
        )
    )
    assert allowed is True


def test_failure_analyzer_classifies_mypy_stub_dependency() -> None:
    digest = analyze_test_output(
        'error: Library stubs not installed for "yaml"\n'
        'Hint: "python3 -m pip install types-PyYAML"\n'
    )
    assert digest.dependency_issue is True
    assert digest.dependency_packages == ["types-PyYAML"]


def test_dependency_manager_is_allow_listed_and_attempt_limited(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    workspace = WorkspaceManager(tmp_path / "workspace")
    workspace.make_directory("demo")
    manager = ExecutionManager(
        workspace,
        enabled=True,
        allow_dependency_install=True,
        allowed_packages=["types-PyYAML"],
        max_install_attempts=1,
    )

    def fake_run(command: list[str], **kwargs):
        return {
            "command": command,
            "cwd": "demo",
            "exit_code": 0,
            "ok": True,
            "duration_seconds": 0.01,
            "output": "installed",
            "truncated": False,
        }

    monkeypatch.setattr(manager, "_run", fake_run)
    result = manager.install_packages(["types-PyYAML"], cwd="demo")
    assert result["environment_mutated"] is True
    with pytest.raises(ExecutionError):
        manager.install_packages(["types-PyYAML"], cwd="demo")
    with pytest.raises(ExecutionError):
        manager.install_packages(["evil-package"], cwd="demo")


def test_lmstudio_model_name_can_come_from_environment(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("LMSTUDIO_MODEL", "qwen-local-test")
    provider, model = resolve_model_id("lmstudio:local-code")
    assert provider.provider_name == "lmstudio"
    assert model == "qwen-local-test"


def _tool_payload(call_id: str, tool: str, ok: bool, result: dict) -> str:
    import json

    return json.dumps(
        {
            "type": "tool_result",
            "call_id": call_id,
            "tool": tool,
            "ok": ok,
            "result": result,
        },
        ensure_ascii=False,
    )


def test_kernel_ruff_autofix_happens_without_extra_llm_round(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    workspace = WorkspaceManager(tmp_path / "workspace")
    workspace.make_directory("demo")
    workspace.write_file("demo/a.py", "import os\n\nprint('x')\n")
    agent = Agent(
        memory=MemoryManager(tmp_path / "memory"),
        router=EscalationRouter(),
        workspace=workspace,
        planner_enabled=False,
        reviewer_enabled=False,
        execution_enabled=True,
        research_enabled=False,
    )
    agent.project_context.set_active_project("demo")
    monkeypatch.setattr(
        agent,
        "_quality_gate_calls",
        lambda: [ToolCall(tool="execution.run_ruff", arguments={"cwd": "demo"})],
    )
    calls: list[ToolCall] = []

    def fake_execute(call: ToolCall, evidence: dict, read_paths=None):
        calls.append(call)
        if len(calls) == 1:
            return (
                _tool_payload(call.call_id, call.tool, False, {"output": "F401", "ok": False}),
                False,
                False,
            )
        if call.arguments.get("fix"):
            return (
                _tool_payload(
                    call.call_id,
                    call.tool,
                    True,
                    {"output": "1 fixed", "ok": True, "changed_paths": ["a.py"]},
                ),
                True,
                True,
            )
        return (
            _tool_payload(
                call.call_id,
                call.tool,
                True,
                {"output": "All checks passed", "ok": True},
            ),
            True,
            False,
        )

    monkeypatch.setattr(agent, "_execute_tool", fake_execute)
    results, ok = agent._run_quality_gates({})
    assert ok is True
    assert any(call.arguments.get("fix") is True for call in calls)
    assert agent._kernel_mutated_paths == {"a.py"}
    assert results[-1]["ok"] is True


def test_kernel_dependency_manager_retries_mypy_once_after_install(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    workspace = WorkspaceManager(tmp_path / "workspace")
    workspace.make_directory("demo")
    workspace.write_file("demo/a.py", "x = 1\n")
    agent = Agent(
        memory=MemoryManager(tmp_path / "memory"),
        router=EscalationRouter(),
        workspace=workspace,
        planner_enabled=False,
        reviewer_enabled=False,
        execution_enabled=True,
        research_enabled=False,
    )
    agent.project_context.set_active_project("demo")
    monkeypatch.setattr(settings.agent.dependencies, "allow_install", True)
    monkeypatch.setattr(
        agent,
        "_quality_gate_calls",
        lambda: [ToolCall(tool="execution.run_mypy", arguments={"cwd": "demo"})],
    )
    calls: list[ToolCall] = []

    def fake_execute(call: ToolCall, evidence: dict, read_paths=None):
        calls.append(call)
        if call.tool == "environment.install_packages":
            return (
                _tool_payload(
                    call.call_id,
                    call.tool,
                    True,
                    {"ok": True, "environment_mutated": True},
                ),
                True,
                False,
            )
        if call.tool == "environment.pip_check":
            return (
                _tool_payload(
                    call.call_id,
                    call.tool,
                    True,
                    {"ok": True, "output": "No broken requirements found."},
                ),
                True,
                False,
            )
        if len([item for item in calls if item.tool == "execution.run_mypy"]) == 1:
            output = (
                'error: Library stubs not installed for "yaml"\n'
                'Hint: "python3 -m pip install types-PyYAML"\n'
            )
            return (
                _tool_payload(call.call_id, call.tool, False, {"output": output, "ok": False}),
                False,
                False,
            )
        return (
            _tool_payload(call.call_id, call.tool, True, {"output": "Success", "ok": True}),
            True,
            False,
        )

    monkeypatch.setattr(agent, "_execute_tool", fake_execute)
    _, ok = agent._run_quality_gates({})
    assert ok is True
    assert [call.tool for call in calls] == [
        "execution.run_mypy",
        "environment.install_packages",
        "environment.pip_check",
        "execution.run_mypy",
    ]
