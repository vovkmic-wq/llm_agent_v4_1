from __future__ import annotations

import re
from pathlib import Path

import tomllib
import yaml

ROOT = Path(__file__).resolve().parents[1]


def _name(requirement: str) -> str:
    return re.split(r"[<>=!~;\s]", requirement, maxsplit=1)[0].casefold()


def test_runtime_dependencies_are_consistent_between_pyproject_and_requirements() -> None:
    project = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))
    pyproject_runtime = {
        _name(item): item for item in project["project"]["dependencies"]
    }
    requirement_lines = [
        line.strip()
        for line in (ROOT / "requirements.txt").read_text(encoding="utf-8").splitlines()
        if line.strip() and not line.lstrip().startswith("#")
    ]
    requirements = {_name(item): item for item in requirement_lines}

    assert set(pyproject_runtime) <= set(requirements)
    for name, requirement in pyproject_runtime.items():
        assert requirements[name].casefold().replace('"', "'") == requirement.casefold()


def test_dependency_remediation_allow_list_is_bounded_and_excludes_types_numpy() -> None:
    config = yaml.safe_load((ROOT / "config" / "agent.yaml").read_text(encoding="utf-8"))
    allowed = config["agent"]["dependencies"]["allowed_packages"]

    assert allowed == ["types-PyYAML", "types-requests"]
    assert "types-numpy" not in {item.casefold() for item in allowed}


def test_v46_package_identity_is_consistent() -> None:
    project = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))
    config = yaml.safe_load((ROOT / "config" / "agent.yaml").read_text(encoding="utf-8"))

    assert project["project"]["version"] == "0.4.6"
    assert "V4.6" in config["agent"]["name"]
