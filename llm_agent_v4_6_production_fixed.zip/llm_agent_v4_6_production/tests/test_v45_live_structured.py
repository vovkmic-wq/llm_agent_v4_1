"""Optional live structured-output checks for user-configured providers.

These tests are excluded from the default suite. Enable explicitly with
AGENT_RUN_LIVE_LLM_TESTS=true and the provider credentials/server settings.
"""
from __future__ import annotations

import os

import pytest

from core.protocol import FinalAnswer, decode_agent_response, protocol_json_schema
from providers.lmstudio_provider import LMStudioProvider
from providers.yandexgpt_provider import YandexGPTProvider

pytestmark = pytest.mark.live_llm


def _live_enabled() -> bool:
    return os.environ.get("AGENT_RUN_LIVE_LLM_TESTS", "").strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }


def _assert_final_json(text: str) -> None:
    decoded = decode_agent_response(text)
    assert isinstance(decoded.action, FinalAnswer)
    assert decoded.action.status in {"success", "partial", "blocked"}


@pytest.mark.skipif(not _live_enabled(), reason="live LLM tests are opt-in")
def test_live_lmstudio_structured_final() -> None:
    base_url = os.environ.get("LMSTUDIO_BASE_URL", "http://localhost:1234/v1")
    model = os.environ.get("LMSTUDIO_MODEL", "").strip()
    if not model:
        pytest.skip("LMSTUDIO_MODEL is not configured")

    provider = LMStudioProvider(os.environ.get("LMSTUDIO_API_KEY"), base_url)
    provider.timeout_seconds = 360.0
    result = provider.complete(
        model_name=model,
        system_prompt=(
            "Return one JSON object conforming to the supplied schema. "
            "Do not call tools."
        ),
        messages=[
            {
                "role": "user",
                "content": (
                    "Return a successful final answer. Set content to LIVE_OK "
                    "and evidence to an empty array."
                ),
            }
        ],
        temperature=0.0,
        max_tokens=128,
        response_schema=protocol_json_schema(),
        response_schema_name="agent_action_v45_live",
    )
    assert result.structured_output == "json_schema"
    _assert_final_json(result.text)


@pytest.mark.skipif(not _live_enabled(), reason="live LLM tests are opt-in")
def test_live_yandex_structured_final() -> None:
    api_key = os.environ.get("YANDEX_API_KEY", "").strip()
    folder_id = os.environ.get("YANDEX_FOLDER_ID", "").strip()
    if not api_key or not folder_id:
        pytest.skip("YANDEX_API_KEY/YANDEX_FOLDER_ID are not configured")

    # YandexGPTProvider reads folder ID via the configured environment name.
    provider = YandexGPTProvider(
        api_key,
        os.environ.get(
            "YANDEX_BASE_URL",
            "https://ai.api.cloud.yandex.net/v1",
        ),
        "YANDEX_FOLDER_ID",
    )
    provider.timeout_seconds = 90.0
    result = provider.complete(
        model_name=os.environ.get("YANDEX_MODEL", "yandexgpt"),
        system_prompt=(
            "Return one JSON object conforming to the supplied schema. "
            "Do not call tools."
        ),
        messages=[
            {
                "role": "user",
                "content": (
                    "Return a successful final answer. Set content to LIVE_OK "
                    "and evidence to an empty array."
                ),
            }
        ],
        temperature=0.0,
        max_tokens=256,
        response_schema=protocol_json_schema(),
        response_schema_name="agent_action_v45_live",
    )
    assert result.structured_output == "json_schema"
    _assert_final_json(result.text)
