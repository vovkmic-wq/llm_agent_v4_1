from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest
from pydantic import BaseModel

from core.agent import Agent
from core.config import settings
from core.failure_analyzer import analyze_test_output
from core.memory import MemoryManager
from core.protocol import (
    ProtocolError,
    decode_agent_response,
    protocol_json_schema,
    repair_instruction,
)
from core.structured_schema import strict_json_schema, strict_schema_violations
from core.workspace import WorkspaceManager
from providers.base import CompletionResult


class _OptionalNested(BaseModel):
    name: str
    reason: str | None = None


class _OptionalEnvelope(BaseModel):
    action: _OptionalNested
    note: str | None = None


class RecordingRouter:
    def __init__(self, responses: list[str] | None = None) -> None:
        self.responses = list(responses or [])
        self.calls: list[dict[str, Any]] = []

    def call(self, **kwargs: Any) -> CompletionResult:
        self.calls.append(kwargs)
        text = self.responses.pop(0) if self.responses else "ok"
        return CompletionResult(text=text, raw_model_name=kwargs["model_id"])


def _agent(tmp_path: Path, router: RecordingRouter, *, execution: bool = False) -> Agent:
    workspace = WorkspaceManager(tmp_path / "workspace")
    workspace.make_directory("demo")
    workspace.write_file("demo/app.py", "VALUE = 1\n")
    agent = Agent(
        memory=MemoryManager(tmp_path / "memory"),
        router=router,
        workspace=workspace,
        planner_enabled=False,
        reviewer_enabled=False,
        execution_enabled=execution,
        research_enabled=False,
    )
    agent.project_context.set_active_project("demo")
    return agent


def _result(call_id: str, tool: str, ok: bool, output: str = "") -> dict[str, Any]:
    return {
        "type": "tool_result",
        "call_id": call_id,
        "tool": tool,
        "ok": ok,
        "result": {"ok": ok, "output": output},
    }


def test_strict_schema_recursively_requires_every_declared_property() -> None:
    raw = _OptionalEnvelope.model_json_schema()
    strict = strict_json_schema(raw)

    assert strict_schema_violations(strict) == []
    assert strict["required"] == ["action", "note"]
    assert "default" not in strict["properties"]["note"]
    nested = strict["$defs"]["_OptionalNested"]
    assert nested["required"] == ["name", "reason"]
    assert nested["additionalProperties"] is False


def test_protocol_schema_matches_yandex_all_fields_required_constraint() -> None:
    schema = protocol_json_schema()

    assert strict_schema_violations(schema) == []
    assert "reason" in schema["required"]
    reason = schema["properties"]["reason"]
    assert {item.get("type") for item in reason["anyOf"]} == {"string", "null"}


def test_structured_schema_forbids_out_of_band_payload_references() -> None:
    schema = protocol_json_schema()

    assert schema["properties"]["payload_id"] == {"type": "null"}
    assert schema["properties"]["payload_argument"] == {"type": "null"}
    nested = schema["properties"]["calls"]["anyOf"][0]["items"]
    assert nested["properties"]["payload_id"] == {"type": "null"}
    assert nested["properties"]["payload_argument"] == {"type": "null"}


def test_structured_payload_repair_keeps_content_inside_json_arguments() -> None:
    instruction = repair_instruction(
        ProtocolError("PAYLOAD missing", code="missing_payload"),
        structured_output=True,
    )

    assert "payload_id=null" in instruction
    assert "arguments" in instruction
    assert "Не добавляй блоки <<<PAYLOAD>>>" in instruction


def test_strict_transport_tool_action_with_null_irrelevant_fields_decodes() -> None:
    raw = json.dumps(
        {
            "type": "tool",
            "tool": "workspace.read_file",
            "arguments": {"path": "demo/app.py"},
            "call_id": "read-1",
            "payload_id": None,
            "payload_argument": None,
            "reason": None,
            "calls": None,
            "status": None,
            "content": None,
            "evidence": None,
        }
    )

    decoded = decode_agent_response(raw)
    assert decoded.action is not None
    assert decoded.action.type == "tool"
    assert decoded.action.call_id == "read-1"


def test_strict_transport_final_action_with_null_irrelevant_fields_decodes() -> None:
    raw = json.dumps(
        {
            "type": "final",
            "tool": None,
            "arguments": None,
            "call_id": None,
            "payload_id": None,
            "payload_argument": None,
            "reason": None,
            "calls": None,
            "status": "success",
            "content": "done",
            "evidence": [],
        }
    )

    decoded = decode_agent_response(raw)
    assert decoded.action is not None
    assert decoded.action.type == "final"
    assert decoded.action.content == "done"


def test_router_call_strictifies_role_schema_before_provider(tmp_path: Path) -> None:
    router = RecordingRouter(['{"action":{"name":"x","reason":null},"note":null}'])
    agent = _agent(tmp_path, router)

    agent._router_call(  # noqa: SLF001 - intentional contract regression test
        model_id="lmstudio:local-code",
        system_prompt="system",
        messages=[{"role": "user", "content": "task"}],
        profile=settings.agent.generation.chat,
        allow_fallback=False,
        response_schema=_OptionalEnvelope.model_json_schema(),
        response_schema_name="optional_envelope_v46",
    )

    sent = router.calls[0]["response_schema"]
    assert strict_schema_violations(sent) == []
    assert sent["required"] == ["action", "note"]


def test_numpy_stub_syntax_is_environment_issue_not_types_numpy_dependency() -> None:
    output = (
        'tests/test_cli.py:3: error: Library stubs not installed for "yaml"\n'
        'tests/test_cli.py:3: note: Hint: "python3 -m pip install types-PyYAML"\n'
        '.venv/Lib/site-packages/numpy/__init__.pyi:737: error: '
        'Type statement is only supported in Python 3.12 and greater  [syntax]\n'
    )

    digest = analyze_test_output(output, project="demo")

    assert digest.dependency_issue is True
    assert digest.typing_environment_issue is True
    assert digest.minimum_python_required == "3.12"
    assert "types-PyYAML" in digest.dependency_packages
    assert "types-numpy" not in {item.casefold() for item in digest.dependency_packages}


def test_mypy_remediation_installs_allowed_stub_only_then_diagnoses_environment(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    router = RecordingRouter()
    agent = _agent(tmp_path, router, execution=True)
    failed = _result(
        "mypy-1",
        "execution.run_mypy",
        False,
        'test.py:1: error: Library stubs not installed for "yaml"\n'
        'note: Hint: "python3 -m pip install types-PyYAML"\n'
        '.venv/Lib/site-packages/numpy/__init__.pyi:737: error: '
        'Type statement is only supported in Python 3.12 and greater [syntax]',
    )
    calls: list[tuple[str, dict[str, Any]]] = []

    def fake_execute(call, evidence):
        calls.append((call.tool, dict(call.arguments)))
        if call.tool == "environment.install_packages":
            item = _result(call.call_id, call.tool, True, "installed")
        elif call.tool == "environment.pip_check":
            item = _result(call.call_id, call.tool, True, "No broken requirements found")
        elif call.tool == "execution.run_mypy":
            item = _result(
                call.call_id,
                call.tool,
                False,
                '.venv/Lib/site-packages/numpy/__init__.pyi:737: error: '
                'Type statement is only supported in Python 3.12 and greater [syntax]',
            )
        elif call.tool == "environment.diagnose_mypy":
            item = _result(call.call_id, call.tool, True, "")
            item["result"]["diagnostics"] = {
                "python": "3.11.9",
                "mypy_python_version": "3.10",
                "packages": {"numpy": "2.3.5", "types-PyYAML": "6.0.12"},
            }
        else:  # pragma: no cover - assertion documents the exact matrix
            raise AssertionError(call.tool)
        evidence[call.call_id] = item
        return json.dumps(item), item["ok"], False

    monkeypatch.setattr(agent, "_execute_tool", fake_execute)
    evidence: dict[str, dict[str, Any]] = {}
    items = agent._remediate_mypy_dependency(  # noqa: SLF001
        failed,
        evidence,
        recheck_arguments={"cwd": "demo"},
    )

    assert items is not None
    assert [tool for tool, _ in calls] == [
        "environment.install_packages",
        "environment.pip_check",
        "execution.run_mypy",
        "environment.diagnose_mypy",
    ]
    assert calls[0][1]["packages"] == ["types-PyYAML"]
    assert all("types-numpy" not in str(arguments).casefold() for _, arguments in calls)
    assert not any(tool in {"execution.run_ruff", "execution.run_compileall"} for tool, _ in calls)


def test_bare_shell_command_is_not_sent_to_llm(tmp_path: Path) -> None:
    router = RecordingRouter()
    agent = _agent(tmp_path, router)

    answer = agent.ask("python -m pip install types-PyYAML")

    assert router.calls == []
    assert "не выполнена" in answer.casefold()
    assert "powershell" in answer.casefold()


def test_post_iap_dependency_remediation_can_finalize_before_llm(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    router = RecordingRouter()
    agent = _agent(tmp_path, router, execution=True)
    initial = [
        _result("ruff-1", "execution.run_ruff", True, "ok"),
        _result("compile-1", "execution.run_compileall", True, "ok"),
        _result(
            "mypy-1",
            "execution.run_mypy",
            False,
            'error: Library stubs not installed for "yaml"\n'
            'note: Hint: "python3 -m pip install types-PyYAML"',
        ),
        _result("pytest-1", "execution.run_pytest", True, "1 passed"),
    ]

    def baseline(evidence, remediate=False):
        assert remediate is False
        for item in initial:
            evidence[item["call_id"]] = item
        return initial, False

    def remediate(results, evidence):
        assert results is initial
        initial[2]["superseded"] = True
        install = _result("install-1", "environment.install_packages", True, "installed")
        pip_check = _result("pip-1", "environment.pip_check", True, "ok")
        mypy_green = _result("mypy-2", "execution.run_mypy", True, "Success")
        for item in (install, pip_check, mypy_green):
            evidence[item["call_id"]] = item
        return [*initial, install, pip_check, mypy_green], True

    monkeypatch.setattr(agent, "_run_quality_gates", baseline)
    monkeypatch.setattr(agent, "_remediate_baseline_dependencies", remediate)

    answer = agent.ask(
        "Исправь текущую проблему mypy и повторяй проверки до PASS.",
        force_task=True,
    )

    assert router.calls == []
    assert "задача выполнена" in answer.casefold()
    assert "execution.run_mypy" in answer


def test_post_iap_environment_blocker_finishes_without_llm(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    router = RecordingRouter()
    agent = _agent(tmp_path, router, execution=True)
    initial = [
        _result("ruff-1", "execution.run_ruff", True, "ok"),
        _result("compile-1", "execution.run_compileall", True, "ok"),
        _result(
            "mypy-1",
            "execution.run_mypy",
            False,
            'error: Library stubs not installed for "yaml"\n'
            'note: Hint: "python3 -m pip install types-PyYAML"',
        ),
        _result("pytest-1", "execution.run_pytest", True, "1 passed"),
    ]

    def baseline(evidence, remediate=False):
        for item in initial:
            evidence[item["call_id"]] = item
        return initial, False

    def remediate(results, evidence):
        initial[2]["superseded"] = True
        blocker = _result(
            "mypy-2",
            "execution.run_mypy",
            False,
            '.venv/Lib/site-packages/numpy/__init__.pyi:737: error: '
            'Type statement is only supported in Python 3.12 and greater [syntax]',
        )
        blocker["failure_class"] = "environment"
        blocker["result"]["infrastructure_error"] = True
        blocker["result"]["reason"] = "NumPy typing requires Python target >=3.12"
        blocker["result"]["environment_diagnostics"] = {
            "python": "3.11.9",
            "mypy_python_version": "3.10",
            "packages": {"numpy": "2.3.5"},
        }
        evidence[blocker["call_id"]] = blocker
        return [*initial, blocker], True

    monkeypatch.setattr(agent, "_run_quality_gates", baseline)
    monkeypatch.setattr(agent, "_remediate_baseline_dependencies", remediate)

    answer = agent.ask(
        "Исправь текущую проблему mypy до PASS либо доказанного blocker.",
        force_task=True,
    )

    assert router.calls == []
    assert "environment blocker" in answer.casefold()
    assert "mypy-2" in answer
    assert agent.task_state.current is not None
    assert agent.task_state.current.status == "failed"
