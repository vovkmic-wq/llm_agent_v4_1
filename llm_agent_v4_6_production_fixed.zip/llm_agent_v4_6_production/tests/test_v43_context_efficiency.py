from __future__ import annotations

from pathlib import Path

import pytest

import core.router as router_module
from core.agent import Agent
from core.config import settings
from core.memory import MemoryManager
from core.router import Router
from core.workspace import WorkspaceManager
from providers.base import CompletionResult, ProviderError
from providers.lmstudio_provider import LMStudioProvider


class CaptureRouter:
    def __init__(self, text: str = "Привет!") -> None:
        self.text = text
        self.calls: list[dict] = []

    def call(self, **kwargs):
        self.calls.append(kwargs)
        return CompletionResult(
            text=self.text,
            raw_model_name=kwargs["model_id"],
        )


def _agent(tmp_path: Path, router) -> Agent:
    workspace = WorkspaceManager(tmp_path / "workspace")
    workspace.make_directory("demo")
    agent = Agent(
        memory=MemoryManager(tmp_path / "memory"),
        router=router,
        workspace=workspace,
        planner_enabled=False,
        reviewer_enabled=False,
        execution_enabled=False,
        research_enabled=False,
    )
    agent.project_context.set_active_project("demo")
    return agent


def test_quick_chat_uses_small_prompt_without_engineering_harness(
    tmp_path: Path,
) -> None:
    router = CaptureRouter()
    agent = _agent(tmp_path, router)
    answer = agent.ask("привет")

    assert answer == "Привет!"
    assert len(router.calls) == 1
    call = router.calls[0]
    assert call["model_id"] == "lmstudio:local-code"
    assert call["max_tokens"] == settings.agent.generation.chat.max_tokens
    assert call["max_tokens"] == 512
    assert "TOOL / EXECUTION CONTEXT" not in call["system_prompt"]
    assert "ACTIVE PROJECT FILE INDEX" not in call["system_prompt"]
    assert "ICS INCIDENT CONTROL" not in call["system_prompt"]
    assert "разговорный режим" in call["system_prompt"]
    total_chars = len(call["system_prompt"]) + sum(
        len(item["content"]) for item in call["messages"]
    )
    assert total_chars < 2000


def test_contextual_chat_has_clipped_project_context_but_no_tools(
    tmp_path: Path,
) -> None:
    router = CaptureRouter("Контекст вижу.")
    agent = _agent(tmp_path, router)
    agent.project_context.add_context_fact("Проект использует SQLite для истории.")

    answer = agent.ask("Что известно о текущем контексте?")

    assert answer == "Контекст вижу."
    call = router.calls[0]
    assert "КРАТКИЙ КОНТЕКСТ АКТИВНОГО ПРОЕКТА" in call["system_prompt"]
    assert "SQLite" in call["system_prompt"]
    assert "TOOL / EXECUTION CONTEXT" not in call["system_prompt"]
    assert "ACTIVE PROJECT FILE INDEX" not in call["system_prompt"]


def test_quick_chat_does_not_call_summarizer(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    router = CaptureRouter()
    agent = _agent(tmp_path, router)

    def fail_if_called() -> None:
        raise AssertionError("quick chat must not synchronously summarize")

    monkeypatch.setattr(agent, "_maybe_summarize", fail_if_called)
    assert agent.ask("спасибо") == "Привет!"


def test_lmstudio_policy_is_three_times_old_timeout() -> None:
    entry = settings.models.providers["lmstudio"]
    assert entry.timeout_seconds == 360
    assert entry.max_attempts == 1


def test_lmstudio_provider_uses_configured_timeout(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    captured: dict[str, object] = {}

    class Response:
        def raise_for_status(self) -> None:
            return None

        def json(self) -> dict:
            return {
                "choices": [
                    {
                        "message": {"content": "ok"},
                        "finish_reason": "stop",
                    }
                ]
            }

    def fake_post(url, *, headers, json, timeout):
        captured["url"] = url
        captured["timeout"] = timeout
        return Response()

    monkeypatch.setattr("providers.openai_compatible.httpx.post", fake_post)
    provider = LMStudioProvider(None, "http://localhost:1234/v1")
    provider.timeout_seconds = 360
    result = provider.complete(
        model_name="qwen2.5-coder-7b-instruct",
        system_prompt="system",
        messages=[{"role": "user", "content": "hello"}],
        max_tokens=32,
    )

    assert result.text == "ok"
    assert captured["timeout"] == 360.0


class FakeProvider:
    def __init__(self, name: str, *, fail: bool) -> None:
        self.provider_name = name
        self.fail = fail
        self.max_attempts = 1 if name == "lmstudio" else 3
        self.calls = 0

    def is_configured(self) -> bool:
        return True

    def complete(self, **kwargs):
        self.calls += 1
        if self.fail:
            raise ProviderError("timed out", retryable=True)
        return CompletionResult(text="cloud-ok", raw_model_name="yandexgpt")


def test_local_transport_failure_falls_back_after_one_attempt(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    local = FakeProvider("lmstudio", fail=True)
    cloud = FakeProvider("yandexgpt", fail=False)

    def fake_resolve(model_id: str):
        if model_id == "lmstudio:local-code":
            return local, "local-model"
        if model_id == "yandexgpt:yandex-pro":
            return cloud, "yandexgpt"
        raise AssertionError(model_id)

    monkeypatch.setattr(router_module, "resolve_model_id", fake_resolve)
    router = Router()
    result = router.call(
        model_id="lmstudio:local-code",
        system_prompt="system",
        messages=[{"role": "user", "content": "hello"}],
        max_tokens=32,
        allow_fallback=True,
    )

    assert result.text == "cloud-ok"
    assert local.calls == 1
    assert cloud.calls == 1
