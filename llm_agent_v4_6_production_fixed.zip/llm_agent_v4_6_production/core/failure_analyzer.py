"""Deterministic test-output analysis used before asking an LLM for diagnosis."""
from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field
from pathlib import Path

_FAILED_RE = re.compile(r"^FAILED\s+([^\s]+)", re.MULTILINE)
_FRAME_RE = re.compile(r"(?P<path>(?:[A-Za-z]:)?[^\s:]+\.py):(?P<line>\d+)")
_ERROR_RE = re.compile(r"\b([A-Za-z_][A-Za-z0-9_]*(?:Error|Exception))\b")
_STUB_PACKAGE_RE = re.compile(r"(?:pip install|install)\s+(types-[A-Za-z0-9_.-]+)", re.IGNORECASE)
_MISSING_STUB_RE = re.compile(
    r"(?:Library stubs not installed|Cannot find implementation or library stub)",
    re.IGNORECASE,
)
_PYTHON_STUB_SYNTAX_RE = re.compile(
    r"Type statement is only supported in Python (?P<version>\d+\.\d+) and greater",
    re.IGNORECASE,
)
_UNSUPPORTED_STUB_PACKAGES = {"types-numpy"}


@dataclass(slots=True)
class FailureDigest:
    signature: str
    failed_tests: list[str] = field(default_factory=list)
    relevant_files: list[str] = field(default_factory=list)
    exceptions: list[str] = field(default_factory=list)
    dependency_packages: list[str] = field(default_factory=list)
    dependency_issue: bool = False
    typing_environment_issue: bool = False
    minimum_python_required: str | None = None
    summary: str = ""


def analyze_test_output(output: str, project: str = ".") -> FailureDigest:
    normalized = output.replace("\\", "/")
    failed = list(dict.fromkeys(_FAILED_RE.findall(normalized)))[:20]
    files: list[str] = []
    project_prefix = project.strip("./").replace("\\", "/")
    for match in _FRAME_RE.finditer(normalized):
        raw = match.group("path").replace("\\", "/")
        if "/site-packages/" in raw or "/lib/python" in raw.casefold():
            continue
        if project_prefix and project_prefix != "." and raw.startswith(project_prefix + "/"):
            raw = raw[len(project_prefix) + 1 :]
        path = Path(raw).as_posix()
        if path not in files:
            files.append(path)
        if len(files) >= 20:
            break
    exceptions = list(dict.fromkeys(_ERROR_RE.findall(normalized)))[:10]
    dependency_packages = [
        package
        for package in dict.fromkeys(_STUB_PACKAGE_RE.findall(normalized))
        if package.casefold() not in _UNSUPPORTED_STUB_PACKAGES
    ][:10]
    syntax_match = _PYTHON_STUB_SYNTAX_RE.search(normalized)
    typing_environment_issue = bool(syntax_match and "site-packages" in normalized.casefold())
    minimum_python_required = (
        syntax_match.group("version") if typing_environment_issue and syntax_match else None
    )
    dependency_issue = bool(
        dependency_packages
        or _MISSING_STUB_RE.search(normalized)
        or typing_environment_issue
    )
    basis = "\n".join(
        [
            *failed,
            *files,
            *exceptions,
            *dependency_packages,
            *(
                [f"python>={minimum_python_required}"]
                if minimum_python_required
                else []
            ),
        ]
    ) or normalized[-4000:]
    signature = hashlib.sha256(basis.encode("utf-8", errors="replace")).hexdigest()[:20]
    summary_lines = [
        f"failed_tests={len(failed)}",
        f"relevant_files={files[:10]}",
        f"exceptions={exceptions[:10]}",
        f"dependency_packages={dependency_packages}",
        f"dependency_issue={dependency_issue}",
        f"typing_environment_issue={typing_environment_issue}",
        f"minimum_python_required={minimum_python_required}",
    ]
    return FailureDigest(
        signature=signature,
        failed_tests=failed,
        relevant_files=files,
        exceptions=exceptions,
        dependency_packages=dependency_packages,
        dependency_issue=dependency_issue,
        typing_environment_issue=typing_environment_issue,
        minimum_python_required=minimum_python_required,
        summary="; ".join(summary_lines),
    )
