"""Provider-independent strict JSON Schema normalization for structured output.

V4.6 compiles every provider-facing schema through the same deterministic pass.
Strict providers such as Yandex require every property of a closed object to be
listed in ``required``. Pydantic still performs the authoritative semantic
validation after transport, so this module only tightens the transport schema;
it never invents response values.
"""
from __future__ import annotations

from copy import deepcopy
from typing import Any

from pydantic import BaseModel

_SCHEMA_BRANCH_KEYS = ("anyOf", "oneOf", "allOf")


def _walk(node: Any) -> None:
    if isinstance(node, list):
        for item in node:
            _walk(item)
        return
    if not isinstance(node, dict):
        return

    # ``default`` is generation metadata rather than a validation requirement and
    # is rejected/ignored by several strict structured-output implementations.
    node.pop("default", None)

    properties = node.get("properties")
    if isinstance(properties, dict):
        # Yandex strict structured output requires every declared object field to
        # be required. Optional semantics must therefore be represented by the
        # field schema itself (normally ``anyOf: [T, null]``), not by omission.
        node["required"] = list(properties)
        node["additionalProperties"] = False
        for child in properties.values():
            _walk(child)

    items = node.get("items")
    if isinstance(items, (dict, list)):
        _walk(items)

    defs = node.get("$defs")
    if isinstance(defs, dict):
        for child in defs.values():
            _walk(child)

    definitions = node.get("definitions")
    if isinstance(definitions, dict):
        for child in definitions.values():
            _walk(child)

    for key in _SCHEMA_BRANCH_KEYS:
        branches = node.get(key)
        if isinstance(branches, list):
            for branch in branches:
                _walk(branch)

    # ``additionalProperties`` may itself contain a schema for map values. Do not
    # turn open maps (e.g. ToolCall.arguments) into closed empty objects.
    additional = node.get("additionalProperties")
    if isinstance(additional, dict):
        _walk(additional)


def strict_json_schema(schema: dict[str, Any]) -> dict[str, Any]:
    """Return a deep-copied schema normalized for strict structured output."""
    normalized = deepcopy(schema)
    _walk(normalized)
    return normalized


def strict_model_schema(model: type[BaseModel]) -> dict[str, Any]:
    """Compile a Pydantic model schema through the V4.6 strict transport pass."""
    return strict_json_schema(model.model_json_schema())


def strict_schema_violations(schema: dict[str, Any]) -> list[str]:
    """Return deterministic diagnostics for object fields missing from required."""
    violations: list[str] = []

    def visit(node: Any, path: str) -> None:
        if isinstance(node, list):
            for index, item in enumerate(node):
                visit(item, f"{path}[{index}]")
            return
        if not isinstance(node, dict):
            return
        properties = node.get("properties")
        if isinstance(properties, dict):
            required = node.get("required")
            required_set = set(required) if isinstance(required, list) else set()
            missing = [name for name in properties if name not in required_set]
            if missing:
                violations.append(f"{path}: missing required={missing}")
            if node.get("additionalProperties") is not False:
                violations.append(f"{path}: additionalProperties must be false")
            for name, child in properties.items():
                visit(child, f"{path}.properties.{name}")
        if isinstance(node.get("items"), (dict, list)):
            visit(node["items"], f"{path}.items")
        for defs_key in ("$defs", "definitions"):
            defs = node.get(defs_key)
            if isinstance(defs, dict):
                for name, child in defs.items():
                    visit(child, f"{path}.{defs_key}.{name}")
        for key in _SCHEMA_BRANCH_KEYS:
            branches = node.get(key)
            if isinstance(branches, list):
                for index, branch in enumerate(branches):
                    visit(branch, f"{path}.{key}[{index}]")

    visit(schema, "$")
    return violations
