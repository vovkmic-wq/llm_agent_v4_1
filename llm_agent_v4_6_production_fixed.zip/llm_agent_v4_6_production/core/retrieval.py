"""Local-first retrieval for compact engineering context.

The retrieval layer is deliberately optional: deterministic lexical scoring is always
available, while LM Studio embeddings are used when ``LMSTUDIO_EMBEDDING_MODEL`` is
configured. A local embedding failure never blocks the coding task.
"""
from __future__ import annotations

import math
import os
import re
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path

import httpx

from core.failure_analyzer import FailureDigest
from core.workspace import WorkspaceError, WorkspaceManager

_TOKEN_RE = re.compile(r"[A-Za-zА-Яа-яЁё_][A-Za-zА-Яа-яЁё0-9_]{1,}")
_ALLOWED_SUFFIXES = {
    ".py",
    ".pyi",
    ".toml",
    ".yaml",
    ".yml",
    ".json",
    ".md",
    ".rst",
    ".txt",
}


@dataclass(frozen=True, slots=True)
class RetrievalItem:
    path: str
    score: float
    content: str
    sha256: str


@dataclass(frozen=True, slots=True)
class RetrievalResult:
    items: list[RetrievalItem]
    mode: str
    embedding_error: str | None = None

    def render(self, max_chars: int = 16000) -> str:
        remaining = max(1000, int(max_chars))
        chunks: list[str] = []
        for item in self.items:
            header = f"\n--- {item.path} | score={item.score:.4f} ---\n"
            if len(header) >= remaining:
                break
            body_budget = remaining - len(header)
            body = item.content[:body_budget]
            chunks.append(header + body)
            remaining -= len(header) + len(body)
            if remaining <= 200:
                break
        return "".join(chunks).strip()


class LocalRetrievalManager:
    """Retrieve the smallest useful source/spec/test context for an engineering task."""

    def __init__(
        self,
        workspace: WorkspaceManager,
        project: str,
        *,
        embedding_enabled: bool = True,
        embedding_model: str | None = None,
        base_url: str | None = None,
        timeout_seconds: float = 20.0,
        max_candidate_files: int = 60,
        max_chars_per_file: int = 5000,
    ) -> None:
        self.workspace = workspace
        self.project = project.strip("/") or "."
        self.embedding_enabled = embedding_enabled
        self.embedding_model = (
            embedding_model
            if embedding_model is not None
            else os.environ.get("LMSTUDIO_EMBEDDING_MODEL", "").strip()
        )
        self.base_url = (
            base_url
            if base_url is not None
            else os.environ.get("LMSTUDIO_BASE_URL", "http://localhost:1234/v1")
        ).rstrip("/")
        self.timeout_seconds = max(1.0, float(timeout_seconds))
        self.max_candidate_files = max(4, int(max_candidate_files))
        self.max_chars_per_file = max(1000, int(max_chars_per_file))

    @staticmethod
    def _tokens(text: str) -> set[str]:
        return {token.casefold() for token in _TOKEN_RE.findall(text)}

    def _project_relative(self, workspace_path: str) -> str:
        prefix = self.project.rstrip("/")
        if prefix not in {"", "."} and workspace_path.startswith(prefix + "/"):
            return workspace_path[len(prefix) + 1 :]
        return workspace_path

    def _seed_paths(self, digest: FailureDigest | None) -> list[str]:
        if digest is None:
            return []
        values: list[str] = []
        for path in digest.relevant_files:
            normalized = path.replace("\\", "/").lstrip("./")
            if normalized and normalized not in values:
                values.append(normalized)
        for selector in digest.failed_tests:
            path = selector.split("::", 1)[0].replace("\\", "/").lstrip("./")
            if path and path not in values:
                values.append(path)
        return values

    def _candidate_paths(self, digest: FailureDigest | None) -> list[str]:
        listing = self.workspace.list_files(self.project, recursive=True)["entries"]
        available: list[str] = []
        for item in listing:
            if item.get("type") != "file":
                continue
            path = self._project_relative(str(item.get("path", "")))
            suffix = Path(path).suffix.casefold()
            if suffix not in _ALLOWED_SUFFIXES:
                continue
            if path not in available:
                available.append(path)
        seeds = self._seed_paths(digest)
        ordered: list[str] = []
        for seed in seeds:
            if seed in available and seed not in ordered:
                ordered.append(seed)
        for path in available:
            if path not in ordered:
                ordered.append(path)
            if len(ordered) >= self.max_candidate_files:
                break
        return ordered[: self.max_candidate_files]

    def _read_candidates(self, paths: Iterable[str]) -> list[RetrievalItem]:
        items: list[RetrievalItem] = []
        prefix = "" if self.project in {"", "."} else self.project.rstrip("/") + "/"
        for path in paths:
            try:
                raw = self.workspace.read_file(prefix + path)
            except WorkspaceError:
                continue
            content = str(raw.get("content", ""))[: self.max_chars_per_file]
            items.append(
                RetrievalItem(
                    path=path,
                    score=0.0,
                    content=content,
                    sha256=str(raw.get("sha256", "")),
                )
            )
        return items

    def _lexical_rank(
        self,
        query: str,
        items: list[RetrievalItem],
        digest: FailureDigest | None,
    ) -> list[RetrievalItem]:
        query_tokens = self._tokens(query)
        seed_paths = set(self._seed_paths(digest))
        ranked: list[RetrievalItem] = []
        for item in items:
            path_tokens = self._tokens(item.path.replace("/", " "))
            content_tokens = self._tokens(item.content[:3000])
            score = 0.0
            score += 8.0 if item.path in seed_paths else 0.0
            score += 3.0 * len(query_tokens.intersection(path_tokens))
            score += 1.0 * len(query_tokens.intersection(content_tokens))
            if item.path.startswith("tests/") or "/tests/" in f"/{item.path}":
                score += 0.5
            if Path(item.path).name.casefold() in {
                "pyproject.toml",
                "requirements.txt",
                "technical_specification.md",
                "specification.md",
                "srs.md",
            }:
                score += 0.25
            ranked.append(
                RetrievalItem(
                    path=item.path,
                    score=score,
                    content=item.content,
                    sha256=item.sha256,
                )
            )
        return sorted(ranked, key=lambda item: (-item.score, item.path.casefold()))

    def _embed(self, texts: list[str]) -> list[list[float]]:
        if not self.embedding_model:
            raise RuntimeError("LMSTUDIO_EMBEDDING_MODEL не задан")
        response = httpx.post(
            f"{self.base_url}/embeddings",
            headers={"Content-Type": "application/json"},
            json={"model": self.embedding_model, "input": texts},
            timeout=self.timeout_seconds,
        )
        response.raise_for_status()
        payload = response.json()
        data = payload.get("data") if isinstance(payload, dict) else None
        if not isinstance(data, list) or len(data) != len(texts):
            raise RuntimeError("LM Studio embeddings: неожиданный формат ответа")
        vectors: list[list[float]] = []
        for item in sorted(data, key=lambda row: int(row.get("index", 0))):
            vector = item.get("embedding") if isinstance(item, dict) else None
            if not isinstance(vector, list):
                raise RuntimeError("LM Studio embeddings: embedding отсутствует")
            vectors.append([float(value) for value in vector])
        return vectors

    @staticmethod
    def _cosine(left: list[float], right: list[float]) -> float:
        if len(left) != len(right) or not left:
            return 0.0
        dot = sum(a * b for a, b in zip(left, right, strict=True))
        left_norm = math.sqrt(sum(value * value for value in left))
        right_norm = math.sqrt(sum(value * value for value in right))
        if left_norm == 0.0 or right_norm == 0.0:
            return 0.0
        return dot / (left_norm * right_norm)

    def retrieve(
        self,
        query: str,
        *,
        failure_digest: FailureDigest | None = None,
        top_k: int = 8,
    ) -> RetrievalResult:
        paths = self._candidate_paths(failure_digest)
        items = self._read_candidates(paths)
        lexical = self._lexical_rank(query, items, failure_digest)
        limit = max(1, min(int(top_k), 20))
        if not self.embedding_enabled or not self.embedding_model or not lexical:
            return RetrievalResult(items=lexical[:limit], mode="lexical")

        # Embed only the best lexical candidates: the embedding model should refine
        # a bounded set, not become another full-project scan.
        candidates = lexical[: min(len(lexical), 24)]
        texts = [query] + [f"{item.path}\n{item.content}" for item in candidates]
        try:
            vectors = self._embed(texts)
            query_vector = vectors[0]
            embedded: list[RetrievalItem] = []
            for item, vector in zip(candidates, vectors[1:], strict=True):
                semantic = self._cosine(query_vector, vector)
                # Preserve deterministic failure/path priority while letting semantic
                # similarity reorder otherwise close candidates.
                combined = semantic + min(item.score, 12.0) / 20.0
                embedded.append(
                    RetrievalItem(
                        path=item.path,
                        score=combined,
                        content=item.content,
                        sha256=item.sha256,
                    )
                )
            embedded.sort(key=lambda item: (-item.score, item.path.casefold()))
            return RetrievalResult(items=embedded[:limit], mode="embedding")
        except (httpx.HTTPError, RuntimeError, ValueError, TypeError) as exc:
            return RetrievalResult(
                items=lexical[:limit],
                mode="lexical",
                embedding_error=str(exc),
            )
