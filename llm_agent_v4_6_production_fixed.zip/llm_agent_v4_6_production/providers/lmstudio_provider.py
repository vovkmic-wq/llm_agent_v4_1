"""LM Studio provider through its OpenAI-compatible local HTTP API."""
from __future__ import annotations

from providers.openai_compatible import OpenAICompatibleProvider


class LMStudioProvider(OpenAICompatibleProvider):
    """Local-first provider for LM Studio.

    LM Studio exposes an OpenAI-compatible API, typically at
    ``http://localhost:1234/v1``. Authentication is optional and can be enabled
    in LM Studio; when ``LMSTUDIO_API_KEY`` is set it is sent as a Bearer token.
    """

    provider_name = "lmstudio"
    supports_structured_output = True
    requires_api_key = False
