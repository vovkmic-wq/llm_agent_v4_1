"""Общие безопасные helpers для HTTP-провайдеров."""
from __future__ import annotations

import json
import re
from typing import Any

import httpx

from providers.base import ProviderError

_RETRYABLE_STATUS = {408, 409, 425, 429, 500, 502, 503, 504}
_MAX_ERROR_DETAIL_CHARS = 1200
_SECRET_PATTERNS = (
    re.compile(r"(?i)(authorization|api[-_ ]?key)\s*[:=]\s*[^\s,;]+"),
    re.compile(r"(?i)\b(Bearer|Api-Key)\s+[A-Za-z0-9._~+\-/=]+"),
)


def _redact_secrets(text: str) -> str:
    sanitized = text
    for pattern in _SECRET_PATTERNS:
        sanitized = pattern.sub(r"\1=<redacted>", sanitized)
    return sanitized


def _safe_http_detail(response: httpx.Response) -> str | None:
    """Extract bounded server diagnostics without request headers or secrets."""
    try:
        payload = response.json()
    except ValueError:
        payload = None

    detail: str = ""
    if isinstance(payload, dict):
        error = payload.get("error", payload)
        if isinstance(error, dict):
            selected = {
                key: error[key]
                for key in ("code", "status", "message")
                if key in error
            }
            if selected:
                detail = json.dumps(selected, ensure_ascii=False, default=str)
        elif isinstance(error, str):
            detail = error
    if not detail:
        try:
            detail = response.text
        except (UnicodeDecodeError, RuntimeError):
            detail = ""

    detail = " ".join(_redact_secrets(detail).split())
    if not detail:
        return None
    if len(detail) > _MAX_ERROR_DETAIL_CHARS:
        detail = detail[: _MAX_ERROR_DETAIL_CHARS - 3] + "..."
    return detail


def provider_http_error(provider: str, exc: httpx.HTTPError) -> ProviderError:
    """Convert HTTPX errors to ProviderError with safe actionable diagnostics."""
    status: int | None = None
    detail: str | None = None
    if isinstance(exc, httpx.HTTPStatusError):
        status = exc.response.status_code
        detail = _safe_http_detail(exc.response)
    retryable = status is None or status in _RETRYABLE_STATUS or status >= 500
    status_text = f" HTTP {status}" if status is not None else ""
    detail_text = f"; server={detail}" if detail else ""
    return ProviderError(
        f"{provider} API ошибка{status_text}: {exc}{detail_text}",
        retryable=retryable,
    )


def json_object(response: httpx.Response, provider: str) -> dict[str, Any]:
    """Разобрать JSON-объект и не выпускать ValueError/TypeError наружу."""
    try:
        data = response.json()
    except ValueError as exc:
        raise ProviderError(
            f"{provider}: API вернул невалидный JSON",
            retryable=False,
        ) from exc
    if not isinstance(data, dict):
        raise ProviderError(
            f"{provider}: ожидался JSON object, получен {type(data).__name__}",
            retryable=False,
        )
    return data


def as_optional_int(value: Any) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None
