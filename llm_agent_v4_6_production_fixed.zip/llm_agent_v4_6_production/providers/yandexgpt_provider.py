"""YandexGPT provider through the current OpenAI-compatible AI Studio API."""
from __future__ import annotations

import os
from typing import Any
from urllib.parse import urlparse

import httpx

from providers.base import BaseProvider, CompletionResult, ProviderError
from providers.http_utils import as_optional_int, json_object, provider_http_error

_CURRENT_BASE_URL = "https://ai.api.cloud.yandex.net/v1"
_YANDEX_API_HOSTS = {"llm.api.cloud.yandex.net", "ai.api.cloud.yandex.net"}
_LEGACY_PATH = "/foundationModels/v1"
_CHAT_COMPLETIONS_PATH = "/v1/chat/completions"


class YandexGPTProvider(BaseProvider):
    """YandexGPT transport with provider-native JSON Schema support.

    AI Studio currently documents an OpenAI-compatible Chat Completions endpoint.
    Older V4.x installations may still carry the former Foundation Models base URL;
    the official legacy URL is migrated internally so existing ``.env`` files do not
    keep sending V4.6 structured requests to the incompatible payload contract.
    """

    provider_name = "yandexgpt"
    supports_structured_output = True

    def __init__(
        self,
        api_key: str | None,
        base_url: str | None,
        folder_id_env: str | None = None,
    ) -> None:
        super().__init__(api_key, self._normalize_base_url(base_url))
        self.folder_id = os.environ.get(folder_id_env) if folder_id_env else None

    @staticmethod
    def _normalize_base_url(base_url: str | None) -> str | None:
        """Migrate only Yandex's official legacy Foundation Models URL."""
        if not base_url:
            return base_url
        normalized = base_url.rstrip("/")
        parsed = urlparse(normalized)
        path = parsed.path.rstrip("/")
        if parsed.hostname in _YANDEX_API_HOSTS and path == _LEGACY_PATH:
            return _CURRENT_BASE_URL
        if parsed.hostname == "ai.api.cloud.yandex.net" and path == _CHAT_COMPLETIONS_PATH:
            return _CURRENT_BASE_URL
        return normalized

    def is_configured(self) -> bool:
        return bool(self.api_key and self.folder_id and self.base_url)

    def complete(
        self,
        *,
        model_name: str,
        system_prompt: str,
        messages: list[dict[str, str]],
        temperature: float = 0.15,
        max_tokens: int = 8192,
        response_schema: dict[str, Any] | None = None,
        response_schema_name: str = "response",
    ) -> CompletionResult:
        if not self.is_configured():
            raise ProviderError(
                "YandexGPT: YANDEX_API_KEY/YANDEX_FOLDER_ID/base_url не заданы",
                retryable=False,
            )

        headers = {
            "Authorization": f"Api-Key {self.api_key}",
            "Content-Type": "application/json",
            "OpenAI-Project": str(self.folder_id),
        }
        payload: dict[str, Any] = {
            "model": f"gpt://{self.folder_id}/{model_name}",
            "messages": [
                {"role": "system", "content": system_prompt},
                *[
                    {
                        "role": (
                            "assistant"
                            if message.get("role") == "assistant"
                            else "user"
                        ),
                        "content": message.get("content", ""),
                    }
                    for message in messages
                ],
            ],
            "stream": False,
            "temperature": max(0.0, min(float(temperature), 1.0)),
            "max_tokens": max(256, min(int(max_tokens), 65536)),
        }
        structured_output: str | None = None
        if response_schema is not None:
            payload["response_format"] = {
                "type": "json_schema",
                "json_schema": {
                    "name": response_schema_name[:64] or "response",
                    "schema": response_schema,
                },
            }
            structured_output = "json_schema"

        try:
            response = httpx.post(
                f"{self.base_url}/chat/completions",
                headers=headers,
                json=payload,
                timeout=float(getattr(self, "timeout_seconds", 90.0)),
            )
            response.raise_for_status()
        except httpx.HTTPError as exc:
            raise provider_http_error("YandexGPT", exc) from exc

        data = json_object(response, "YandexGPT")
        try:
            choice: Any = data["choices"][0]
            message: Any = choice["message"]
            text = message["content"]
        except (KeyError, IndexError, TypeError) as exc:
            raise ProviderError(
                "YandexGPT: неожиданный формат OpenAI-compatible ответа",
                retryable=False,
            ) from exc
        if not isinstance(text, str):
            raise ProviderError("YandexGPT: message.content не строка", retryable=False)

        usage_value = data.get("usage")
        usage: dict[str, Any] = usage_value if isinstance(usage_value, dict) else {}
        finish_reason = choice.get("finish_reason") if isinstance(choice, dict) else None
        return CompletionResult(
            text=text,
            raw_model_name=model_name,
            usage_tokens=as_optional_int(usage.get("total_tokens")),
            finish_reason=(
                str(finish_reason) if finish_reason is not None else None
            ),
            prompt_tokens=as_optional_int(usage.get("prompt_tokens")),
            completion_tokens=as_optional_int(usage.get("completion_tokens")),
            structured_output=structured_output,
        )
