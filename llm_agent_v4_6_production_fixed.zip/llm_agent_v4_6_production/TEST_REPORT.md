
## 10. Clean release-copy verification

После очистки source tree от caches/build/runtime state была создана release-копия и
проверена независимо:

```text
150 passed, 7 deselected
5 / 5 subprocess PASS
compileall PASS
AST errors 0
lines >100 0
```

Production ZIP формируется только из этой clean release-копии.
