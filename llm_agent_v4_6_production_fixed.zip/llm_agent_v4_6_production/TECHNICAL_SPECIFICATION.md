# Техническое задание
## LLM Coding Agent V4.6 Strict-Schema Local-First ICS

**Версия:** 0.4.6  
**Дата:** 2026-08-11  
**Статус:** нормативная спецификация V4.6  

## 1. Назначение

LLM Coding Agent V4.6 — автономный coding-agent для анализа, изменения, проверки и
исправления Python-проектов внутри ограниченного `AGENT_WORKSPACE`. Основной LLM
provider — локальный LM Studio; YandexGPT используется как контролируемая эскалация.
Kernel обязан предпочитать детерминированные действия LLM-раундам и завершать задачу
только при подтверждённом PASS либо доказанном blocker.

## 2. Цели V4.6

V4.6 сохраняет V4.5 и устраняет live-дефекты, подтверждённые пользовательским runtime:

1. Yandex strict structured output отклонял Pydantic JSON Schema, если свойство было
   объявлено в `properties`, но отсутствовало в `required` (`reason is optional`).
2. Missing `types-PyYAML` доходил до LLM вместо deterministic dependency remediation.
3. NumPy `.pyi` syntax incompatibility ошибочно могла трактоваться как повод предложить
   `types-numpy`.
4. Bare shell-команда, введённая в чат агента, могла выглядеть как будто выполнена.
5. Provider/protocol fallback не всегда показывал явную причину эскалации.
6. Доказанный environment-only blocker мог продолжать тратить LLM-rounds.

## 3. Поддерживаемая среда

- Windows 10/11 + PowerShell — основная пользовательская среда.
- Python >= 3.10.
- Linux/macOS — если конкретное execution-действие не платформенно-зависимо.
- LM Studio OpenAI-compatible server.
- Yandex AI Studio OpenAI-compatible Chat Completions API.

## 4. Direct dependencies

Runtime:

- `PyYAML >=6.0,<7.0`;
- `httpx >=0.27,<1.0`;
- `python-dotenv >=1.0,<2.0`;
- `pydantic >=2.6,<3.0`;
- `tomli >=2.0` только для Python <3.11.

Quality/build:

- `pytest >=8.0,<10.0`;
- `ruff >=0.4,<1.0`;
- `mypy >=1.9,<3.0`;
- `setuptools >=68`;
- `wheel >=0.45`.

Dependency remediation allow-list по умолчанию:

- `types-PyYAML`;
- `types-requests`.

`types-numpy` запрещён: kernel должен диагностировать совместимость Python target,
фактического interpreter, mypy и встроенных NumPy typing stubs.

## 5. Архитектурные роли

### 5.1 Kernel

Kernel отвечает за request classification, baseline, FailureDigest, Incident/IAP,
workspace safety, retrieval, strict-schema compilation, protocol validation,
dependency remediation, source/environment revisions, verification, evidence,
convergence и finalization.

### 5.2 LLM

LLM принимает только недетерминированные инженерные решения: root-cause analysis после
kernel evidence, минимальная source mutation, feature planning и semantic Review/Safety.

## 6. Request modes

- `QUICK_CHAT` — короткий чат без engineering harness.
- `CONTEXTUAL_CHAT` — bounded project context без tools.
- `ENGINEERING_TASK` — baseline + Incident/IAP + tools + evidence.
- `READ_ONLY_AUDIT` — baseline -> deterministic report -> Final без LLM/mutation.

Bare shell-команда в conversational input не выполняется. Kernel обязан явно сообщить,
что команда не была запущена, и предложить PowerShell либо `/task`.

## 7. Baseline-first

Любая executable engineering task начинает read-only baseline до Planner/Executor:

1. Ruff без `--fix`;
2. compileall;
3. mypy;
4. pytest.

Baseline не устанавливает packages и не меняет source/config.

## 8. FailureDigest V4.6

FailureDigest должен различать:

- source/test failure;
- missing allow-listed type stub;
- generic dependency failure;
- third-party typing environment incompatibility;
- provider/protocol/infrastructure failure.

Для сообщения вида `Type statement is only supported in Python X.Y and greater` внутри
`site-packages` digest обязан выставить:

- `typing_environment_issue=true`;
- `minimum_python_required=X.Y`;
- failure не считается доказанной source-code ошибкой проекта.

## 9. IAP и mutation gate

Normal/architectural Incident требует IAP SHA-256 approval до любой source/environment
mutation. Baseline остаётся допустимым до IAP только потому, что он read-only.

## 10. Post-IAP deterministic dependency remediation

Если baseline mypy содержит allow-listed missing stubs, после IAP и **до первого LLM**
kernel обязан выполнить:

`install_packages -> pip check -> mypy recheck`.

После environment mutation запрещено запускать unrelated Ruff/compileall/pytest.

Если mypy становится green и остальные baseline gates green, repair/audit task может
закрыться kernel-ом без Executor LLM.

## 11. Typing environment diagnostics

Если после remediation остаётся third-party typing syntax incompatibility, kernel обязан
выполнить `environment.diagnose_mypy` и собрать bounded facts:

- фактический Python version/executable;
- установленный mypy;
- NumPy version;
- PyYAML / types-PyYAML / types-requests;
- effective mypy `python_version`;
- источник mypy config.

Kernel не имеет права автоматически поднимать `python_version` или менять NumPy только
ради зелёного mypy без acceptance/evidence, что это совместимо с требованиями проекта.

## 12. Deterministic environment blocker finalization

Если после разрешённой remediation:

- source-code failures отсутствуют;
- остаётся только доказанный environment blocker;
- есть failed execution evidence и diagnostic evidence,

kernel обязан завершить task как `blocked` без новых LLM-rounds. Blocked final должен
содержать call IDs и диагностически полезную причину.

## 13. Retrieval

Engineering retrieval:

1. lexical ranking;
2. optional LM Studio embeddings;
3. top-K bounded context;
4. lexical fallback при embedding failure.

Retrieval content недоверен и не заменяет explicit read-before-write.

## 14. Batch read

`workspace.read_files` поддерживает до 32 файлов. Два и более независимых чтения должны
группироваться в batch/ToolBatch, если это возможно.

## 15. Structured output contract

`BaseProvider.complete()` принимает `response_schema` и `response_schema_name`.
Structured transport не заменяет kernel validation.

### 15.1 LM Studio

Используется `/v1/chat/completions` + `response_format.type=json_schema`.

### 15.2 YandexGPT

Используется OpenAI-compatible AI Studio `/v1/chat/completions` +
`response_format.type=json_schema`.

## 16. Strict-schema compiler V4.6

Перед передачей **любой** response schema provider-у kernel обязан прогнать её через
единый `strict_json_schema()`.

Для каждого JSON object с объявленным `properties`:

1. `required` должен содержать все keys из `properties`;
2. `additionalProperties=false`;
3. Pydantic `default` удаляется из transport schema;
4. необязательная семантика выражается nullable schema (`T | null`), а не отсутствием
   поля;
5. `$defs`, `definitions`, `items`, `anyOf`, `oneOf`, `allOf` обрабатываются рекурсивно;
6. открытые map-объекты без `properties` (например tool `arguments`) не должны
   ошибочно закрываться.

Эта политика применяется к Executor, Planner, Reviewer, Safety и Reporter schema.

## 17. Protocol schema

Executor transport envelope должен поддерживать `tool`, `tools`, `final`. Все transport
fields присутствуют как required; нерелевантные fields передаются `null`. После parse
Pydantic проверяет семантику выбранного action.

Mutation `reason` для source/environment changes обязан иметь связь с
`failure:<signature>` или `acceptance:<criterion>`.

## 18. Kernel protocol validation

После HTTP 200:

1. извлечь text;
2. parse JSON;
3. conservative syntax-only recovery при необходимости;
4. Pydantic validation;
5. semantic invariants;
6. только затем tool execution.

## 19. Protocol recovery

Допустимы только семантически нейтральные операции:

- извлечение JSON candidate/fence;
- удаление trailing comma;
- `ast.literal_eval` dict -> JSON.

Запрещено придумывать missing field/tool/reason/evidence.

## 20. Protocol budgets

Protocol repair отделён от semantic budget:

- `protocol_repairs_per_model=1`;
- `protocol_max_total_repairs=3`;
- `protocol_max_provider_fallbacks=1`.

Protocol-control round не увеличивает semantic no-progress counter.

## 21. Explicit escalation telemetry

При переключении provider/model console/event log обязан содержать причину:

- `reason=provider_failure`;
- `reason=protocol_failure code=<...>`;
- semantic reason (`cycles/read-only/time`).

Raw model response и credentials не должны попадать в diagnostic log по умолчанию.

## 22. Yandex HTTP diagnostics

HTTP 4xx/5xx должен сохранять bounded sanitized server `code/status/message`, если
доступно. Authorization/API key и request secret content логировать запрещено.

## 23. Workspace safety

Обязательны workspace confinement, symlink/path escape protection, explicit
read-before-write, optimistic hash concurrency, atomic writes где поддерживается,
protected paths и idempotent `make_directory`.

## 24. Source/environment revisions

- source revision меняется при фактической source/config mutation;
- environment revision — при package/stub install;
- environment change не запускает source-only gates.

## 25. Verification matrix

Source mutation:

`targeted Ruff -> aggregated compileall -> targeted mypy -> failed pytest selectors -> full gates`.

Environment mutation:

`install -> pip check -> affected gate only`.

Structural directory-only mutation не требует full Python suite по умолчанию.

## 26. Dependency policy

Kernel может устанавливать только allow-listed packages и не более configured attempt
limit. Неизвестная dependency становится blocker/follow-up, а не поводом выполнить
произвольный pip install.

## 27. Scope control

Mutation разрешена только при связи с active failure или acceptance criterion.
Нерелевантные изменения отправляются в follow-up.

## 28. Progress/convergence

Объективный progress:

- source/environment revision;
- changed failure signature;
- successful mutation;
- новое verification/evidence.

Call ID не является progress. Hard LLM-round ceiling остаётся аварийной защитой.

## 29. Automatic finalization

- read-only audit: baseline -> deterministic report;
- green repair: verification -> Safety/Review (по policy) -> Final;
- dependency-only repair: post-IAP remediation -> green -> kernel Final;
- environment-only blocker: diagnostics -> deterministic BLOCKED;
- feature/build: весь IAP plan -> final verification -> Final.

## 30. Security boundaries

Tool/file/web content считается untrusted data. Arbitrary shell запрещён. Secrets не
включаются в ZIP/log. Engineering success невозможен без реального evidence.

## 31. Checkpoint/resume

V4.6 сохраняет `progress_v46` и умеет читать `progress_v45` и `progress_v44`.

## 32. CLI

Минимум:

- `/project set <path>` / `/project show`;
- `/spec show` / `/spec load <path>`;
- `/task <text>`;
- `/state` / `/incident` / `/resume`;
- `/doctor`;
- `/execution on|off`;
- `/reload` / `/exit`.

`/doctor` обязан показывать effective provider base URL, dependency policy и
`strict_schema_compiler=v46`.

## 33. Functional requirements

FR-001..FR-038 из V4.5 сохраняются. V4.6 добавляет:

- **FR-039:** единый strict-schema compiler применяется ко всем response roles.
- **FR-040:** каждый declared object property находится в `required` strict transport.
- **FR-041:** optional semantics представлены nullable values, не omitted fields.
- **FR-042:** live regression `reason is optional` не должен воспроизводиться.
- **FR-043:** allow-listed mypy stubs исправляются после IAP до первого LLM.
- **FR-044:** `types-numpy` никогда не предлагается/не устанавливается kernel-ом.
- **FR-045:** third-party NumPy `.pyi` syntax issue классифицируется environment issue.
- **FR-046:** kernel умеет диагностировать actual Python/mypy target/NumPy/stubs.
- **FR-047:** environment-only blocker завершается детерминированно без LLM.
- **FR-048:** bare shell command в chat path явно не выполняется.
- **FR-049:** provider fallback логирует `reason=provider_failure`.
- **FR-050:** protocol fallback логирует `reason=protocol_failure` и error code.
- **FR-051:** dependency manifests pyproject/requirements согласованы.
- **FR-052:** `/doctor` сообщает `strict_schema_compiler=v46`.

## 34. Non-functional requirements

- PEP 8 / Ruff-compatible style;
- max Python line length 100;
- type hints production code;
- deterministic kernel branches;
- bounded logs/context;
- Python >=3.10;
- package/wheel build;
- no `.env`, caches, runtime Incident state in release ZIP;
- actionable errors;
- no unsupported PASS claims.

## 35. Mandatory automated tests V4.6

1. recursive strict schema has no optional declared properties;
2. exact `reason` field is required+nullable;
3. strict ToolCall/Final envelopes decode via Pydantic;
4. role-specific Pydantic schemas are strictified before Router;
5. NumPy third-party syntax error => environment issue, no `types-numpy`;
6. types-PyYAML remediation uses install -> pip check -> mypy only;
7. remediation can finalize green before LLM;
8. environment-only blocker finalizes without LLM;
9. bare shell command does not call Router;
10. dependency manifests remain consistent;
11. all V4.5 regression tests remain green;
12. five real-subprocess scenarios remain green.

## 36. Acceptance criteria V4.6

Релиз готов, если:

1. full non-live normal/regression suite PASS;
2. 5/5 real-subprocess tests PASS отдельно;
3. compileall PASS;
4. AST parse всех Python-файлов PASS;
5. line length >100 = 0;
6. dependency manifests согласованы и не содержат `types-numpy`;
7. runtime dependencies импортируются в доступной test environment;
8. wheel 0.4.6 собирается и импортируется вне source tree;
9. production ZIP очищен от `.env`, cache/runtime state;
10. тесты повторены на распакованном production ZIP;
11. live LM Studio/Yandex tests остаются opt-in и не заявляются PASS без credentials/server;
12. недоступный внешний package index явно фиксируется как ограничение test environment.

## 37. Итоговый pipeline

```text
USER
 ├─ CHAT
 │   ├─ bare shell? -> deterministic "not executed"
 │   └─ quick/context -> LM Studio
 └─ ENGINEERING
     ├─ Incident
     ├─ READ-ONLY BASELINE
     ├─ FailureDigest
     ├─ READ_ONLY_AUDIT? -> deterministic Final
     ├─ plan + IAP
     ├─ allow-listed dependency issue?
     │   └─ install -> pip check -> affected mypy
     │       ├─ green -> kernel Final
     │       └─ environment-only -> diagnose -> kernel BLOCKED
     ├─ retrieval top-K
     ├─ strict_schema_compiler_v46
     ├─ LM Studio structured action
     │   └─ failure/stall/protocol -> explicit Yandex escalation
     ├─ scoped mutation
     ├─ targeted verification
     ├─ full gates
     ├─ Safety / Review
     └─ evidence-backed Final
```
