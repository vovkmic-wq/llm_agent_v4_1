# DEPENDENCY AUDIT — LLM Coding Agent V4.6

**Version:** 0.4.6  
**Date:** 2026-08-11

## Manifest consistency

`pyproject.toml` и `requirements.txt` проверены автоматически regression-тестом.
Runtime dependencies из `pyproject.toml` присутствуют в `requirements.txt` с теми же
version constraints. `types-numpy` отсутствует в direct dependencies и remediation
allow-list.

## Runtime ranges

- PyYAML >=6.0,<7.0
- httpx >=0.27,<1.0
- python-dotenv >=1.0,<2.0
- pydantic >=2.6,<3.0
- tomli >=2.0 только для Python <3.11

Dev/build:

- pytest >=8.0,<10.0
- mypy >=1.9,<3.0
- ruff >=0.4,<1.0
- setuptools >=68
- wheel >=0.45

## Available test-environment verification

Фактически обнаружено в release sandbox:

- Python 3.13.5;
- PyYAML 6.0.3 — удовлетворяет range;
- httpx 0.28.1 — удовлетворяет range;
- python-dotenv 1.2.2 — удовлетворяет range;
- pydantic 2.13.4 — удовлетворяет range;
- pytest 9.0.2 — удовлетворяет range;
- runtime imports — PASS.

Mypy и Ruff не были установлены в базовом sandbox environment. Была выполнена реальная
попытка создать изолированный venv и установить `requirements.txt`; package index был
недоступен из-за DNS (`Temporary failure in name resolution`). Поэтому отдельный прямой
Ruff/mypy run в этой среде не заявляется как PASS.

## Remediation policy

Автоматическая установка ограничена:

- types-PyYAML;
- types-requests.

`types-numpy` намеренно запрещён. NumPy typing incompatibility диагностируется через
actual Python, mypy target и NumPy version вместо установки внешних stubs.
