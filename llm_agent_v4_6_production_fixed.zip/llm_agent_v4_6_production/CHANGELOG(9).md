# CHANGELOG

## 0.4.6 — 2026-08-11

### Strict structured schema

- Добавлен единый recursive `core/structured_schema.py`.
- Для strict transport каждый declared object field входит в `required`.
- Optional semantics представлены nullable values; Pydantic defaults удаляются из transport schema.
- Исправлен live Yandex defect `Invalid JSON Schema: all fields must be required, 'reason' is optional`.
- Strict compiler применяется ко всем provider-facing response schemas, включая Planner/Reviewer/Safety.

### Deterministic dependency remediation

- После IAP missing allow-listed mypy stubs исправляются до первого LLM: `install -> pip check -> mypy`.
- Добавлен `environment.diagnose_mypy` для actual Python, mypy target, NumPy и stub versions.
- NumPy `.pyi` Python-syntax incompatibility классифицируется как environment issue.
- `types-numpy` запрещён в remediation и tool instructions.
- Environment-only blocker завершается kernel-ом без дополнительных LLM-rounds.

### CLI and telemetry

- Bare shell-команда в chat path явно не выполняется и не отправляется LLM как инструкция к исполнению.
- Provider fallback пишет `[ESCALATE] ... reason=provider_failure`.
- Protocol fallback пишет `[ESCALATE] ... reason=protocol_failure code=...`.
- `/doctor` показывает `strict_schema_compiler=v46`.
- Checkpoint пишет `progress_v46` с backward read `progress_v45`/`progress_v44`.

### Dependencies and tests

- Dependency manifests синхронизированы; package version повышен до `0.4.6`.
- Добавлены `tests/test_v46_strict_schema_and_dependencies.py` и `tests/test_v46_dependency_manifest.py`.
- Сохранены все V4.5 regression/live opt-in tests.

## 0.4.5 — 2026-08-11

### Protocol hardening

- Добавлен provider-native structured output через JSON Schema.
- LM Studio/OpenAI-compatible использует `response_format=json_schema`.
- YandexGPT получает structured JSON schema request.
- Transport schema дополняется обязательной Pydantic validation в kernel.
- Planner, Executor, Reviewer и Safety Officer получают собственные response schema.

### Read-only audit

- Добавлен deterministic `READ_ONLY_AUDIT` fast-path.
- Явные запросы «ничего не изменяй/только проверь» завершаются из baseline evidence
  без Executor, ToolCall, embedding retrieval и protocol fallback.
- Добавлена отдельная `ReporterAnswer` schema для tool-free отчётов.

### Protocol recovery and budgets

- Добавлено conservative syntax-only JSON recovery (trailing comma / safe literal).
- Добавлена безопасная protocol diagnostics telemetry без raw response.
- Protocol repair/fallback budget отделён от semantic Incident/no-progress budget.
- Repair-round не увеличивает semantic LLM round.

### Tool protocol consistency

- Structured mode передаёт небольшие patch/content непосредственно в JSON arguments.
- Raw PAYLOAD оставлен только как legacy fallback для provider без structured output.
- Устранено противоречие между system prompt и ToolRegistry instructions.

### Compatibility

- Resume читает `progress_v45`, но сохраняет fallback на `progress_v44`.
- Baseline-first, retrieval, batch read, source/environment revisions, scope control,
  Safety/Review и convergence V4.4 сохранены.

### Tests

- Добавлен `tests/test_v45_protocol_hardening.py`.
- Добавлены opt-in live structured-output tests LM Studio/Yandex.

## 0.4.4 — 2026-08-09

- Deterministic read-only baseline до LLM для engineering task.
- Compact lexical/embedding retrieval, batch read и incident-wide progress cache.
- Source/environment verification matrix и deterministic dependency remediation.
- Scope reason, convergence guards, Safety/Review evidence finalization.

## 0.4.3 — 2026-08-09

- LM Studio timeout 360 seconds.
- Lightweight quick/context chat.
- One LM Studio transport attempt before provider fallback.
- Local-first semantic escalation to YandexGPT.

### 0.4.5 live-fix — 2026-08-11 (version unchanged)

- YandexGPT migrated to the current OpenAI-compatible AI Studio Chat Completions transport.
- Official legacy `foundationModels/v1` base URL auto-migrates to the current endpoint.
- Structured Yandex output now uses `response_format.type=json_schema`.
- Added bounded sanitized HTTP 4xx server diagnostics without credentials.
- Updated live/unit regression tests and `.env.example`; version remains `0.4.5`.
