# ARCHITECTURE — LLM Coding Agent V4.6 Strict-Schema Local-First ICS

## Kernel-first pipeline

```text
request classifier
  ├─ chat -> shell guard / compact LM Studio
  └─ engineering
       ├─ Incident
       ├─ read-only baseline
       ├─ FailureDigest
       ├─ read-only audit fast path
       ├─ deterministic plan + IAP
       ├─ dependency remediation before LLM
       ├─ typing environment diagnostics / blocker finalization
       ├─ retrieval top-K
       ├─ strict-schema compiler
       ├─ LM Studio -> explicit Yandex fallback
       ├─ scoped mutation
       ├─ targeted/full verification
       └─ Safety/Review/Final
```

## Strict-schema compiler

`core/structured_schema.py` — единая transport-компиляция JSON Schema. Все объекты с
`properties` закрываются `additionalProperties=false`, а `required` равен полному набору
properties. Nullable семантика сохраняется через schema union с `null`. Открытые maps
вроде tool `arguments` остаются открытыми.

Это устраняет класс Yandex live errors, когда Pydantic default делал поле transport-
optional, хотя strict provider требует его присутствия.

## Dependency remediation

Baseline read-only. После IAP missing allow-listed mypy stubs проходят механически:

```text
install_packages -> pip_check -> mypy
```

Ни Ruff, ни compileall, ни unrelated pytest после environment mutation не запускаются.

При third-party `.pyi` syntax incompatibility kernel выполняет `environment.diagnose_mypy`
и отделяет environment blocker от source failure. `types-numpy` не используется.

## Deterministic blocker finalization

Если code failures нет, а остаётся доказанный environment blocker с failed execution
evidence, task завершается `blocked` без LLM. Incident остаётся в BLOCKED state и может
быть продолжен `/resume` после исправления окружения.

## Protocol fallback

Console/event telemetry различает:

- semantic stall;
- provider failure;
- protocol failure + code.

Protocol repair budget не смешивается с semantic no-progress budget.

## Checkpoint compatibility

V4.6 пишет `progress_v46`, читает также `progress_v45` и `progress_v44`.
