"""LM Studio provider through its OpenAI-compatible local HTTP API."""
from __future__ import annotations

import time
from typing import Any

import httpx

from providers.base import CompletionResult, ProviderCapabilities, ProviderError
from providers.http_utils import json_object, provider_http_error
from providers.openai_compatible import OpenAICompatibleProvider


class LMStudioProvider(OpenAICompatibleProvider):
    """Local-first provider for LM Studio.

    LM Studio exposes an OpenAI-compatible API, typically at
    ``http://localhost:1234/v1``. Authentication is optional and can be enabled
    in LM Studio; when ``LMSTUDIO_API_KEY`` is set it is sent as a Bearer token.
    """

    provider_name = "lmstudio"
    supports_structured_output = True
    requires_api_key = False

    def __init__(self, api_key: str | None, base_url: str | None) -> None:
        super().__init__(api_key, base_url)
        self.capability_cache_ttl_seconds = 300.0
        self.circuit_breaker_cooldown_seconds = 300.0
        self._capability_cache: dict[
            tuple[str, str, str], ProviderCapabilities
        ] = {}
        self._circuit_open_until = 0.0
        self._last_model_load_failure: str | None = None

    @property
    def _server_root(self) -> str:
        base = (self.base_url or "").rstrip("/")
        return base[:-3] if base.endswith("/v1") else base

    @staticmethod
    def _items(payload: dict[str, Any]) -> list[dict[str, Any]]:
        for key in ("models", "data"):
            value = payload.get(key)
            if isinstance(value, list):
                return [item for item in value if isinstance(item, dict)]
        return []

    @staticmethod
    def _model_id(item: dict[str, Any]) -> str:
        for key in ("key", "id", "model", "name"):
            value = item.get(key)
            if isinstance(value, str) and value:
                return value
        return ""

    @staticmethod
    def _positive_int(value: Any) -> int | None:
        try:
            converted = int(value)
        except (TypeError, ValueError):
            return None
        return converted if converted > 0 else None

    def _request_models(self, endpoint: str) -> dict[str, Any]:
        headers: dict[str, str] = {"Accept": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        try:
            response = httpx.get(
                f"{self._server_root}{endpoint}",
                headers=headers,
                timeout=min(float(self.timeout_seconds), 5.0),
            )
            response.raise_for_status()
        except httpx.HTTPError as exc:
            raise provider_http_error(self.provider_name, exc) from exc
        return json_object(response, self.provider_name)

    def _capabilities_from_item(
        self,
        model_name: str,
        item: dict[str, Any],
        source: str,
    ) -> ProviderCapabilities:
        loaded_instances = item.get("loaded_instances")
        loaded_item: dict[str, Any] | None = None
        if isinstance(loaded_instances, list):
            loaded_item = next(
                (entry for entry in loaded_instances if isinstance(entry, dict)),
                None,
            )
        config = loaded_item.get("config", {}) if loaded_item else {}
        if not isinstance(config, dict):
            config = {}
        max_context = self._positive_int(
            item.get("max_context_length", item.get("max_context_tokens"))
        )
        loaded_context = self._positive_int(
            config.get(
                "context_length",
                item.get("loaded_context_length", item.get("context_length")),
            )
        )
        effective_values = [
            value for value in (max_context, loaded_context) if value is not None
        ]
        state_value = item.get("state", item.get("status"))
        state = str(state_value) if state_value is not None else None
        ready = bool(loaded_item) or (state or "").casefold() in {
            "loaded",
            "ready",
            "running",
        }
        quantization_value = item.get("quantization")
        if isinstance(quantization_value, dict):
            quantization_value = quantization_value.get("name")
        return ProviderCapabilities(
            provider=self.provider_name,
            base_url=self.base_url or "",
            model_id=model_name,
            display_name=(
                str(item["display_name"])
                if item.get("display_name") is not None
                else str(item["name"])
                if item.get("name") is not None
                else None
            ),
            quantization=(
                str(quantization_value) if quantization_value is not None else None
            ),
            state=state,
            ready=ready,
            max_context_tokens=max_context,
            loaded_context_tokens=loaded_context,
            effective_context_tokens=min(effective_values) if effective_values else None,
            source=source,
            discovered_at=time.time(),
        )

    def discover_capabilities(
        self,
        model_name: str,
        *,
        force: bool = False,
    ) -> ProviderCapabilities:
        key = (self.provider_name, self.base_url or "", model_name)
        cached = self._capability_cache.get(key)
        if (
            not force
            and cached is not None
            and cached.cache_age_seconds < self.capability_cache_ttl_seconds
        ):
            return cached

        errors: list[ProviderError] = []
        for endpoint in ("/api/v1/models", "/api/v0/models"):
            try:
                payload = self._request_models(endpoint)
            except ProviderError as exc:
                errors.append(exc)
                continue
            item = next(
                (entry for entry in self._items(payload) if self._model_id(entry) == model_name),
                None,
            )
            if item is not None:
                capabilities = self._capabilities_from_item(model_name, item, endpoint)
                self._capability_cache[key] = capabilities
                return capabilities

        # /v1/models is an exact-ID existence check only; it must not invent limits.
        try:
            payload = self._request_models("/v1/models")
        except ProviderError as exc:
            errors.append(exc)
        else:
            if any(self._model_id(item) == model_name for item in self._items(payload)):
                capabilities = ProviderCapabilities(
                    provider=self.provider_name,
                    base_url=self.base_url or "",
                    model_id=model_name,
                    source="/v1/models:id_only",
                    discovered_at=time.time(),
                )
                self._capability_cache[key] = capabilities
                return capabilities

        if errors and len(errors) == 3:
            raise errors[-1]
        raise ProviderError(
            f"lmstudio: configured model ID '{model_name}' отсутствует в API",
            retryable=False,
            code="configured_model_not_found",
        )

    def note_context_limit(self, model_name: str, limit: int) -> None:
        if limit <= 0:
            return
        key = (self.provider_name, self.base_url or "", model_name)
        current = self._capability_cache.get(key)
        if current is None:
            current = ProviderCapabilities(
                provider=self.provider_name,
                base_url=self.base_url or "",
                model_id=model_name,
                discovered_at=time.time(),
            )
        theoretical = current.max_context_tokens
        effective = min(
            value
            for value in (theoretical, current.loaded_context_tokens, limit)
            if value is not None
        )
        self._capability_cache[key] = ProviderCapabilities(
            provider=current.provider,
            base_url=current.base_url,
            model_id=current.model_id,
            display_name=current.display_name,
            quantization=current.quantization,
            state=current.state,
            ready=current.ready,
            max_context_tokens=theoretical,
            loaded_context_tokens=current.loaded_context_tokens,
            effective_context_tokens=effective,
            source="provider_error:context_length_exceeded",
            discovered_at=time.time(),
        )

    def complete(self, **kwargs: Any) -> CompletionResult:
        now = time.monotonic()
        if now < self._circuit_open_until:
            raise ProviderError(
                "lmstudio: model-load circuit breaker открыт",
                retryable=False,
                code="model_load_circuit_open",
            )
        try:
            return super().complete(**kwargs)
        except ProviderError as exc:
            if exc.code == "model_load_failure":
                self._last_model_load_failure = str(exc)
                self._circuit_open_until = (
                    time.monotonic() + self.circuit_breaker_cooldown_seconds
                )
            raise

    def circuit_diagnostic(self) -> dict[str, Any]:
        remaining = max(0.0, self._circuit_open_until - time.monotonic())
        return {
            "status": "open" if remaining > 0 else "closed",
            "cooldown_seconds": self.circuit_breaker_cooldown_seconds,
            "remaining_seconds": round(remaining, 3),
            "last_failure": self._last_model_load_failure,
        }
