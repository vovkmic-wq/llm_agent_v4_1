"""Базовые типы LLM-провайдеров."""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from time import time
from typing import Any


class ProviderError(RuntimeError):
    """Ошибка вызова LLM-провайдера.

    ``retryable`` позволяет Router не тратить повторные попытки на постоянные
    ошибки конфигурации/авторизации/валидации запроса.
    """

    def __init__(
        self,
        message: str,
        *,
        retryable: bool = True,
        code: str = "provider_error",
        context_limit: int | None = None,
    ) -> None:
        super().__init__(message)
        self.retryable = retryable
        self.code = code
        self.context_limit = context_limit


@dataclass(frozen=True)
class ProviderCapabilities:
    """Machine-discovered provider/model limits used by the request guard."""

    provider: str
    base_url: str
    model_id: str
    display_name: str | None = None
    quantization: str | None = None
    state: str | None = None
    ready: bool | None = None
    max_context_tokens: int | None = None
    loaded_context_tokens: int | None = None
    effective_context_tokens: int | None = None
    source: str = "unknown"
    discovered_at: float = 0.0

    @property
    def cache_age_seconds(self) -> float:
        return max(0.0, time() - self.discovered_at)

    def diagnostic(self) -> dict[str, Any]:
        return {
            "model_id": self.model_id,
            "display_name": self.display_name,
            "quantization": self.quantization,
            "state": self.state,
            "ready": self.ready,
            "max_context_tokens": self.max_context_tokens,
            "loaded_context_tokens": self.loaded_context_tokens,
            "effective_context_tokens": self.effective_context_tokens,
            "capability_source": self.source,
            "cache_age_seconds": round(self.cache_age_seconds, 3),
        }


@dataclass(frozen=True)
class CompletionResult:
    text: str
    raw_model_name: str
    usage_tokens: int | None = None
    finish_reason: str | None = None
    prompt_tokens: int | None = None
    completion_tokens: int | None = None
    duration_seconds: float | None = None
    structured_output: str | None = None


class BaseProvider(ABC):
    provider_name: str = "base"
    supports_structured_output: bool = False
    timeout_seconds: float = 120.0
    max_attempts: int = 3
    capability_cache_ttl_seconds: float = 300.0
    circuit_breaker_cooldown_seconds: float = 300.0

    def __init__(self, api_key: str | None, base_url: str | None) -> None:
        self.api_key = api_key
        self.base_url = base_url.rstrip("/") if base_url else None

    def discover_capabilities(
        self,
        model_name: str,
        *,
        force: bool = False,
    ) -> ProviderCapabilities:
        """Return known limits. Providers with no metadata stay explicitly unknown."""
        del force
        return ProviderCapabilities(
            provider=self.provider_name,
            base_url=self.base_url or "",
            model_id=model_name,
            source="provider_metadata_unavailable",
            discovered_at=time(),
        )

    def note_context_limit(self, model_name: str, limit: int) -> None:
        """Accept a provider-confirmed runtime limit when a provider supports caching."""
        del model_name, limit

    def circuit_diagnostic(self) -> dict[str, Any]:
        return {
            "status": "unsupported",
            "cooldown_seconds": None,
            "remaining_seconds": 0.0,
            "last_failure": None,
        }

    @abstractmethod
    def is_configured(self) -> bool:
        """True, если есть всё необходимое для вызова."""

    @abstractmethod
    def complete(
        self,
        *,
        model_name: str,
        system_prompt: str,
        messages: list[dict[str, str]],
        temperature: float = 0.15,
        max_tokens: int = 8192,
        response_schema: dict[str, Any] | None = None,
        response_schema_name: str = "response",
    ) -> CompletionResult:
        """Выполнить запрос и вернуть нормализованный результат."""
