"""Model routing, provider retry and explicit protocol-fallback support."""
from __future__ import annotations

import os
import time
from dataclasses import dataclass, replace
from typing import Any

from core.config import settings
from core.logger import console_logger, log_request
from providers.anthropic_provider import AnthropicProvider
from providers.base import (
    BaseProvider,
    CompletionResult,
    ProviderCapabilities,
    ProviderError,
)
from providers.deepseek_provider import DeepSeekProvider
from providers.gemini_provider import GeminiProvider
from providers.gigachat_provider import GigaChatProvider
from providers.lmstudio_provider import LMStudioProvider
from providers.ollama_provider import OllamaProvider
from providers.openai_provider import OpenAIProvider
from providers.qwen_provider import QwenProvider
from providers.yandexgpt_provider import YandexGPTProvider

_PROVIDER_CLASSES: dict[str, type[BaseProvider]] = {
    "anthropic": AnthropicProvider,
    "openai": OpenAIProvider,
    "gemini": GeminiProvider,
    "deepseek": DeepSeekProvider,
    "ollama": OllamaProvider,
    "lmstudio": LMStudioProvider,
    "qwen": QwenProvider,
}
_provider_instances: dict[str, BaseProvider] = {}


@dataclass(frozen=True)
class RequestBudget:
    model_id: str
    resolved_model_id: str
    effective_context_tokens: int | None
    effective_input_budget: int
    output_reserve_tokens: int
    safety_margin_tokens: int
    capabilities: ProviderCapabilities


def clear_provider_cache() -> None:
    """Drop cached provider objects after configuration/environment reload."""
    _provider_instances.clear()


def _build_provider(provider_name: str) -> BaseProvider:
    if provider_name in _provider_instances:
        return _provider_instances[provider_name]
    entry = settings.models.providers.get(provider_name)
    if entry is None:
        raise ProviderError(f"Провайдер '{provider_name}' не описан в models.yaml")
    if not entry.enabled:
        raise ProviderError(f"Провайдер '{provider_name}' отключён в models.yaml")

    api_key = settings.provider_api_key(provider_name)
    base_url = settings.provider_base_url(provider_name)
    if provider_name == "gigachat":
        instance: BaseProvider = GigaChatProvider(api_key, base_url, entry.auth_url)
    elif provider_name == "yandexgpt":
        instance = YandexGPTProvider(api_key, base_url, entry.folder_id_env)
    elif provider_name == "ollama":
        instance = OllamaProvider(api_key, (base_url or "").rstrip("/") + "/v1")
    elif provider_name == "lmstudio":
        instance = LMStudioProvider(api_key, base_url)
    else:
        provider_cls = _PROVIDER_CLASSES.get(provider_name)
        if provider_cls is None:
            raise ProviderError(f"Нет реализации провайдера '{provider_name}'")
        instance = provider_cls(api_key, base_url)
    # Provider-specific runtime policy is data-driven from models.yaml.
    # This lets a slow local model use a longer timeout without making cloud
    # providers equally slow, and lets provider failures fall through after a
    # different number of transport retries.
    if entry.timeout_seconds is not None:
        instance.timeout_seconds = float(entry.timeout_seconds)
    if entry.max_attempts is not None:
        instance.max_attempts = int(entry.max_attempts)
    if entry.capability_cache_ttl_seconds is not None:
        instance.capability_cache_ttl_seconds = float(
            entry.capability_cache_ttl_seconds
        )
    if entry.circuit_breaker_cooldown_seconds is not None:
        instance.circuit_breaker_cooldown_seconds = float(
            entry.circuit_breaker_cooldown_seconds
        )
    _provider_instances[provider_name] = instance
    return instance


def resolve_model_id(model_id: str) -> tuple[BaseProvider, str]:
    if ":" not in model_id:
        raise ProviderError(
            f"Некорректный формат модели: '{model_id}' (ожидается provider:alias)"
        )
    provider_name, alias = model_id.split(":", 1)
    entry = settings.models.providers.get(provider_name)
    if entry is None:
        raise ProviderError(f"Провайдер '{provider_name}' не найден в models.yaml")
    real_model_name = entry.models.get(alias)
    if real_model_name is None:
        raise ProviderError(f"Алиас '{alias}' не найден у провайдера '{provider_name}'")
    if real_model_name.startswith("${") and real_model_name.endswith("}"):
        env_name = real_model_name[2:-1].strip()
        resolved = os.environ.get(env_name, "").strip()
        if not resolved:
            raise ProviderError(
                f"Для модели '{model_id}' не задана переменная {env_name}",
                retryable=False,
            )
        real_model_name = resolved
    return _build_provider(provider_name), real_model_name


def choose_model(tags: list[str] | None = None) -> str:
    tags = tags or []
    for rule in settings.models.routing.rules:
        rule_tags = rule.match.get("tags", [])
        if any(tag in tags for tag in rule_tags):
            return rule.model
    return settings.models.routing.default


class Router:
    def __init__(self) -> None:
        self.routing_cfg = settings.models.routing
        self._confirmed_context_limits: dict[tuple[str, str, str], int] = {}

    @staticmethod
    def _capability_key(
        provider: BaseProvider,
        real_model_name: str,
    ) -> tuple[str, str, str]:
        return provider.provider_name, provider.base_url or "", real_model_name

    def capabilities(
        self,
        model_id: str,
        *,
        force: bool = False,
    ) -> ProviderCapabilities:
        provider, real_model_name = resolve_model_id(model_id)
        capabilities = provider.discover_capabilities(real_model_name, force=force)
        confirmed = self._confirmed_context_limits.get(
            self._capability_key(provider, real_model_name)
        )
        if confirmed is None:
            return capabilities
        known = capabilities.effective_context_tokens
        effective = min(known, confirmed) if known is not None else confirmed
        return replace(
            capabilities,
            effective_context_tokens=effective,
            source="provider_error:context_length_exceeded",
        )

    def request_budget(
        self,
        model_id: str,
        *,
        internal_input_limit: int,
        output_reserve_tokens: int,
        safety_margin_tokens: int,
    ) -> RequestBudget:
        _, real_model_name = resolve_model_id(model_id)
        capabilities = self.capabilities(model_id)
        effective_context = capabilities.effective_context_tokens
        provider_input_budget = internal_input_limit
        if effective_context is not None:
            provider_input_budget = (
                effective_context - output_reserve_tokens - safety_margin_tokens
            )
            if provider_input_budget <= 0:
                raise ProviderError(
                    "Резерв ответа и safety margin исчерпывают context window "
                    f"модели '{model_id}'",
                    retryable=False,
                    code="context_budget_invalid",
                    context_limit=effective_context,
                )
        # Internal policy can only narrow a discovered provider limit.
        input_budget = min(internal_input_limit, provider_input_budget)
        return RequestBudget(
            model_id=model_id,
            resolved_model_id=real_model_name,
            effective_context_tokens=effective_context,
            effective_input_budget=input_budget,
            output_reserve_tokens=output_reserve_tokens,
            safety_margin_tokens=safety_margin_tokens,
            capabilities=capabilities,
        )

    def note_context_limit(self, model_id: str, limit: int) -> None:
        if limit <= 0:
            return
        provider, real_model_name = resolve_model_id(model_id)
        key = self._capability_key(provider, real_model_name)
        previous = self._confirmed_context_limits.get(key)
        self._confirmed_context_limits[key] = min(previous, limit) if previous else limit
        provider.note_context_limit(real_model_name, limit)

    def provider_diagnostic(self, model_id: str) -> dict[str, Any]:
        provider, real_model_name = resolve_model_id(model_id)
        capabilities = self.capabilities(model_id)
        budget = self.request_budget(
            model_id,
            internal_input_limit=settings.agent.memory.max_context_tokens,
            output_reserve_tokens=settings.agent.generation.executor_local.max_tokens,
            safety_margin_tokens=settings.agent.context_budget.safety_margin_tokens,
        )
        return {
            "configured_model_id": model_id,
            "resolved_model_id": real_model_name,
            **capabilities.diagnostic(),
            "effective_input_budget": budget.effective_input_budget,
            "output_reserve_tokens": budget.output_reserve_tokens,
            "safety_margin_tokens": budget.safety_margin_tokens,
            "circuit_breaker": provider.circuit_diagnostic(),
        }

    def candidates(
        self,
        primary: str,
        *,
        protocol_chain: list[str] | None = None,
    ) -> list[str]:
        chain = protocol_chain or self.routing_cfg.fallback_chain
        result: list[str] = []
        for model in [primary, *chain]:
            if model and model not in result:
                result.append(model)
        return result

    def call(
        self,
        *,
        model_id: str,
        system_prompt: str,
        messages: list[dict[str, str]],
        temperature: float = 0.15,
        max_tokens: int = 8192,
        allow_fallback: bool = True,
        response_schema: dict[str, Any] | None = None,
        response_schema_name: str = "response",
    ) -> CompletionResult:
        candidates = (
            self.candidates(model_id) if allow_fallback else [model_id]
        )
        last_error: ProviderError | None = None
        for candidate in candidates:
            try:
                return self._call_with_retry(
                    candidate,
                    system_prompt,
                    messages,
                    temperature=temperature,
                    max_tokens=max_tokens,
                    response_schema=response_schema,
                    response_schema_name=response_schema_name,
                )
            except ProviderError as exc:
                console_logger.warning(
                    "Модель '%s' недоступна (%s), пробуем следующую", candidate, exc
                )
                if not allow_fallback:
                    raise
                last_error = exc
        raise ProviderError(
            "Все модели из fallback-цепочки недоступны. "
            f"Последняя ошибка: {last_error}",
            retryable=last_error.retryable if last_error is not None else False,
            code=last_error.code if last_error is not None else "provider_unavailable",
            context_limit=(
                last_error.context_limit if last_error is not None else None
            ),
        )

    def _call_with_retry(
        self,
        model_id: str,
        system_prompt: str,
        messages: list[dict[str, str]],
        *,
        temperature: float,
        max_tokens: int,
        response_schema: dict[str, Any] | None = None,
        response_schema_name: str = "response",
    ) -> CompletionResult:
        provider, real_model_name = resolve_model_id(model_id)
        max_attempts = int(
            getattr(
                provider,
                "max_attempts",
                self.routing_cfg.retry.get("max_attempts", 3),
            )
        )
        backoff = float(self.routing_cfg.retry.get("backoff_seconds", 2))
        if not provider.is_configured():
            raise ProviderError(
                f"Провайдер '{provider.provider_name}' не настроен (нет ключа/URL)"
            )

        last_error: ProviderError | None = None
        for attempt in range(1, max_attempts + 1):
            start = time.monotonic()
            try:
                complete_kwargs: dict[str, Any] = {
                    "model_name": real_model_name,
                    "system_prompt": system_prompt,
                    "messages": messages,
                    "temperature": temperature,
                    "max_tokens": max_tokens,
                }
                if response_schema is not None and provider.supports_structured_output:
                    complete_kwargs["response_schema"] = response_schema
                    complete_kwargs["response_schema_name"] = response_schema_name
                result = provider.complete(**complete_kwargs)
                duration = time.monotonic() - start
                log_request(
                    model=model_id,
                    query=messages[-1]["content"] if messages else "",
                    success=True,
                    duration_seconds=duration,
                )
                return replace(result, duration_seconds=duration)
            except ProviderError as exc:
                last_error = exc
                log_request(
                    model=model_id,
                    query=messages[-1]["content"] if messages else "",
                    success=False,
                    duration_seconds=time.monotonic() - start,
                    error=str(exc),
                )
                if not exc.retryable:
                    raise
                if attempt < max_attempts:
                    delay = min(backoff * (2 ** (attempt - 1)), 30.0)
                    time.sleep(delay)
        raise ProviderError(
            f"'{model_id}' не ответил после {max_attempts} попыток: {last_error}",
            retryable=getattr(last_error, "retryable", True),
            code=last_error.code if last_error is not None else "provider_unavailable",
            context_limit=(
                last_error.context_limit if last_error is not None else None
            ),
        )
