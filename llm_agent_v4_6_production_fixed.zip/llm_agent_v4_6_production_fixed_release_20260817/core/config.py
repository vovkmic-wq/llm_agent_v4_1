"""Загрузка .env и строго типизированной YAML-конфигурации Agent V4."""
from __future__ import annotations

import os
from importlib.resources import files
from pathlib import Path
from typing import Any, Literal

import yaml
from dotenv import load_dotenv
from pydantic import BaseModel, Field

PROJECT_DIR = Path(__file__).resolve().parent.parent
CONFIG_DIR = Path(os.environ.get("AGENT_CONFIG_DIR", PROJECT_DIR / "config")).expanduser()
_default_env = Path.cwd() / ".env"
ENV_FILE = Path(
    os.environ.get(
        "AGENT_ENV_FILE",
        _default_env if _default_env.exists() else PROJECT_DIR / ".env",
    )
).expanduser()
load_dotenv(ENV_FILE, override=False)
STATE_DIR = Path(
    os.environ.get("AGENT_STATE_DIR", Path.home() / ".llm_agent_v4")
).expanduser().resolve()


def _load_yaml(filename: str) -> dict[str, Any]:
    path = CONFIG_DIR / filename
    if path.exists():
        with path.open("r", encoding="utf-8") as stream:
            return yaml.safe_load(stream) or {}
    # A wheel is a ZIP import location, so ``Path(__file__) / config`` is not a
    # real directory. Packaged YAML remains readable through importlib.resources.
    try:
        resource = files("config").joinpath(filename)
        with resource.open("r", encoding="utf-8") as stream:
            return yaml.safe_load(stream) or {}
    except (FileNotFoundError, ModuleNotFoundError) as exc:
        raise FileNotFoundError(f"Конфиг не найден: {path}") from exc


def env_bool(name: str, default: bool = False) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on", "да"}


class MemoryConfig(BaseModel):
    use_context: bool = True
    use_summary: bool = True
    last_messages: int = 8
    max_context_tokens: int = 8000
    loop_reserve_tokens: int = 2000
    project_context_chars: int = 14000
    summary_chars: int = 4000
    long_term_context_chars: int = 5000


class SummarizationConfig(BaseModel):
    enabled: bool = True
    trigger_after_messages: int = 30
    summarizer_model: str = "yandexgpt:yandex-lite"


class WorkspaceConfig(BaseModel):
    enabled: bool = True
    root_env: str = "AGENT_WORKSPACE_DIR"
    max_file_size_bytes: int = 2_000_000
    max_list_entries: int = 1000
    max_model_list_entries: int = Field(default=200, ge=1)
    max_model_list_chars: int = Field(default=12000, ge=1000)
    validate_on_write: bool = True
    protected_globs: list[str] = Field(
        default_factory=lambda: [
            ".env",
            ".env.*",
            "*.pem",
            "*.key",
            "*.p12",
            "*.pfx",
            "secrets.*",
            ".git",
            ".git/*",
            ".git/**",
            ".venv",
            ".venv/*",
            ".venv/**",
            "venv",
            "venv/*",
            "venv/**",
        ]
    )
    ignored_globs: list[str] = Field(
        default_factory=lambda: [
            "__pycache__",
            "__pycache__/*",
            "__pycache__/**",
            ".pytest_cache",
            ".pytest_cache/*",
            ".pytest_cache/**",
            ".mypy_cache",
            ".mypy_cache/*",
            ".mypy_cache/**",
            ".ruff_cache",
            ".ruff_cache/*",
            ".ruff_cache/**",
            ".tox",
            ".tox/*",
            ".tox/**",
            ".nox",
            ".nox/*",
            ".nox/**",
            "node_modules",
            "node_modules/*",
            "node_modules/**",
            "build",
            "build/*",
            "build/**",
            "dist",
            "dist/*",
            "dist/**",
        ]
    )


class ExecutionConfig(BaseModel):
    enabled_env: str = "AGENT_ALLOW_CODE_EXECUTION"
    timeout_seconds: int = 120
    max_output_chars: int = 40_000
    allow_terminal_compat: bool = True


class ResearchConfig(BaseModel):
    enabled_env: str = "AGENT_ALLOW_RESEARCH"
    allowed_domains: list[str] = Field(default_factory=list)
    timeout_seconds: int = 20
    max_response_bytes: int = 500_000


class IncidentConfig(BaseModel):
    enabled: bool = True
    approval_mode: Literal["kernel", "human"] = "kernel"
    max_period_rounds: int = 12
    max_periods: int = 4
    max_plan_revisions: int = 4
    max_safety_stops: int = 4
    max_read_only_rounds: int = 4
    max_no_progress_rounds: int = 3


class ChatConfig(BaseModel):
    quick_max_query_chars: int = 240
    recent_messages: int = 4
    quick_max_context_tokens: int = 1200
    contextual_max_context_tokens: int = 3200
    contextual_project_chars: int = 3500
    quick_markers: list[str] = Field(
        default_factory=lambda: [
            "привет",
            "здравствуй",
            "здравствуйте",
            "добрый день",
            "добрый вечер",
            "доброе утро",
            "как дела",
            "кто ты",
            "спасибо",
            "благодарю",
            "пока",
            "hello",
            "hi",
            "thanks",
        ]
    )


class LocalFirstConfig(BaseModel):
    enabled: bool = True
    primary_model: str = "lmstudio:local-code"
    escalation_model: str = "yandexgpt:yandex-pro"
    max_local_no_progress_cycles: int = 6
    max_local_read_only_cycles: int = 2
    max_local_no_progress_seconds: float = 480.0
    model_load_circuit_breaker_cooldown_seconds: float = Field(default=300.0, ge=1.0)
    reset_on_progress: bool = True


class ContextBudgetConfig(BaseModel):
    safety_margin_tokens: int = Field(default=1024, ge=0)
    capability_cache_ttl_seconds: float = Field(default=300.0, ge=1.0)


class RetrievalConfig(BaseModel):
    enabled: bool = True
    embedding_enabled: bool = True
    embedding_model_env: str = "LMSTUDIO_EMBEDDING_MODEL"
    top_k: int = 8
    max_candidate_files: int = 60
    max_chars_per_file: int = 5000
    max_context_chars: int = 16000
    timeout_seconds: float = 20.0


class ProgressConfig(BaseModel):
    max_same_semantic_action: int = 2
    max_same_failure_signature: int = 2


class DependencyConfig(BaseModel):
    allow_install: bool = False
    max_install_attempts: int = 1
    allowed_packages: list[str] = Field(
        default_factory=lambda: ["types-PyYAML", "types-requests"]
    )


class OrchestrationConfig(BaseModel):
    planning_enabled: bool = True
    review_enabled: bool = True
    max_steps: int = 60  # compatibility hard ceiling; periods should stop much earlier
    max_total_llm_rounds: int = 36
    auto_verify_after_mutation: bool = True
    batch_reads_required: bool = True
    structured_output_enabled: bool = True
    protocol_repairs_per_model: int = 1
    protocol_max_total_repairs: int = 3
    protocol_max_provider_fallbacks: int = 1
    protocol_fallback_models: list[str] = Field(default_factory=list)
    checkpoint_on_failure: bool = True
    baseline_quality_gates: bool = True
    max_reviewer_rejections: int = 2
    task_keywords: list[str] = Field(
        default_factory=lambda: [
            "создай",
            "разработай",
            "исправь",
            "переработай",
            "рефактор",
            "напиши код",
            "проект",
            "протестируй",
            "файл",
        ]
    )




class GenerationProfileConfig(BaseModel):
    temperature: float = Field(default=0.15, ge=0.0, le=2.0)
    max_tokens: int = Field(default=8192, ge=256, le=65536)


class GenerationConfig(BaseModel):
    chat: GenerationProfileConfig = Field(
        default_factory=lambda: GenerationProfileConfig(temperature=0.2, max_tokens=512)
    )
    planner: GenerationProfileConfig = Field(
        default_factory=lambda: GenerationProfileConfig(temperature=0.1, max_tokens=3000)
    )
    executor: GenerationProfileConfig = Field(
        default_factory=lambda: GenerationProfileConfig(temperature=0.15, max_tokens=8192)
    )
    executor_local: GenerationProfileConfig = Field(
        default_factory=lambda: GenerationProfileConfig(temperature=0.1, max_tokens=4096)
    )
    executor_cloud: GenerationProfileConfig = Field(
        default_factory=lambda: GenerationProfileConfig(temperature=0.1, max_tokens=8192)
    )
    repair: GenerationProfileConfig = Field(
        default_factory=lambda: GenerationProfileConfig(temperature=0.0, max_tokens=4096)
    )
    reviewer: GenerationProfileConfig = Field(
        default_factory=lambda: GenerationProfileConfig(temperature=0.1, max_tokens=3000)
    )
    summarizer: GenerationProfileConfig = Field(
        default_factory=lambda: GenerationProfileConfig(temperature=0.1, max_tokens=2500)
    )


class QualityGateConfig(BaseModel):
    auto_run: bool = True
    compileall: bool = True
    pytest: bool = True
    ruff: bool = True
    mypy: bool = True
    auto_fix_ruff: bool = True
    targeted_first: bool = True
    verify_after_source_mutation: bool = True
    verify_after_config_mutation: bool = True
    verify_after_directory_creation: bool = False


class RolesConfig(BaseModel):
    planner: str = "yandexgpt:yandex-pro"
    executor: str = "yandexgpt:yandex-pro"
    reviewer: str = "yandexgpt:yandex-pro"
    safety_officer: str = "yandexgpt:yandex-pro"


PermissionMode = Literal["auto", "confirm", "deny"]


class PermissionsConfig(BaseModel):
    rules: dict[str, PermissionMode] = Field(
        default_factory=lambda: {  # type: ignore[arg-type]
            "workspace.*": "auto",
            "workspace.delete_file": "confirm",
            "execution.*": "auto",
            "terminal.execute": "auto",
            "research.*": "auto",
        }
    )


class AgentTask(BaseModel):
    name: str
    role: str
    rules: list[str] = Field(default_factory=list)
    memory: MemoryConfig = Field(default_factory=MemoryConfig)
    workspace: WorkspaceConfig = Field(default_factory=WorkspaceConfig)
    execution: ExecutionConfig = Field(default_factory=ExecutionConfig)
    research: ResearchConfig = Field(default_factory=ResearchConfig)
    orchestration: OrchestrationConfig = Field(default_factory=OrchestrationConfig)
    chat: ChatConfig = Field(default_factory=ChatConfig)
    local_first: LocalFirstConfig = Field(default_factory=LocalFirstConfig)
    context_budget: ContextBudgetConfig = Field(default_factory=ContextBudgetConfig)
    retrieval: RetrievalConfig = Field(default_factory=RetrievalConfig)
    progress: ProgressConfig = Field(default_factory=ProgressConfig)
    dependencies: DependencyConfig = Field(default_factory=DependencyConfig)
    incident: IncidentConfig = Field(default_factory=IncidentConfig)
    generation: GenerationConfig = Field(default_factory=GenerationConfig)
    quality_gates: QualityGateConfig = Field(default_factory=QualityGateConfig)
    roles: RolesConfig = Field(default_factory=RolesConfig)
    permissions: PermissionsConfig = Field(default_factory=PermissionsConfig)
    default_model: str = "yandexgpt:yandex-pro"
    summarization: SummarizationConfig = Field(default_factory=SummarizationConfig)


class ModelEntry(BaseModel):
    enabled: bool = True
    env_key: str | None = None
    base_url: str | None = None
    base_url_env: str | None = None
    auth_url: str | None = None
    folder_id_env: str | None = None
    timeout_seconds: float | None = Field(default=None, gt=0)
    max_attempts: int | None = Field(default=None, ge=1, le=10)
    capability_cache_ttl_seconds: float | None = Field(default=None, ge=1.0)
    circuit_breaker_cooldown_seconds: float | None = Field(default=None, ge=1.0)
    models: dict[str, str] = Field(default_factory=dict)


class RoutingRule(BaseModel):
    name: str
    match: dict[str, Any]
    model: str


class RoutingConfig(BaseModel):
    rules: list[RoutingRule] = Field(default_factory=list)
    default: str
    fallback_chain: list[str] = Field(default_factory=list)
    retry: dict[str, int] = Field(default_factory=dict)


class ModelsConfig(BaseModel):
    providers: dict[str, ModelEntry]
    routing: RoutingConfig


class PromptsConfig(BaseModel):
    system_template: str
    planner_prompt: str
    reviewer_prompt: str
    summarization_prompt: str


class Settings:
    def __init__(self) -> None:
        self.reload()

    def reload(self) -> None:
        self.agent = AgentTask(**_load_yaml("agent.yaml")["agent"])
        self.models = ModelsConfig(**_load_yaml("models.yaml"))
        self.prompts = PromptsConfig(**_load_yaml("prompts.yaml"))

    def provider_api_key(self, provider_name: str) -> str | None:
        entry = self.models.providers.get(provider_name)
        if entry is None or entry.env_key is None:
            return None
        return os.environ.get(entry.env_key)

    def provider_base_url(self, provider_name: str) -> str | None:
        entry = self.models.providers.get(provider_name)
        if entry is None:
            return None
        if entry.base_url_env:
            return os.environ.get(entry.base_url_env, entry.base_url)
        return entry.base_url

    @property
    def code_execution_enabled(self) -> bool:
        return env_bool(self.agent.execution.enabled_env, False)

    @property
    def research_enabled(self) -> bool:
        return env_bool(self.agent.research.enabled_env, False)


settings = Settings()
