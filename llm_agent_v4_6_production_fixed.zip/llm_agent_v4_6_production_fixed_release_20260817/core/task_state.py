"""Персистентное структурированное состояние текущей инженерной задачи."""
from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, Field


class PlanStep(BaseModel):
    id: int
    description: str
    status: Literal["pending", "in_progress", "done", "failed"] = "pending"


class TaskState(BaseModel):
    task_id: str = Field(default_factory=lambda: uuid.uuid4().hex)
    goal: str
    requested_path: str | None = None
    requested_target: str | None = None
    workspace_root: str | None = None
    scope_confirmed: bool = False
    status: Literal[
        "planning",
        "executing",
        "reviewing",
        "done",
        "failed",
        "blocked",
        "interrupted",
    ] = "planning"
    task_kind: str = "engineering"
    read_only: bool = False
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    updated_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    plan: list[PlanStep] = Field(default_factory=list)
    acceptance_criteria: list[str] = Field(default_factory=list)
    successful_evidence: list[str] = Field(default_factory=list)
    failed_tools: list[str] = Field(default_factory=list)
    files_changed: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class TaskStateManager:
    def __init__(self, path: Path) -> None:
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.history_path = self.path.with_name("task_state_history.jsonl")
        self.current: TaskState | None = None
        if path.exists() and path.stat().st_size:
            try:
                self.current = TaskState.model_validate_json(path.read_text(encoding="utf-8"))
            except (ValueError, OSError):
                self.current = None

    def start(
        self,
        goal: str,
        *,
        requested_path: str | None = None,
        requested_target: str | None = None,
        workspace_root: str | None = None,
        scope_confirmed: bool = False,
        task_kind: str = "engineering",
        read_only: bool = False,
    ) -> TaskState:
        if self.current is not None and self.current.status != "done":
            self._archive(self.current)
        self.current = TaskState(
            goal=goal,
            requested_path=requested_path,
            requested_target=requested_target,
            workspace_root=workspace_root,
            scope_confirmed=scope_confirmed,
            task_kind=task_kind,
            read_only=read_only,
        )
        self.save()
        return self.current

    def set_plan(self, steps: list[str], acceptance_criteria: list[str]) -> None:
        if self.current is None:
            return
        self.current.plan = [PlanStep(id=i + 1, description=step) for i, step in enumerate(steps)]
        self.current.acceptance_criteria = acceptance_criteria
        self.current.status = "executing"
        self.save()

    def record_tool(
        self,
        *,
        call_id: str,
        tool: str,
        ok: bool,
        changed_path: str | None = None,
    ) -> None:
        if self.current is None:
            return
        if ok:
            if call_id not in self.current.successful_evidence:
                self.current.successful_evidence.append(call_id)
            if changed_path and changed_path not in self.current.files_changed:
                self.current.files_changed.append(changed_path)
        else:
            self.current.failed_tools.append(tool)
        self.save()

    def finish(self, ok: bool) -> None:
        if self.current is None:
            return
        self.current.status = "done" if ok else "failed"
        self.save()

    def mark_status(
        self,
        status: Literal["failed", "blocked", "interrupted"],
        *,
        code: str,
        message: str,
        resumable: bool = True,
    ) -> None:
        if self.current is None:
            return
        self.current.status = status
        self.current.metadata["last_failure"] = {
            "code": code,
            "reason": message,
            "resumable": resumable,
        }
        self.save()

    def latest_resumable(self) -> TaskState | None:
        if self.current is not None and self._is_resumable(self.current):
            return self.current
        if not self.history_path.exists():
            return None
        try:
            lines = self.history_path.read_text(encoding="utf-8").splitlines()
        except OSError:
            return None
        for line in reversed(lines):
            try:
                candidate = TaskState.model_validate_json(line)
            except ValueError:
                continue
            if self._is_resumable(candidate):
                return candidate
        return None

    def restore_latest_resumable(self) -> TaskState | None:
        candidate = self.latest_resumable()
        if candidate is None:
            return None
        if self.current is None or self.current.task_id != candidate.task_id:
            self.current = candidate
            self.save()
        return self.current

    @staticmethod
    def _is_resumable(state: TaskState) -> bool:
        if state.status == "done":
            return False
        failure = state.metadata.get("last_failure")
        return not isinstance(failure, dict) or failure.get("resumable", True) is not False

    def _archive(self, state: TaskState) -> None:
        try:
            with self.history_path.open("a", encoding="utf-8") as stream:
                stream.write(json.dumps(state.model_dump(), ensure_ascii=False) + "\n")
        except OSError:
            # Failure to maintain optional history must not corrupt the current state.
            return

    def save(self) -> None:
        if self.current is None:
            return
        self.current.updated_at = datetime.now(timezone.utc).isoformat()
        temp = self.path.with_suffix(self.path.suffix + ".tmp")
        temp.write_text(
            json.dumps(self.current.model_dump(), ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        temp.replace(self.path)
