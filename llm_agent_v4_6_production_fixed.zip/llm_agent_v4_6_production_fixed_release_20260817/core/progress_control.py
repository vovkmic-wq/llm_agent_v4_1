"""Mechanical convergence controls for Agent V4.6.

Loop detection is call-id independent and incident-wide. Source and environment
revisions are tracked separately so an unrelated dependency install cannot reset a
successful structural-action cache or trigger source-only verification.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from core.protocol import ToolCall

_STABLE_IDEMPOTENT_TOOLS = {"workspace.make_directory"}
_NO_REPEAT_WITHOUT_REVISION = {
    "workspace.read_file",
    "workspace.read_files",
    "workspace.read_lines",
    "workspace.read_json",
    "workspace.read_yaml",
    "workspace.list_files",
    "environment.install_packages",
    "execution.run_ruff",
    "execution.run_compileall",
    "execution.run_mypy",
    "execution.run_pytest",
}


def _normalized(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: _normalized(value[key]) for key in sorted(value)}
    if isinstance(value, list):
        return [_normalized(item) for item in value]
    if isinstance(value, str):
        return " ".join(value.strip().split())
    return value


def semantic_action_fingerprint(call: ToolCall) -> str:
    """Return a call-id-independent fingerprint for a tool action."""
    arguments = dict(call.arguments)
    for key in ("content", "text", "new_text"):
        value = arguments.get(key)
        if isinstance(value, str):
            arguments[key] = {
                "chars": len(value),
                "sha256": hashlib.sha256(value.encode("utf-8")).hexdigest(),
            }
    payload = {
        "tool": call.tool,
        "arguments": _normalized(arguments),
    }
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:24]


@dataclass
class ProgressState:
    source_revision: int = 0
    environment_revision: int = 0
    local_no_progress_cycles: int = 0
    local_read_only_cycles: int = 0
    local_no_progress_seconds: float = 0.0
    repeated_failure_cycles: int = 0
    last_failure_signature: str | None = None
    semantic_actions: dict[str, tuple[int, int, int]] = field(default_factory=dict)
    completed_stable_actions: set[str] = field(default_factory=set)
    completed_revision_actions: dict[str, tuple[int, int]] = field(default_factory=dict)


class ProgressController:
    """Track objective progress and prevent semantically repeated actions."""

    def __init__(
        self,
        *,
        max_same_semantic_action: int = 2,
        max_same_failure_signature: int = 2,
    ) -> None:
        self.max_same_semantic_action = max(1, max_same_semantic_action)
        self.max_same_failure_signature = max(1, max_same_failure_signature)
        self.state = ProgressState()

    def completed_action(self, call: ToolCall) -> bool:
        fingerprint = semantic_action_fingerprint(call)
        if (
            call.tool in _STABLE_IDEMPOTENT_TOOLS
            and fingerprint in self.state.completed_stable_actions
        ):
            return True
        return self.state.completed_revision_actions.get(fingerprint) == (
            self.state.source_revision,
            self.state.environment_revision,
        )

    def completed_revision_action(self, call: ToolCall) -> bool:
        fingerprint = semantic_action_fingerprint(call)
        return (
            call.tool in _NO_REPEAT_WITHOUT_REVISION
            and self.state.completed_revision_actions.get(fingerprint)
            == (self.state.source_revision, self.state.environment_revision)
        )

    def mark_action_completed(self, call: ToolCall) -> None:
        fingerprint = semantic_action_fingerprint(call)
        if call.tool in _STABLE_IDEMPOTENT_TOOLS:
            self.state.completed_stable_actions.add(fingerprint)
        if call.tool in _NO_REPEAT_WITHOUT_REVISION:
            self.state.completed_revision_actions[fingerprint] = (
                self.state.source_revision,
                self.state.environment_revision,
            )

    def action_allowed(self, call: ToolCall) -> tuple[bool, str | None]:
        if self.completed_action(call):
            return False, "Стабильное идемпотентное действие уже успешно выполнено в incident."
        fingerprint = semantic_action_fingerprint(call)
        previous = self.state.semantic_actions.get(fingerprint)
        current = (
            self.state.source_revision,
            self.state.environment_revision,
            1,
        )
        if previous is None:
            self.state.semantic_actions[fingerprint] = current
            return True, None
        old_source, old_env, count = previous
        if (
            old_source == self.state.source_revision
            and old_env == self.state.environment_revision
        ):
            count += 1
            self.state.semantic_actions[fingerprint] = (old_source, old_env, count)
            if count > self.max_same_semantic_action:
                return (
                    False,
                    "Семантически одинаковое действие уже повторялось без изменения "
                    "source/environment revision. Выбери другой диагностический шаг, "
                    "patch или blocker.",
                )
            return True, None
        self.state.semantic_actions[fingerprint] = current
        return True, None

    def _reset_local_stall(self) -> None:
        self.state.local_no_progress_cycles = 0
        self.state.local_read_only_cycles = 0
        self.state.local_no_progress_seconds = 0.0

    def source_mutated(self) -> None:
        self.state.source_revision += 1
        self._reset_local_stall()
        self.state.repeated_failure_cycles = 0

    def environment_mutated(self) -> None:
        self.state.environment_revision += 1
        self._reset_local_stall()
        self.state.repeated_failure_cycles = 0

    def verification(self, signature: str | None, *, ok: bool) -> bool:
        """Return True when verification objectively changed state."""
        if ok:
            changed = self.state.last_failure_signature not in {None, "green"}
            self.state.last_failure_signature = "green"
            self.state.repeated_failure_cycles = 0
            if changed:
                self._reset_local_stall()
            return changed
        if not signature:
            return False
        changed = signature != self.state.last_failure_signature
        if changed:
            self.state.last_failure_signature = signature
            self.state.repeated_failure_cycles = 0
            self._reset_local_stall()
            return True
        self.state.repeated_failure_cycles += 1
        return False

    def local_round_finished(
        self,
        *,
        progress: bool,
        elapsed_seconds: float = 0.0,
    ) -> None:
        if progress:
            self._reset_local_stall()
            return
        self.state.local_no_progress_cycles += 1
        self.state.local_no_progress_seconds += max(0.0, float(elapsed_seconds))

    def local_read_only_finished(self, *, progress: bool) -> None:
        if progress:
            self.state.local_read_only_cycles = 0
        else:
            self.state.local_read_only_cycles += 1

    def should_escalate_local(
        self,
        max_cycles: int,
        max_read_only_cycles: int | None = None,
        max_no_progress_seconds: float | None = None,
    ) -> bool:
        if self.state.local_no_progress_cycles >= max(1, max_cycles):
            return True
        if (
            max_read_only_cycles is not None
            and max_read_only_cycles > 0
            and self.state.local_read_only_cycles >= max_read_only_cycles
        ):
            return True
        return bool(
            max_no_progress_seconds is not None
            and max_no_progress_seconds > 0
            and self.state.local_no_progress_seconds >= max_no_progress_seconds
        )

    def local_escalation_reason(
        self,
        *,
        max_cycles: int,
        max_read_only_cycles: int,
        max_no_progress_seconds: float,
    ) -> str:
        if self.state.local_read_only_cycles >= max_read_only_cycles > 0:
            return f"read-only cycles={self.state.local_read_only_cycles}"
        if self.state.local_no_progress_seconds >= max_no_progress_seconds > 0:
            return f"no-progress time={self.state.local_no_progress_seconds:.1f}s"
        return f"no-progress cycles={self.state.local_no_progress_cycles}/{max_cycles}"

    def repeated_failure_blocked(self) -> bool:
        return self.state.repeated_failure_cycles >= self.max_same_failure_signature

    def snapshot(self) -> dict[str, Any]:
        """Serialize incident-wide convergence state for checkpoint/resume."""
        return {
            "source_revision": self.state.source_revision,
            "environment_revision": self.state.environment_revision,
            "local_no_progress_cycles": self.state.local_no_progress_cycles,
            "local_read_only_cycles": self.state.local_read_only_cycles,
            "local_no_progress_seconds": self.state.local_no_progress_seconds,
            "repeated_failure_cycles": self.state.repeated_failure_cycles,
            "last_failure_signature": self.state.last_failure_signature,
            "semantic_actions": {
                key: list(value) for key, value in self.state.semantic_actions.items()
            },
            "completed_stable_actions": sorted(self.state.completed_stable_actions),
            "completed_revision_actions": {
                key: list(value)
                for key, value in self.state.completed_revision_actions.items()
            },
        }

    def restore(self, payload: dict[str, Any] | None) -> None:
        """Restore convergence state saved in an Incident checkpoint."""
        if not isinstance(payload, dict):
            return
        self.state.source_revision = int(payload.get("source_revision", 0) or 0)
        self.state.environment_revision = int(payload.get("environment_revision", 0) or 0)
        self.state.local_no_progress_cycles = int(
            payload.get("local_no_progress_cycles", 0) or 0
        )
        self.state.local_read_only_cycles = int(
            payload.get("local_read_only_cycles", 0) or 0
        )
        self.state.local_no_progress_seconds = float(
            payload.get("local_no_progress_seconds", 0.0) or 0.0
        )
        self.state.repeated_failure_cycles = int(
            payload.get("repeated_failure_cycles", 0) or 0
        )
        signature = payload.get("last_failure_signature")
        self.state.last_failure_signature = str(signature) if signature else None
        actions = payload.get("semantic_actions")
        if isinstance(actions, dict):
            restored: dict[str, tuple[int, int, int]] = {}
            for key, value in actions.items():
                if isinstance(value, (list, tuple)) and len(value) == 3:
                    restored[str(key)] = (int(value[0]), int(value[1]), int(value[2]))
            self.state.semantic_actions = restored
        completed = payload.get("completed_stable_actions")
        if isinstance(completed, list):
            self.state.completed_stable_actions = {str(item) for item in completed}
        revision_completed = payload.get("completed_revision_actions")
        if isinstance(revision_completed, dict):
            restored_completed: dict[str, tuple[int, int]] = {}
            for key, value in revision_completed.items():
                if isinstance(value, (list, tuple)) and len(value) == 2:
                    restored_completed[str(key)] = (int(value[0]), int(value[1]))
            self.state.completed_revision_actions = restored_completed


def mutation_kind(path: str | None, tool: str) -> str:
    """Classify mutation so verification can be proportional to risk."""
    if tool.startswith("environment."):
        return "environment"
    if tool == "workspace.make_directory":
        return "structural"
    if not path:
        return "source"
    suffix = Path(path).suffix.casefold()
    if suffix in {".md", ".rst", ".txt"}:
        return "docs"
    if suffix in {".yaml", ".yml", ".json", ".toml", ".ini", ".cfg"}:
        return "config"
    if suffix in {".py", ".pyi", ".pyx"}:
        return "source"
    return "source"
