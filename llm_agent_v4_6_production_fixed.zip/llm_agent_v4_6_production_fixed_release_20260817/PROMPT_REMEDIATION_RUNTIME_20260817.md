# Промт для исправления подтверждённых runtime-ошибок V4.6

Работай с проектом `llm_agent_v4_6_production_fixed`. Нормативные источники:
`TECHNICAL_SPECIFICATION.md`, `TECHNICAL_SPECIFICATION_V4_6.md`,
`config/prompts.yaml` и фактические runtime-логи от 2026-08-16/17.

## Цель

Исправь только подтверждённые логами несоответствия. Не добавляй функций, которых нет в
ТЗ. Проводи цикл «воспроизведение -> минимальное исправление -> targeted tests -> полный
regression suite» до PASS либо доказанного внешнего blocker. Нельзя объявлять PASS по
предположению, статическому просмотру или одним зелёным quality gates.

## Подтверждённые дефекты

1. Запрос «проверь структуру файлов на соответствие ТЗ» ошибочно ушёл в общий engineering
   loop: 2 LM Studio + 36 Yandex rounds, 20 tool calls, 4 install attempts и round ceiling.
2. Явный read-only structural audit завершился `done` только по Ruff/compileall/mypy/
   pytest без чтения ТЗ, root listing и requirement/evidence matrix.
3. `files_changed=[]` не подтверждён filesystem manifest и не учитывает side effects
   compileall/pytest/mypy/Ruff caches.
4. Protocol/round/interruption failure теряет resumable state; `/resume` затем не может
   продолжить фактически незавершённую проверку.
5. Follow-up «что делать/продолжи/дай статус» уходит в новый chat и выдаёт generic
   PowerShell checklist вместо состояния и самостоятельных read-only действий.
6. Русский диалог получил китайский текст и нерелевантный совет по Poetry.
7. Ctrl+C во время HTTP request завершает CLI traceback-ом.
8. Валидная по смыслу форма `type=tool_batch` исчерпывает repairs вместо безопасной
   однозначной нормализации в `type=tools` при уже существующем `calls`.
9. Bare/incomplete PowerShell pipeline в chat вызывает долгий provider request.
10. Отдельные capability key/value сообщения ошибочно продолжают старую тему и не
    должны считаться `/doctor` evidence.

## Обязательная реализация

### A. Классификация и structural audit

- Kernel до baseline/Planner/provider распознаёт structural audit по смыслу запроса; слова
  «ничего не меняй» не обязательны.
- При отсутствии mutation verbs выбирается read-only режим.
- Structural audit по умолчанию не запускает общий Ruff/compileall/mypy/pytest baseline.
- Последовательность: confirm target/spec -> read spec -> bounded root listing -> derive
  required paths/roles -> targeted batch reads/listings -> evidence matrix -> report.
- Отчёт содержит scope, spec source/hash, requirement/evidence matrix, gaps, отдельный
  quality status, before/after manifest и PASS/FAIL/BLOCKED.
- Green gates никогда не заменяют structural evidence.

### B. Механический read-only lock

- В TaskState хранится read-only scope.
- Kernel allow-list разрешает только гарантированно не изменяющие read/list/stat/hash.
- Любой install/write/patch/delete/mkdir/terminal action отклоняется до permissions и до
  исполнения, даже если его запросила LLM.
- Для строгого audit не допускаются project-local caches/pyc. Если gate отдельно заказан,
  используй cache-free variant или temp path вне target.
- Сравни before/after manifests с полными relative paths и SHA-256; journal mutations не
  является достаточным доказательством.

### C. Convergence и бюджет

- Простой audit не более шести tool calls и двух LLM rounds; предпочтительно zero LLM.
- Запрети повтор green gate, одинакового install/read action без revision/new evidence.
- Не допускай handoff и общий ceiling 36 rounds для bounded audit: раньше сформируй отчёт
  или точный blocker.

### D. TaskState, follow-up и resume

- `protocol_failure`, `provider_failure`, `round_limit`, `interrupted`,
  `incomplete_evidence` не преобразуются в `done`.
- Сохраняй goal, target, plan, criteria, evidence, last error и resume cursor на диск.
- `/resume` продолжает их после перезапуска.
- «что теперь делать?», «продолжи предыдущую задачу», «дай текущий статус» сначала
  обслуживают релевантную незавершённую/recent failed task.

### E. CLI, shell и язык

- Перехвати первый KeyboardInterrupt вокруг provider/tool и в main loop: checkpoint,
  короткое сообщение без traceback, возврат к prompt. Повторный Ctrl+C на пустом prompt
  может завершить программу.
- Bare shell и incomplete pipelines с trailing continuation распознавай без Router и
  отвечай `NOT_EXECUTED`.
- Embedded slash-команда не считается выполненной; сообщи правильный способ ввода.
- Для русского запроса валидируй язык final. При CJK/mixed-language drift выполни один
  bounded repair или дай детерминированный русский fallback.
- Не перекладывай доступные read-only действия на пользователя.

### F. Protocol recovery

- Сохрани fail-closed validation.
- Разреши только нейтральную нормализацию `type=tool_batch` -> `type=tools`, если объект
  уже имеет корректный `calls` и не содержит конфликтующих payload.
- Не придумывай calls, tool names, arguments, reason или evidence.

## Обязательные тесты

Добавь regression tests на точные фразы и события из логов:

1. естественный structural audit -> zero mutation/install/baseline, bounded evidence;
2. explicit read-only audit -> spec + root list + matrix, а не gates-only PASS;
3. malicious/scripted LLM install/write action -> kernel rejection;
4. before/after manifest equality и обнаружение незарегистрированного изменения;
5. four green gates without structural evidence -> no structural PASS;
6. round/protocol/provider failure -> resumable state после нового процесса;
7. status/continue follow-ups -> текущая цель/ошибка/next step без Router generic chat;
8. KeyboardInterrupt -> no traceback, CLI alive, state saved;
9. valid tool_batch alias -> tools; malformed alias -> fail closed;
10. incomplete PowerShell pipeline -> zero provider calls;
11. Russian response language guard;
12. exact external path blocker и exact model/capability tests остаются green;
13. полный normal/regression suite, отдельные subprocess tests, Ruff, mypy, AST/syntax,
    wheel build/import и clean ZIP roundtrip.

## Формат завершения

Верни только подтверждённый отчёт:

- изменённые файлы и связь каждой правки с FR/дефектом;
- новые regression tests;
- команды и точные результаты всех проверок;
- remaining gaps/blockers;
- подтверждение, что source/config/docs manifests и release artifacts согласованы.

Если хотя бы один обязательный критерий не подтверждён, итог не PASS.
