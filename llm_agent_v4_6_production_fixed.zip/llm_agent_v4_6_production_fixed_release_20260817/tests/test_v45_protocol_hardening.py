from __future__ import annotations

import json
from pathlib import Path

import pytest

from core.agent import Agent
from core.memory import MemoryManager
from core.protocol import (
    ReporterAnswer,
    decode_agent_response,
    decode_reporter_response,
    protocol_diagnostics,
    protocol_json_schema,
)
from core.workspace import WorkspaceManager
from providers.base import CompletionResult
from providers.lmstudio_provider import LMStudioProvider
from providers.yandexgpt_provider import YandexGPTProvider


class RecordingRouter:
    def __init__(self, responses: list[str] | None = None) -> None:
        self.responses = list(responses or [])
        self.calls: list[dict] = []

    def call(self, **kwargs):
        self.calls.append(kwargs)
        text = self.responses.pop(0) if self.responses else (
            '{"type":"final","status":"success","content":"ok","evidence":[]}'
        )
        return CompletionResult(text=text, raw_model_name=kwargs["model_id"])


def _agent(tmp_path: Path, router: RecordingRouter, *, execution: bool) -> Agent:
    workspace = WorkspaceManager(tmp_path / "workspace")
    workspace.make_directory("demo")
    workspace.write_file("demo/app.py", "VALUE = 1\n")
    workspace.make_directory("demo/tests")
    workspace.write_file(
        "demo/tests/test_app.py",
        "def test_value():\n    assert 1 == 1\n",
    )
    agent = Agent(
        memory=MemoryManager(tmp_path / "memory"),
        router=router,
        workspace=workspace,
        planner_enabled=False,
        reviewer_enabled=False,
        execution_enabled=execution,
        research_enabled=False,
    )
    agent.project_context.set_active_project("demo")
    return agent


def _gate(call_id: str, tool: str, ok: bool, output: str) -> dict:
    return {
        "type": "tool_result",
        "call_id": call_id,
        "tool": tool,
        "ok": ok,
        "result": {"ok": ok, "output": output},
    }


def test_read_only_audit_finishes_without_llm(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    router = RecordingRouter()
    agent = _agent(tmp_path, router, execution=True)
    results = [
        _gate("ruff-1", "execution.run_ruff", True, "All checks passed!"),
        _gate("compile-1", "execution.run_compileall", True, ""),
        _gate(
            "mypy-1",
            "execution.run_mypy",
            False,
            "app.py:1: error: Incompatible types in assignment [assignment]",
        ),
        _gate("pytest-1", "execution.run_pytest", True, "1 passed"),
    ]
    monkeypatch.setattr(
        agent,
        "_run_quality_gates",
        lambda evidence, remediate=False: (results, False),
    )

    answer = agent.ask(
        "Проверь активный проект. Ничего не изменяй. Выдай список найденных проблем.",
        force_task=True,
    )

    assert router.calls == []
    assert "mypy" in answer.casefold()
    assert "app.py:1" in answer
    assert "файлы не изменялись" in answer.casefold()


def test_lmstudio_sends_native_json_schema(monkeypatch: pytest.MonkeyPatch) -> None:
    captured: dict = {}

    class Response:
        def raise_for_status(self) -> None:
            return None

        def json(self) -> dict:
            return {
                "choices": [
                    {
                        "message": {"content": '{"type":"final","content":"ok"}'},
                        "finish_reason": "stop",
                    }
                ],
                "usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15},
            }

    def fake_post(url, headers, json, timeout):
        captured["json"] = json
        return Response()

    monkeypatch.setattr("providers.openai_compatible.httpx.post", fake_post)
    provider = LMStudioProvider(None, "http://localhost:1234/v1")
    schema = protocol_json_schema()
    result = provider.complete(
        model_name="qwen2.5-coder-7b-instruct",
        system_prompt="system",
        messages=[{"role": "user", "content": "task"}],
        response_schema=schema,
        response_schema_name="agent_action",
    )
    assert captured["json"]["response_format"]["type"] == "json_schema"
    assert captured["json"]["response_format"]["json_schema"]["schema"] == schema
    assert result.structured_output == "json_schema"


def test_yandex_sends_json_schema(monkeypatch: pytest.MonkeyPatch) -> None:
    captured: dict = {}
    monkeypatch.setenv("YANDEX_FOLDER_ID", "folder")

    class Response:
        status_code = 200

        def raise_for_status(self) -> None:
            return None

        def json(self) -> dict:
            return {
                "choices": [
                    {
                        "message": {"content": '{"type":"final","content":"ok"}'},
                        "finish_reason": "stop",
                    }
                ],
                "usage": {
                    "total_tokens": 12,
                    "prompt_tokens": 8,
                    "completion_tokens": 4,
                },
            }

    def fake_post(url, headers, json, timeout):
        captured["url"] = url
        captured["headers"] = headers
        captured["json"] = json
        return Response()

    monkeypatch.setattr("providers.yandexgpt_provider.httpx.post", fake_post)
    provider = YandexGPTProvider(
        "secret",
        "https://llm.api.cloud.yandex.net/foundationModels/v1",
        "YANDEX_FOLDER_ID",
    )
    schema = protocol_json_schema()
    result = provider.complete(
        model_name="yandexgpt",
        system_prompt="system",
        messages=[{"role": "user", "content": "task"}],
        response_schema=schema,
        response_schema_name="agent_action",
    )
    assert captured["url"] == "https://ai.api.cloud.yandex.net/v1/chat/completions"
    assert captured["headers"]["OpenAI-Project"] == "folder"
    assert captured["json"]["model"] == "gpt://folder/yandexgpt"
    response_format = captured["json"]["response_format"]
    assert response_format["type"] == "json_schema"
    assert response_format["json_schema"]["name"] == "agent_action"
    assert response_format["json_schema"]["schema"] == schema
    assert "jsonSchema" not in captured["json"]
    assert result.structured_output == "json_schema"


def test_protocol_recovers_trailing_comma_without_llm() -> None:
    decoded = decode_agent_response(
        '{"type":"final","status":"success","content":"ok","evidence":[],}'
    )
    assert decoded.action is not None
    assert decoded.recovered is True
    assert decoded.recovery_method == "trailing_comma"


def test_reporter_protocol_is_separate_from_tool_protocol() -> None:
    raw = json.dumps(
        {
            "status": "issues_found",
            "summary": "Найдена одна проблема",
            "problems": [
                {
                    "gate": "mypy",
                    "file": "app.py",
                    "line": 1,
                    "message": "type error",
                }
            ],
        },
        ensure_ascii=False,
    )
    report = decode_reporter_response(raw)
    assert isinstance(report, ReporterAnswer)
    assert report.status == "issues_found"
    assert report.problems[0].gate == "mypy"


def test_agent_requests_structured_output_for_engineering_actions(tmp_path: Path) -> None:
    tool_action = json.dumps(
        {
            "type": "tool",
            "tool": "workspace.write_file",
            "arguments": {"path": "demo/new.py", "content": "X = 1\n"},
            "call_id": "w1",
            "reason": "acceptance:create",
        }
    )
    router = RecordingRouter(
        [
            tool_action,
            '{"type":"final","status":"success","content":"done","evidence":["w1"]}',
        ]
    )
    agent = _agent(tmp_path, router, execution=False)
    assert agent.ask("Создай demo/new.py", force_task=True) == "done"
    assert router.calls
    assert router.calls[0]["response_schema"] == protocol_json_schema()


def test_protocol_repair_round_does_not_consume_semantic_incident_round(tmp_path: Path) -> None:
    tool_action = json.dumps(
        {
            "type": "tool",
            "tool": "workspace.write_file",
            "arguments": {"path": "demo/new.py", "content": "X = 1\n"},
            "call_id": "w1",
            "reason": "acceptance:create",
        }
    )
    router = RecordingRouter(
        [
            '{"type":"tool","tool":"workspace.write_file","arguments":{"path":"demo/new.py"',
            tool_action,
            '{"type":"final","status":"success","content":"done","evidence":["w1"]}',
        ]
    )
    agent = _agent(tmp_path, router, execution=False)
    assert agent.ask("Создай demo/new.py", force_task=True) == "done"
    assert agent.incident.state is not None
    assert agent.incident.state.total_llm_rounds == 2


def test_unknown_tool_batch_is_repaired_before_permission_layer(tmp_path: Path) -> None:
    invalid_batch = json.dumps(
        {
            "type": "tool",
            "tool": "tool_batch",
            "arguments": {"calls": []},
            "call_id": "bad-batch",
        }
    )
    valid_write = json.dumps(
        {
            "type": "tool",
            "tool": "workspace.write_file",
            "arguments": {"path": "demo/new.py", "content": "X = 1\n"},
            "call_id": "w1",
            "reason": "acceptance:create",
        }
    )
    router = RecordingRouter(
        [
            invalid_batch,
            valid_write,
            '{"type":"final","status":"success","content":"done","evidence":["w1"]}',
        ]
    )
    agent = _agent(tmp_path, router, execution=False)

    assert agent.ask("Создай demo/new.py", force_task=True) == "done"
    assert (tmp_path / "workspace" / "demo" / "new.py").read_text() == "X = 1\n"
    repair_messages = router.calls[1]["messages"]
    assert any(
        "Неизвестный инструмент" in message["content"]
        for message in repair_messages
        if message["role"] == "user"
    )


def test_protocol_fallback_switches_provider_after_one_local_repair(tmp_path: Path) -> None:
    tool_action = json.dumps(
        {
            "type": "tool",
            "tool": "workspace.write_file",
            "arguments": {"path": "demo/new.py", "content": "X = 1\n"},
            "call_id": "w1",
            "reason": "acceptance:create",
        }
    )
    router = RecordingRouter(
        [
            '{"type":"tool","tool":"workspace.write_file"',
            '{"type":"tool","tool":"workspace.write_file"',
            tool_action,
            '{"type":"final","status":"success","content":"done","evidence":["w1"]}',
        ]
    )
    agent = _agent(tmp_path, router, execution=False)

    assert agent.ask("Создай demo/new.py", force_task=True) == "done"
    models = [call["model_id"] for call in router.calls]
    assert models[:2] == ["lmstudio:local-code", "lmstudio:local-code"]
    assert models[2:] == ["yandexgpt:yandex-pro", "yandexgpt:yandex-pro"]
    assert agent.incident.state is not None
    assert agent.incident.state.total_llm_rounds == 2


def test_protocol_diagnostics_never_exposes_raw_response() -> None:
    secret = 'TOP_SECRET_RESPONSE {"type":"broken"}'
    diagnostics = protocol_diagnostics(secret)

    assert diagnostics["response_chars"] == len(secret)
    assert len(diagnostics["response_sha256_16"]) == 16
    assert "TOP_SECRET_RESPONSE" not in json.dumps(diagnostics)
    assert "tail" not in diagnostics


def test_yandex_normalizes_legacy_and_full_chat_urls(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("YANDEX_FOLDER_ID", "folder")
    legacy_ai = YandexGPTProvider(
        "secret",
        "https://ai.api.cloud.yandex.net/foundationModels/v1",
        "YANDEX_FOLDER_ID",
    )
    full_chat = YandexGPTProvider(
        "secret",
        "https://ai.api.cloud.yandex.net/v1/chat/completions",
        "YANDEX_FOLDER_ID",
    )
    assert legacy_ai.base_url == "https://ai.api.cloud.yandex.net/v1"
    assert full_chat.base_url == "https://ai.api.cloud.yandex.net/v1"
