from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace
from typing import Any

import httpx
import pytest

import core.router as router_module
from core.agent import Agent
from core.config import GenerationProfileConfig, settings
from core.memory import MemoryManager
from core.prompt_builder import rough_token_estimate
from core.router import Router
from core.workspace import WorkspaceManager
from providers.base import CompletionResult, ProviderCapabilities, ProviderError
from providers.http_utils import provider_http_error
from providers.lmstudio_provider import LMStudioProvider


class _NeverRouter:
    calls = 0

    def call(self, **kwargs):
        self.calls += 1
        raise AssertionError("provider must not be called")


def _agent(tmp_path: Path, router: Any | None = None) -> Agent:
    return Agent(
        memory=MemoryManager(tmp_path / "memory"),
        router=router or _NeverRouter(),
        workspace=WorkspaceManager(tmp_path / "workspace"),
        planner_enabled=False,
        reviewer_enabled=False,
        execution_enabled=False,
        research_enabled=False,
    )


def _response(url: str, status: int, payload: dict) -> httpx.Response:
    return httpx.Response(
        status,
        json=payload,
        request=httpx.Request("GET", url),
    )


def test_trim_enforces_budget_with_only_three_large_messages(tmp_path: Path) -> None:
    agent = _agent(tmp_path)
    messages = [
        {"role": "user", "content": "task"},
        {"role": "user", "content": "a" * 30000},
        {"role": "user", "content": "b" * 30000},
    ]
    agent._trim_loop_messages("system", messages, 0, {}, token_limit=2000)
    estimate = rough_token_estimate(
        "system" + "".join(str(item["content"]) for item in messages)
    )
    assert estimate <= 2000


def test_list_files_model_preview_is_bounded_and_full_result_is_unchanged() -> None:
    full: dict[str, Any] = {
        "entries": [
            {"path": f"src/file_{index:04d}.py", "type": "file", "size": 10}
            for index in range(1500)
        ],
        "total_entries": 1500,
        "returned_entries": 1500,
        "truncated": False,
    }
    preview = Agent._result_for_model("workspace.list_files", full)
    assert len(full["entries"]) == 1500
    assert preview["total_entries"] == 1500
    preview_entries = preview["entries"]
    assert isinstance(preview_entries, list)
    assert len(preview_entries) <= settings.agent.workspace.max_model_list_entries
    assert preview["truncated_for_context"] is True
    assert len(str(preview)) <= settings.agent.workspace.max_model_list_chars + 2000


def test_structural_listing_prunes_pytest_and_coverage_artifacts(tmp_path: Path) -> None:
    workspace = WorkspaceManager(
        tmp_path / "workspace",
        protected_globs=settings.agent.workspace.protected_globs,
        ignored_globs=settings.agent.workspace.ignored_globs,
    )
    for directory in (".pytest-run", ".pytest_tmp", "htmlcov", ".venv"):
        (workspace.root / directory).mkdir()
        (workspace.root / directory / "artifact.txt").write_text("x", encoding="utf-8")
    (workspace.root / ".coverage").write_text("x", encoding="utf-8")
    (workspace.root / "app.py").write_text("x = 1\n", encoding="utf-8")
    paths = {
        item["path"]
        for item in workspace.list_files(".", recursive=True)["entries"]
    }
    assert "app.py" in paths
    assert not any(path.startswith((".pytest-", ".pytest_", "htmlcov", ".venv")) for path in paths)
    assert ".coverage" not in paths


def test_context_overflow_is_classified_with_confirmed_limit() -> None:
    response = httpx.Response(
        400,
        json={
            "error": {
                "message": "got 85240 input tokens; maximum context is 32768 tokens"
            }
        },
        request=httpx.Request("POST", "https://example.invalid/chat/completions"),
    )
    error = provider_http_error(
        "yandexgpt",
        httpx.HTTPStatusError("bad", request=response.request, response=response),
    )
    assert error.code == "context_length_exceeded"
    assert error.context_limit == 32768
    assert error.retryable is False


def test_lmstudio_api_v1_uses_loaded_context_and_exact_id(monkeypatch) -> None:
    def fake_get(url, **kwargs):
        assert kwargs["timeout"] == 5.0
        return _response(
            url,
            200,
            {
                "models": [
                    {
                        "key": "qwen2.5-coder-7b-instruct",
                        "max_context_length": 65536,
                    },
                    {
                        "key": "qwen2.5-7b-instruct",
                        "display_name": "Qwen2.5 7B Instruct",
                        "quantization": "Q4_K_M",
                        "max_context_length": 32768,
                        "loaded_instances": [{"config": {"context_length": 16384}}],
                    },
                ]
            },
        )

    monkeypatch.setattr("providers.lmstudio_provider.httpx.get", fake_get)
    provider = LMStudioProvider(None, "http://localhost:1234/v1")
    capabilities = provider.discover_capabilities("qwen2.5-7b-instruct")
    assert capabilities.model_id == "qwen2.5-7b-instruct"
    assert capabilities.quantization == "Q4_K_M"
    assert capabilities.max_context_tokens == 32768
    assert capabilities.loaded_context_tokens == 16384
    assert capabilities.effective_context_tokens == 16384
    assert capabilities.source == "/api/v1/models"


def test_lmstudio_falls_back_to_api_v0_and_caches_by_exact_model(monkeypatch) -> None:
    calls: list[str] = []

    def fake_get(url, **kwargs):
        calls.append(url)
        if url.endswith("/api/v1/models"):
            return _response(url, 404, {"error": {"message": "not found"}})
        return _response(
            url,
            200,
            {
                "models": [
                    {
                        "id": "qwen2.5-7b-instruct",
                        "max_context_length": 32768,
                        "loaded_context_length": 32768,
                    }
                ]
            },
        )

    monkeypatch.setattr("providers.lmstudio_provider.httpx.get", fake_get)
    provider = LMStudioProvider(None, "http://localhost:1234/v1")
    first = provider.discover_capabilities("qwen2.5-7b-instruct")
    second = provider.discover_capabilities("qwen2.5-7b-instruct")
    assert first.source == "/api/v0/models"
    assert second == first
    assert len(calls) == 2


def test_missing_exact_lmstudio_model_stops_before_chat(monkeypatch) -> None:
    def fake_get(url, **kwargs):
        return _response(
            url,
            200,
            {"models": [{"id": "qwen2.5-coder-7b-instruct"}]},
        )

    monkeypatch.setattr("providers.lmstudio_provider.httpx.get", fake_get)
    provider = LMStudioProvider(None, "http://localhost:1234/v1")
    with pytest.raises(ProviderError) as caught:
        provider.discover_capabilities("qwen2.5-7b-instruct")
    assert caught.value.code == "configured_model_not_found"


def test_model_load_failure_opens_session_circuit(monkeypatch) -> None:
    calls = 0

    def fail_complete(self, **kwargs):
        nonlocal calls
        calls += 1
        raise ProviderError(
            "Failed to load model; exited before becoming healthy",
            retryable=False,
            code="model_load_failure",
        )

    monkeypatch.setattr(
        "providers.openai_compatible.OpenAICompatibleProvider.complete",
        fail_complete,
    )
    provider = LMStudioProvider(None, "http://localhost:1234/v1")
    with pytest.raises(ProviderError, match="Failed to load"):
        provider.complete(
            model_name="qwen2.5-7b-instruct",
            system_prompt="s",
            messages=[],
        )
    with pytest.raises(ProviderError) as caught:
        provider.complete(
            model_name="qwen2.5-7b-instruct",
            system_prompt="s",
            messages=[],
        )
    assert caught.value.code == "model_load_circuit_open"
    assert calls == 1
    assert provider.circuit_diagnostic()["status"] == "open"


def test_effective_budget_uses_loaded_context_output_margin_and_internal_cap(
    monkeypatch,
) -> None:
    class FakeProvider:
        provider_name = "fake"
        base_url = "https://example.invalid/v1"

        def discover_capabilities(self, model_name, *, force=False):
            return ProviderCapabilities(
                provider="fake",
                base_url=self.base_url,
                model_id=model_name,
                max_context_tokens=32768,
                loaded_context_tokens=12000,
                effective_context_tokens=12000,
                discovered_at=1.0,
            )

    provider = FakeProvider()
    monkeypatch.setattr(
        router_module,
        "resolve_model_id",
        lambda model_id: (provider, "qwen2.5-7b-instruct"),
    )
    budget = Router().request_budget(
        "fake:model",
        internal_input_limit=10000,
        output_reserve_tokens=4096,
        safety_margin_tokens=1024,
    )
    assert budget.effective_input_budget == 6880


def test_final_preflight_blocks_oversized_request_without_provider_call(
    tmp_path: Path,
) -> None:
    class GuardedRouter(_NeverRouter):
        def request_budget(self, *args, **kwargs):
            return SimpleNamespace(
                effective_input_budget=100,
                effective_context_tokens=1000,
            )

    router = GuardedRouter()
    agent = _agent(tmp_path, router)
    with pytest.raises(ProviderError) as caught:
        agent._router_call(
            model_id="test:model",
            system_prompt="x" * 5000,
            messages=[{"role": "user", "content": "hello"}],
            profile=GenerationProfileConfig(max_tokens=256),
        )
    assert caught.value.code == "context_budget_exceeded"
    assert router.calls == 0


def test_absolute_target_outside_workspace_blocks_before_baseline_and_llm(
    tmp_path: Path,
    monkeypatch,
) -> None:
    outside = tmp_path / "outside-project"
    outside.mkdir()
    router = _NeverRouter()
    agent = _agent(tmp_path, router)
    monkeypatch.setattr(
        agent,
        "_run_quality_gates",
        lambda *args, **kwargs: (_ for _ in ()).throw(
            AssertionError("baseline must not run")
        ),
    )
    answer = agent.ask(
        f"Проверь проект по ТЗ в директории {outside}",
        force_task=True,
    )
    assert "path_outside_workspace" in answer
    assert router.calls == 0
    assert agent.task_state.current is not None
    assert agent.task_state.current.requested_path == str(outside.resolve())
    assert agent.task_state.current.scope_confirmed is False


class _ContextRetryRouter:
    def __init__(self) -> None:
        self.calls: list[str] = []

    def call(self, **kwargs):
        self.calls.append(kwargs["model_id"])
        if len(self.calls) == 1:
            raise ProviderError(
                "maximum context is 32768",
                retryable=False,
                code="context_length_exceeded",
                context_limit=32768,
            )
        if len(self.calls) == 2:
            return CompletionResult(
                text=(
                    '{"type":"tool","tool":"workspace.write_file","arguments":'
                    '{"path":"ok.txt","content":"ok"},"call_id":"write"}'
                ),
                raw_model_name=kwargs["model_id"],
            )
        return CompletionResult(
            text='{ "type":"final","content":"Готово","evidence":["write"]}',
            raw_model_name=kwargs["model_id"],
        )


def test_context_overflow_retries_same_provider_once(tmp_path: Path) -> None:
    router = _ContextRetryRouter()
    agent = _agent(tmp_path, router)
    answer = agent.ask("Создай ok.txt", model_id="test:model", force_task=True)
    assert answer == "Готово"
    assert router.calls[:2] == ["test:model", "test:model"]
    assert (agent.workspace.root / "ok.txt").read_text(encoding="utf-8") == "ok"


def test_runtime_configuration_uses_exact_instruct_model() -> None:
    example = (Path(__file__).parents[1] / ".env.example").read_text(encoding="utf-8")
    assert "LMSTUDIO_MODEL=qwen2.5-7b-instruct" in example
    assert "LMSTUDIO_MODEL=qwen2.5-coder-7b-instruct" not in example
