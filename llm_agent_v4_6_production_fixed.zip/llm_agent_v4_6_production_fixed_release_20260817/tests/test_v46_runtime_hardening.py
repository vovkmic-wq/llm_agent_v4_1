from __future__ import annotations

import json
from pathlib import Path

import pytest

from core.agent import Agent, AgentExecutionError
from core.config import settings
from core.memory import MemoryManager
from core.protocol import ProtocolError, ToolCall, decode_agent_response
from core.task_state import TaskStateManager
from core.workspace import WorkspaceManager
from providers.base import CompletionResult, ProviderError


class RecordingRouter:
    def __init__(self, response: str = "обычный ответ") -> None:
        self.response = response
        self.calls: list[dict] = []

    def call(self, **kwargs):
        self.calls.append(kwargs)
        return CompletionResult(text=self.response, raw_model_name=kwargs["model_id"])


def _agent(tmp_path: Path, router: RecordingRouter | None = None) -> Agent:
    return Agent(
        memory=MemoryManager(tmp_path / "memory"),
        router=router or RecordingRouter(),
        workspace=WorkspaceManager(
            tmp_path / "workspace",
            protected_globs=[".env", ".env.*", "*.key"],
            ignored_globs=["**/__pycache__", ".venv", ".venv/**"],
        ),
        planner_enabled=False,
        reviewer_enabled=False,
        execution_enabled=True,
        research_enabled=False,
    )


def _prepare_structural_project(agent: Agent, *, omit_main: bool = False) -> None:
    for directory in ("demo", "demo/config", "demo/src", "demo/src/demo", "demo/tests"):
        agent.workspace.make_directory(directory)
    agent.workspace.write_file("demo/config/config.yaml", "enabled: true\n")
    agent.workspace.write_file("demo/src/demo/__init__.py", "")
    agent.workspace.write_file("demo/tests/test_smoke.py", "def test_ok():\n    assert True\n")
    agent.workspace.write_file("demo/.env.example", "TOKEN=replace-me\n")
    if not omit_main:
        agent.workspace.write_file("demo/main.py", "print('ok')\n")
    agent.workspace.write_file(
        "demo/TECHNICAL_SPECIFICATION.md",
        """# ТЗ

Пример обязательной структуры:

```text
demo/
├── config/
│   └── config.yaml
├── src/
│   └── demo/
├── tests/
├── .env.example
└── main.py
```
""",
    )
    agent.project_context.set_active_project("demo")


def test_structural_classifier_is_read_only_but_not_repair() -> None:
    assert Agent._is_structural_audit("Проверь структуру файлов на соответствие ТЗ")
    assert Agent._is_structural_audit(
        "Проверь структуру по ТЗ, ничего не изменяй и не устанавливай"
    )
    assert not Agent._is_structural_audit(
        "Проверь структуру по ТЗ и исправь найденные ошибки"
    )


def test_executor_uses_updated_primary_system_prompt(tmp_path: Path) -> None:
    agent = _agent(tmp_path)
    built = agent.prompt_builder.build(
        "Проверь проект", project_context="SPEC", task_state="STATE"
    )
    assert "=== STRUCTURAL READ-ONLY AUDIT ===" in built.system_prompt
    assert "=== TASK CONTINUITY ===" in built.system_prompt
    assert "никогда не используй `tool_batch`" in built.system_prompt


@pytest.mark.parametrize(
    "query",
    [
        "Проверь структуру файлов на соответствие ТЗ",
        "Проверь структуру файлов по ТЗ, ничего не изменяй и не устанавливай",
    ],
)
def test_structural_audit_reads_spec_and_manifest_without_llm_or_gates(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, query: str
) -> None:
    router = RecordingRouter()
    agent = _agent(tmp_path, router)
    _prepare_structural_project(agent)

    def gates_must_not_run(*args, **kwargs):
        raise AssertionError("quality gates are forbidden for structural audit")

    monkeypatch.setattr(agent, "_run_quality_gates", gates_must_not_run)
    answer = agent.ask(query, force_task=True)

    assert "Структурный аудит: PASS" in answer
    assert "Quality gates: NOT_REQUESTED" in answer
    assert "Manifest до/после: IDENTICAL" in answer
    assert "TECHNICAL_SPECIFICATION.md" in answer
    assert router.calls == []
    assert agent.task_state.current is not None
    assert agent.task_state.current.status == "done"
    assert agent.task_state.current.task_kind == "structural_audit"
    assert agent.task_state.current.read_only is True


def test_structural_audit_does_not_infer_pass_from_green_gates(tmp_path: Path) -> None:
    router = RecordingRouter()
    agent = _agent(tmp_path, router)
    _prepare_structural_project(agent, omit_main=True)
    answer = agent.ask("Проверь структуру проекта по ТЗ", force_task=True)
    assert "Структурный аудит: FAIL" in answer
    assert "`main.py` | FAIL" in answer
    assert agent.task_state.current is not None
    assert agent.task_state.current.status == "failed"
    assert router.calls == []


def test_structural_manifest_detects_unjournaled_change(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    agent = _agent(tmp_path)
    _prepare_structural_project(agent)
    original = agent.workspace.build_manifest
    calls = 0

    def drifting_manifest(path: str = ".", *, max_entries: int = 20000):
        nonlocal calls
        calls += 1
        payload = original(path, max_entries=max_entries)
        if calls == 2:
            payload["files"] = {**payload["files"], "rogue.tmp": "f" * 64}
            payload["file_count"] += 1
            payload["sha256"] = "e" * 64
        return payload

    monkeypatch.setattr(agent.workspace, "build_manifest", drifting_manifest)
    answer = agent.ask("Проверь структуру проекта по ТЗ", force_task=True)
    assert "Структурный аудит: FAIL" in answer
    assert "Manifest до/после: DIFFERENT" in answer
    assert agent.task_state.current is not None
    assert agent.task_state.current.files_changed == ["rogue.tmp"]


def test_read_only_lock_rejects_install_before_permissions(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    agent = _agent(tmp_path)
    agent.task_state.start(
        "audit", task_kind="structural_audit", read_only=True, scope_confirmed=True
    )

    def permissions_must_not_run(*args, **kwargs):
        raise AssertionError("permission layer must not be reached")

    monkeypatch.setattr(agent.permissions, "authorize", permissions_must_not_run)
    payload, ok, mutated = agent._execute_tool(
        ToolCall(
            tool="environment.install_packages",
            arguments={"packages": ["requests"]},
            call_id="install-1",
        ),
        {},
    )
    assert ok is False
    assert mutated is False
    assert "READ_ONLY_LOCK" in payload


def test_manifest_includes_env_example_but_hides_secret(tmp_path: Path) -> None:
    workspace = WorkspaceManager(
        tmp_path / "workspace", protected_globs=[".env", ".env.*"]
    )
    (workspace.root / ".env.example").write_text("SAFE=x\n", encoding="utf-8")
    (workspace.root / ".env").write_text("SECRET=x\n", encoding="utf-8")
    manifest = workspace.build_manifest(".")
    assert ".env.example" in manifest["files"]
    assert ".env" not in manifest["files"]
    assert "SAFE=x" not in json.dumps(manifest)


def test_valid_tool_batch_alias_is_normalized() -> None:
    decoded = decode_agent_response(
        json.dumps(
            {
                "type": "tool_batch",
                "calls": [
                    {
                        "type": "tool",
                        "tool": "workspace.list_files",
                        "arguments": {"path": "."},
                        "call_id": "l1",
                    }
                ],
            }
        )
    )
    assert decoded.action is not None
    assert decoded.recovered is True
    assert decoded.recovery_method == "tool_batch_alias"


def test_malformed_tool_batch_alias_remains_fail_closed() -> None:
    with pytest.raises(ProtocolError):
        decode_agent_response(
            '{"type":"tool_batch","tool":"workspace.list_files","calls":[]}'
        )


@pytest.mark.parametrize(
    "query",
    ["Get-ChildItem |", "Get-FileHash .\\main.py |", "$x = Get-ChildItem`"],
)
def test_incomplete_powershell_fragments_do_not_call_router(
    tmp_path: Path, query: str
) -> None:
    router = RecordingRouter()
    answer = _agent(tmp_path, router).ask(query)
    assert "не выполнена" in answer.casefold()
    assert router.calls == []


def test_capability_dump_is_not_doctor_evidence(tmp_path: Path) -> None:
    router = RecordingRouter()
    answer = _agent(tmp_path, router).ask("model: qwen\ncontext_tokens: 32768")
    assert "не являются результатом `/doctor`" in answer
    assert router.calls == []


def test_russian_language_guard_rejects_cjk_without_second_call(tmp_path: Path) -> None:
    router = RecordingRouter("这是中文回答")
    answer = _agent(tmp_path, router).ask("Расскажи короткую шутку")
    assert "отклонён языковым контролем" in answer
    assert "这" not in answer
    assert len(router.calls) == 1


def test_status_followup_uses_task_state_without_router(tmp_path: Path) -> None:
    router = RecordingRouter()
    agent = _agent(tmp_path, router)
    agent.task_state.start("Исправить проект", requested_target="demo")
    agent.task_state.mark_status(
        "failed", code="provider_failure", message="Модель недоступна"
    )
    answer = agent.ask("Что теперь делать?")
    assert "Статус: failed" in answer
    assert "Модель недоступна" in answer
    assert "/resume" in answer
    assert router.calls == []


def test_repeated_read_is_blocked_without_revision(tmp_path: Path) -> None:
    agent = _agent(tmp_path)
    agent.workspace.write_file("readme.txt", "ok\n")
    agent.task_state.start("inspect", scope_confirmed=True)
    evidence: dict = {}
    first = ToolCall(
        tool="workspace.read_file",
        arguments={"path": "readme.txt"},
        call_id="read-1",
    )
    second = first.model_copy(update={"call_id": "read-2"})
    assert agent._execute_tool(first, evidence)[1] is True
    payload, ok, _ = agent._execute_tool(second, evidence)
    assert ok is False
    assert "без изменения source/environment revision" in payload


def test_provider_failure_persists_resumable_state_for_new_process(
    tmp_path: Path,
) -> None:
    class FailingRouter:
        def call(self, **kwargs):
            raise ProviderError("model load failed", code="model_load_failed")

    memory_dir = tmp_path / "memory"
    workspace = WorkspaceManager(tmp_path / "workspace")
    agent = Agent(
        memory=MemoryManager(memory_dir),
        router=FailingRouter(),
        workspace=workspace,
        planner_enabled=False,
        reviewer_enabled=False,
        execution_enabled=False,
        research_enabled=False,
    )
    with pytest.raises(ProviderError):
        agent.ask("Создай файл result.txt", force_task=True)
    failed = agent.task_state.current
    assert failed is not None
    assert failed.status == "failed"
    assert failed.metadata["last_failure"]["code"] == "provider_failure"

    restarted = Agent(
        memory=MemoryManager(memory_dir),
        router=RecordingRouter(),
        workspace=workspace,
        planner_enabled=False,
        reviewer_enabled=False,
        execution_enabled=False,
        research_enabled=False,
    )
    restored = restarted.task_state.restore_latest_resumable()
    assert restored is not None
    assert restored.task_id == failed.task_id
    assert restored.goal == "Создай файл result.txt"


def test_protocol_and_round_limit_failures_remain_resumable(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(
        settings.agent.orchestration, "protocol_repairs_per_model", 0
    )
    monkeypatch.setattr(settings.agent.orchestration, "protocol_max_total_repairs", 0)
    monkeypatch.setattr(
        settings.agent.orchestration, "protocol_max_provider_fallbacks", 0
    )
    protocol_agent = _agent(tmp_path / "protocol", RecordingRouter("plain text"))
    protocol_agent.execution.enabled = False
    with pytest.raises(AgentExecutionError):
        protocol_agent.ask("Создай файл protocol.txt", force_task=True)
    assert protocol_agent.task_state.current is not None
    assert protocol_agent.task_state.current.status == "failed"
    assert (
        protocol_agent.task_state.current.metadata["last_failure"]["code"]
        == "protocol_failure"
    )

    monkeypatch.setattr(settings.agent.orchestration, "max_steps", 1)
    tool_response = json.dumps(
        {
            "type": "tool",
            "tool": "workspace.list_files",
            "arguments": {"path": "."},
            "call_id": "list-1",
        }
    )
    round_agent = _agent(tmp_path / "round", RecordingRouter(tool_response))
    round_agent.execution.enabled = False
    with pytest.raises(AgentExecutionError):
        round_agent.ask("Создай файл later.txt", force_task=True)
    assert round_agent.task_state.current is not None
    assert round_agent.task_state.current.status == "failed"
    assert (
        round_agent.task_state.current.metadata["last_failure"]["code"]
        == "round_limit"
    )


def test_cli_keyboard_interrupt_keeps_loop_alive_without_traceback(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    import main as cli

    class Switch:
        enabled = False

    class FakeAgent:
        workspace = type("Workspace", (), {"root": Path("C:/workspace")})()
        project_context = type("Context", (), {"active_project": "demo"})()
        execution = Switch()
        research = Switch()

        def __init__(self) -> None:
            self.interrupted = False

        def ask(self, *args, **kwargs):
            raise KeyboardInterrupt

        def interrupt_current_task(self) -> None:
            self.interrupted = True

    fake = FakeAgent()
    inputs = iter(["/task Сделай работу", "/exit"])
    monkeypatch.setattr(cli, "Agent", lambda **kwargs: fake)
    monkeypatch.setattr("builtins.input", lambda prompt="": next(inputs))
    cli.main()
    output = capsys.readouterr().out
    assert "checkpoint сохранён" in output
    assert "Traceback" not in output
    assert fake.interrupted is True


def test_unfinished_task_can_be_restored_after_new_done_task(tmp_path: Path) -> None:
    manager = TaskStateManager(tmp_path / "task_state.json")
    failed = manager.start("Первая задача")
    manager.mark_status("failed", code="protocol", message="invalid JSON")
    manager.start("Вторая задача")
    manager.finish(True)
    restored = manager.restore_latest_resumable()
    assert restored is not None
    assert restored.task_id == failed.task_id
    assert restored.status == "failed"


def test_interrupt_and_embedded_command_are_safe(tmp_path: Path) -> None:
    router = RecordingRouter()
    agent = _agent(tmp_path, router)
    agent.task_state.start("Долгая задача")
    agent.interrupt_current_task()
    assert agent.task_state.current is not None
    assert agent.task_state.current.status == "interrupted"
    assert agent.task_state.current.metadata["last_failure"]["resumable"] is True

    answer = agent.ask("Покажи сведения /doctor и продолжи")
    assert "не выполнена" in answer.casefold()
    assert router.calls == []
