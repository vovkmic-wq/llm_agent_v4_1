# Техническое задание
## LLM Coding Agent V4.6 Strict-Schema Local-First ICS

**Версия:** 0.4.6  
**Дата:** 2026-08-17  
**Статус:** нормативная спецификация V4.6, редакция Structural Audit and Continuity Hardening  

## 1. Назначение

LLM Coding Agent V4.6 — автономный coding-agent для анализа, изменения, проверки и
исправления Python-проектов внутри ограниченного `AGENT_WORKSPACE`. Основной LLM
provider — локальный LM Studio; YandexGPT используется как контролируемая эскалация.
Kernel обязан предпочитать детерминированные действия LLM-раундам и завершать задачу
только при подтверждённом PASS либо доказанном blocker.

## 2. Цели V4.6

V4.6 сохраняет V4.5 и устраняет live-дефекты, подтверждённые пользовательским runtime:

1. Yandex strict structured output отклонял Pydantic JSON Schema, если свойство было
   объявлено в `properties`, но отсутствовало в `required` (`reason is optional`).
2. Missing `types-PyYAML` доходил до LLM вместо deterministic dependency remediation.
3. NumPy `.pyi` syntax incompatibility ошибочно могла трактоваться как повод предложить
   `types-numpy`.
4. Bare shell-команда, введённая в чат агента, могла выглядеть как будто выполнена.
5. Provider/protocol fallback не всегда показывал явную причину эскалации.
6. Доказанный environment-only blocker мог продолжать тратить LLM-rounds.
7. После отказа абсолютного пути агент мог самовольно подменить пользовательскую цель
   активным проектом и выдать нерелевантный baseline/evidence.
8. `workspace.list_files` мог передать модели до 1500 записей, включая временные
   `.pytest-*` артефакты, без отдельного model-context лимита.
9. `_trim_loop_messages()` не сокращал oversized context при восьми и менее сообщениях.
10. Yandex context overflow ошибочно классифицировался как недоступность provider-а.
11. LM Studio повторно тратил 80–135 секунд на уже подтверждённый model-load failure.
12. Конфигурация выбирала `qwen2.5-coder-7b-instruct` вместо явно заданной пользователем
    `qwen2.5-7b-instruct` Q4_K_M и не учитывала обнаруживаемый context window модели.
13. Естественная формулировка «проверь структуру файлов на соответствие ТЗ» ошибочно
    попадала в общий engineering loop, достигала потолка 36 LLM-раундов и вызывала
    нерелевантные проверки и попытки установки packages.
14. Явный `READ_ONLY_AUDIT` объявлялся завершённым только по Ruff/compileall/mypy/pytest,
    без чтения ТЗ, списка файлов и сопоставления структуры требованиям.
15. `files_changed=[]` учитывал только зарегистрированные mutations, но не доказывал
    физическую неизменность workspace при запуске tools, способных создавать cache/pyc.
16. Задача с protocol/round/interruption failure могла быть потеряна или перезаписана
    состоянием `done`, после чего `/resume` отвечал, что незавершённой задачи нет.
17. Follow-up «что теперь делать», «продолжи предыдущую задачу» и «дай текущий статус»
    мог уходить в новый QUICK_CHAT и терять цель, evidence и последнюю ошибку задачи.
18. Русскоязычный диалог мог получить фрагменты ответа на китайском и нерелевантные
    советы по Poetry/настройке окружения вместо продолжения активной проверки.
19. `KeyboardInterrupt` во время provider request выходил из главного CLI с traceback
    вместо безопасной отмены запроса, checkpoint и возврата к приглашению.
20. Строго распознанный, но распространённый alias `type=tool_batch` исчерпывал protocol
    repair budget, хотя мог быть однозначно нормализован в `type=tools` при наличии calls.
21. Bare/incomplete PowerShell pipeline, введённый в chat частями, мог инициировать
    длительный LLM-запрос вместо немедленного детерминированного ответа «не выполнено».
22. Простые follow-up ответы локальной Qwen занимали 79–145 секунд и повторяли общие
    инструкции пользователю вместо выполнения доступных read-only действий.

## 3. Поддерживаемая среда

- Windows 10/11 + PowerShell — основная пользовательская среда.
- Python >= 3.10.
- Linux/macOS — если конкретное execution-действие не платформенно-зависимо.
- LM Studio OpenAI-compatible server.
- Yandex AI Studio OpenAI-compatible Chat Completions API.

## 4. Direct dependencies

Runtime:

- `PyYAML >=6.0,<7.0`;
- `httpx >=0.27,<1.0`;
- `python-dotenv >=1.0,<2.0`;
- `pydantic >=2.6,<3.0`;
- `tomli >=2.0` только для Python <3.11.

Quality/build:

- `pytest >=8.0,<10.0`;
- `ruff >=0.4,<1.0`;
- `mypy >=1.9,<3.0`;
- `setuptools >=68`;
- `wheel >=0.45`.

Dependency remediation allow-list по умолчанию:

- `types-PyYAML`;
- `types-requests`.

`types-numpy` запрещён: kernel должен диагностировать совместимость Python target,
фактического interpreter, mypy и встроенных NumPy typing stubs.

## 5. Архитектурные роли

### 5.1 Kernel

Kernel отвечает за request classification, baseline, FailureDigest, Incident/IAP,
workspace safety, retrieval, strict-schema compilation, protocol validation,
dependency remediation, source/environment revisions, verification, evidence,
convergence и finalization.

### 5.2 LLM

LLM принимает только недетерминированные инженерные решения: root-cause analysis после
kernel evidence, минимальная source mutation, feature planning и semantic Review/Safety.

## 6. Request modes

- `QUICK_CHAT` — короткий чат без engineering harness.
- `CONTEXTUAL_CHAT` — bounded project context без tools.
- `ENGINEERING_TASK` — baseline + Incident/IAP + tools + evidence.
- `READ_ONLY_AUDIT` — deterministic evidence collection -> compliance report -> Final
  без mutation; quality gates выполняются только если они явно входят в предмет аудита.

Bare shell-команда в conversational input не выполняется. Kernel обязан явно сообщить,
что команда не была запущена, и предложить PowerShell либо `/task`.

### 6.1 Классификация структурного аудита

Запрос классифицируется как `READ_ONLY_AUDIT`, если он просит проверить, проанализировать,
сверить или провести аудит структуры/состава файлов/проекта по ТЗ и не содержит явного
требования создать, изменить, удалить, установить или исправить. Явное «ничего не
изменяй/не устанавливай/только сообщи» усиливает режим, но не является обязательным для
правильной классификации.

Классификация выполняется kernel-ом до Planner, baseline и provider call. Неоднозначность
между audit и mutation разрешается в пользу read-only: агент сначала сообщает найденные
несоответствия и запрашивает отдельное явное разрешение на исправление.

### 6.2 Детерминированный контракт структурного аудита

Обязательная последовательность:

1. подтвердить requested target и источник актуального ТЗ;
2. прочитать ТЗ либо вернуть доказанный blocker `specification_unavailable`;
3. получить bounded нерекурсивный список корня проекта;
4. извлечь из ТЗ проверяемые требования к файлам, каталогам, entry points, manifests,
   tests, config и документации;
5. выполнить только targeted bounded listings/reads/hash операций;
6. построить матрицу `requirement -> expected path/role -> evidence -> PASS/FAIL/UNKNOWN`;
7. отдельно показать quality-gate status, если gates были явно запрошены; он не заменяет
   structural evidence;
8. завершить `done` только когда каждый обязательный структурный критерий имеет evidence.

В `READ_ONLY_AUDIT` действует kernel allow-list только для read/list/stat/hash и иных
доказанно не изменяющих операций. Запрещены source/config writes, directory creation,
delete, terminal execution, environment/package tools, Ruff `--fix` и любые install.
Повтор уже зелёного gate без новой revision запрещён. По умолчанию простой structural
audit использует не более шести tool calls, одного batch read и не вызывает LLM; если
семантическое сопоставление нельзя выполнить детерминированно, допускаются максимум два
bounded LLM-rounds без tools mutation и provider handoff.

До и после аудита kernel строит отфильтрованный manifest `relative_path + SHA-256` для
production source/config/tests/docs, исключая `.venv`, caches, build/dist и runtime state.
`files_changed=[]` разрешено утверждать только при равенстве manifests. Один список хешей
без полных относительных путей и without before/after comparison не является evidence.

## 7. Baseline-first

Любая executable mutation/repair engineering task начинает read-only baseline до
Planner/Executor. Чистый structural audit следует разделу 6.2 и не запускает общий
baseline, если пользователь отдельно не просил code-quality/tests:

1. Ruff без `--fix`;
2. compileall;
3. mypy;
4. pytest.

Baseline не устанавливает packages и не меняет source/config. В строгом read-only режиме
любые caches направляются во временный каталог вне requested target либо отключаются.
`compileall`, создающий `.pyc`, заменяется не записывающим syntax/AST check. Pytest/Ruff/
mypy запускаются с отключённым project-local cache. Если физическая неизменность не может
быть обеспечена, gate не запускается и указывается `UNKNOWN` с причиной.

До baseline kernel обязан подтвердить идентичность фактической цели: requested path,
workspace root и active project должны однозначно относиться к одному проекту. Если
пользователь указал абсолютный путь вне workspace, baseline активного проекта запрещено
использовать как evidence для этой цели. Kernel возвращает `path_outside_workspace` с
`requested_path`, `workspace_root` и безопасным способом продолжения.

## 8. FailureDigest V4.6

FailureDigest должен различать:

- source/test failure;
- missing allow-listed type stub;
- generic dependency failure;
- third-party typing environment incompatibility;
- provider/protocol/infrastructure failure.

Для сообщения вида `Type statement is only supported in Python X.Y and greater` внутри
`site-packages` digest обязан выставить:

- `typing_environment_issue=true`;
- `minimum_python_required=X.Y`;
- failure не считается доказанной source-code ошибкой проекта.

## 9. IAP и mutation gate

Normal/architectural Incident требует IAP SHA-256 approval до любой source/environment
mutation. Baseline остаётся допустимым до IAP только потому, что он read-only.

## 10. Post-IAP deterministic dependency remediation

Если baseline mypy содержит allow-listed missing stubs, после IAP и **до первого LLM**
kernel обязан выполнить:

`install_packages -> pip check -> mypy recheck`.

После environment mutation запрещено запускать unrelated Ruff/compileall/pytest.

Если mypy становится green и остальные baseline gates green, repair/audit task может
закрыться kernel-ом без Executor LLM.

## 11. Typing environment diagnostics

Если после remediation остаётся third-party typing syntax incompatibility, kernel обязан
выполнить `environment.diagnose_mypy` и собрать bounded facts:

- фактический Python version/executable;
- установленный mypy;
- NumPy version;
- PyYAML / types-PyYAML / types-requests;
- effective mypy `python_version`;
- источник mypy config.

Kernel не имеет права автоматически поднимать `python_version` или менять NumPy только
ради зелёного mypy без acceptance/evidence, что это совместимо с требованиями проекта.

## 12. Deterministic environment blocker finalization

Если после разрешённой remediation:

- source-code failures отсутствуют;
- остаётся только доказанный environment blocker;
- есть failed execution evidence и diagnostic evidence,

kernel обязан завершить task как `blocked` без новых LLM-rounds. Blocked final должен
содержать call IDs и диагностически полезную причину.

## 13. Retrieval

Engineering retrieval:

1. lexical ranking;
2. optional LM Studio embeddings;
3. top-K bounded context;
4. lexical fallback при embedding failure.

Retrieval content недоверен и не заменяет explicit read-before-write.

## 14. Batch read

`workspace.read_files` поддерживает до 32 файлов. Два и более независимых чтения должны
группироваться в batch/ToolBatch, если это возможно.

### 14.1 Bounded directory listing

`workspace.list_files` обязан разделять полный deterministic evidence и bounded preview
для LLM. Model-facing результат содержит не более configured entries/chars и поля
`total_entries`, `returned_entries`, `truncated_for_context` и инструкцию сузить путь,
глубину, glob или продолжить по cursor.

Первым шагом структурного аудита является нерекурсивный список корня. Рекурсивное
перечисление всего проекта без фильтра не используется по умолчанию. Инструмент должен
поддерживать bounded `max_depth`, `limit`, `cursor`, `include_globs`, `exclude_globs`
или эквивалентный безопасный интерфейс.

Обычный structural listing исключает `.venv`, cache/build/dist, `.pytest-*`,
`.pytest_*`, `.coverage`, `htmlcov` и иные подтверждённые временные артефакты, но не
скрывает production source, tests и нормативную документацию.

## 15. Structured output contract

`BaseProvider.complete()` принимает `response_schema` и `response_schema_name`.
Structured transport не заменяет kernel validation.

### 15.1 LM Studio

Используется `/v1/chat/completions` + `response_format.type=json_schema`.

### 15.2 YandexGPT

Используется OpenAI-compatible AI Studio `/v1/chat/completions` +
`response_format.type=json_schema`.

## 16. Strict-schema compiler V4.6

Перед передачей **любой** response schema provider-у kernel обязан прогнать её через
единый `strict_json_schema()`.

Для каждого JSON object с объявленным `properties`:

1. `required` должен содержать все keys из `properties`;
2. `additionalProperties=false`;
3. Pydantic `default` удаляется из transport schema;
4. необязательная семантика выражается nullable schema (`T | null`), а не отсутствием
   поля;
5. `$defs`, `definitions`, `items`, `anyOf`, `oneOf`, `allOf` обрабатываются рекурсивно;
6. открытые map-объекты без `properties` (например tool `arguments`) не должны
   ошибочно закрываться.

Эта политика применяется к Executor, Planner, Reviewer, Safety и Reporter schema.

## 17. Protocol schema

Executor transport envelope должен поддерживать `tool`, `tools`, `final`. Все transport
fields присутствуют как required; нерелевантные fields передаются `null`. После parse
Pydantic проверяет семантику выбранного action.

Mutation `reason` для source/environment changes обязан иметь связь с
`failure:<signature>` или `acceptance:<criterion>`.

## 18. Kernel protocol validation

После HTTP 200:

1. извлечь text;
2. parse JSON;
3. conservative syntax-only recovery при необходимости;
4. Pydantic validation;
5. semantic invariants;
6. только затем tool execution.

## 19. Protocol recovery

Допустимы только семантически нейтральные операции:

- извлечение JSON candidate/fence;
- удаление trailing comma;
- `ast.literal_eval` dict -> JSON.
- нормализация `type="tool_batch"` в `type="tools"` только когда объект уже содержит
  корректный непустой `calls` и не содержит конфликтующих `tool`/`final` данных.

Запрещено придумывать missing field/tool/reason/evidence.
Если alias неоднозначен или `calls` отсутствует, action отклоняется без выполнения.

## 20. Protocol budgets

Protocol repair отделён от semantic budget:

- `protocol_repairs_per_model=1`;
- `protocol_max_total_repairs=3`;
- `protocol_max_provider_fallbacks=1`.

Protocol-control round не увеличивает semantic no-progress counter.

## 21. Explicit escalation telemetry

При переключении provider/model console/event log обязан содержать причину:

- `reason=provider_failure`;
- `reason=protocol_failure code=<...>`;
- semantic reason (`cycles/read-only/time`).

Raw model response и credentials не должны попадать в diagnostic log по умолчанию.

### 21.1 End-to-end context budget telemetry

Перед каждым provider call kernel рассчитывает окончательный размер system prompt,
messages, response schema и reserves. Логируются bounded поля
`estimated_tokens_before`, `estimated_tokens_after`, `effective_context_tokens`,
`effective_input_budget`, `output_reserve_tokens`, `safety_margin_tokens`, число
удалённых сообщений и сокращённых tool results. Полный oversized payload в event log не
записывается.

## 22. Yandex HTTP diagnostics

HTTP 4xx/5xx должен сохранять bounded sanitized server `code/status/message`, если
доступно. Authorization/API key и request secret content логировать запрещено.

HTTP 400 с `number of input tokens must be no more`, `context length`,
`maximum context` или эквивалентным сообщением классифицируется как
`context_length_exceeded`, а не `provider_unavailable`. Kernel один раз выполняет
детерминированное compaction и повторяет запрос к тому же provider-у, не расходуя
provider-fallback budget. Подтверждённый server limit обновляет runtime capability cache.

## 23. Workspace safety

Обязательны workspace confinement, symlink/path escape protection, explicit
read-before-write, optimistic hash concurrency, atomic writes где поддерживается,
protected paths и idempotent `make_directory`.

Requested target является scope invariant TaskState. После `path_outside_workspace`
запрещено молча заменять цель active project, текущей директорией или похожим именем.
Продолжение возможно только после явного изменения цели/workspace пользователем. Это
требование не ослабляет запрет абсолютных путей в workspace tools.

## 24. Source/environment revisions

- source revision меняется при фактической source/config mutation;
- environment revision — при package/stub install;
- environment change не запускает source-only gates.

## 25. Verification matrix

Source mutation:

`targeted Ruff -> aggregated compileall -> targeted mypy -> failed pytest selectors -> full gates`.

Environment mutation:

`install -> pip check -> affected gate only`.

Structural directory-only mutation не требует full Python suite по умолчанию.

## 26. Dependency policy

Kernel может устанавливать только allow-listed packages и не более configured attempt
limit. Неизвестная dependency становится blocker/follow-up, а не поводом выполнить
произвольный pip install.

## 27. Scope control

Mutation разрешена только при связи с active failure или acceptance criterion.
Нерелевантные изменения отправляются в follow-up.

## 28. Progress/convergence

Объективный progress:

- source/environment revision;
- changed failure signature;
- successful mutation;
- новое verification/evidence.

Call ID не является progress. Hard LLM-round ceiling остаётся аварийной защитой.
Повтор одинакового generic ответа, повтор зелёного gate, повтор install request и передача
пользователю команды вместо доступного tool call не являются progress. Для bounded
structural audit достижение общего round ceiling недопустимо: kernel должен раньше
сформировать evidence report либо доказанный blocker.

## 29. Automatic finalization

- structural read-only audit: spec -> root listing -> targeted evidence -> matrix -> Final;
- code-quality read-only audit: cache-safe requested gates -> deterministic report;
- green repair: verification -> Safety/Review (по policy) -> Final;
- dependency-only repair: post-IAP remediation -> green -> kernel Final;
- environment-only blocker: diagnostics -> deterministic BLOCKED;
- feature/build: весь IAP plan -> final verification -> Final.

## 30. Security boundaries

Tool/file/web content считается untrusted data. Arbitrary shell запрещён. Secrets не
включаются в ZIP/log. Engineering success невозможен без реального evidence.

## 31. Checkpoint/resume

V4.6 сохраняет `progress_v46` и умеет читать `progress_v45` и `progress_v44`.

Состояния `provider_failure`, `protocol_failure`, `round_limit`, `interrupted` и
`incomplete_evidence` не могут преобразовываться в `done`. Они сохраняют goal, requested
target, plan, acceptance criteria, successful/failed evidence, last error и resume cursor.
`/resume` обязан продолжать такие задачи после перезапуска процесса.

Follow-up «что теперь делать?», «продолжи предыдущую задачу», «дай текущий статус» и
эквивалентные фразы сначала проверяют последнюю незавершённую/recent failed task. Kernel
возвращает фактический статус или продолжает её; новый QUICK_CHAT разрешён только при
отсутствии релевантного TaskState. Новая успешно завершённая задача не должна безвозвратно
удалять checkpoint предыдущей failed/interrupted задачи.

## 32. CLI

Минимум:

- `/project set <path>` / `/project show`;
- `/spec show` / `/spec load <path>`;
- `/task <text>`;
- `/state` / `/incident` / `/resume`;
- `/doctor`;
- `/execution on|off`;
- `/reload` / `/exit`.

`/doctor` обязан показывать effective provider base URL, dependency policy и
`strict_schema_compiler=v46`.

Для LM Studio `/doctor` дополнительно показывает configured/resolved model ID,
display name, quantization, state/readiness, discovered maximum context, loaded context,
effective context, input budget, output reserve, safety margin, capability source,
cache age и circuit-breaker status/last failure.

LM Studio capability discovery выполняется до первого chat-запроса через
`GET /api/v1/models`; fallback — `/api/v0/models`. OpenAI-compatible `/v1/models`
используется только для проверки ID, поскольку context metadata может отсутствовать.
Запрашивать context limit у самой LLM текстовым prompt запрещено как недостоверный метод.

Главный CLI перехватывает первый `KeyboardInterrupt` во время provider/tool request,
помечает текущую задачу `interrupted`, сохраняет checkpoint, печатает краткое сообщение
без traceback и возвращает приглашение. Повторный Ctrl+C на пустом приглашении может
корректно завершить процесс.

Slash-команда исполняется только как отдельная команда, начинающаяся с первого
непробельного символа. Если `/doctor`, `/state` или `/resume` приклеены к обычному тексту,
kernel не выдаёт ложный diagnostic result и явно сообщает, что slash-команда не была
исполнена. Bare shell и незавершённые pipelines с trailing `|`, backtick или continuation
prompt распознаются без LLM и помечаются `NOT_EXECUTED`.

## 33. Functional requirements

FR-001..FR-038 из V4.5 сохраняются. V4.6 добавляет:

- **FR-039:** единый strict-schema compiler применяется ко всем response roles.
- **FR-040:** каждый declared object property находится в `required` strict transport.
- **FR-041:** optional semantics представлены nullable values, не omitted fields.
- **FR-042:** live regression `reason is optional` не должен воспроизводиться.
- **FR-043:** allow-listed mypy stubs исправляются после IAP до первого LLM.
- **FR-044:** `types-numpy` никогда не предлагается/не устанавливается kernel-ом.
- **FR-045:** third-party NumPy `.pyi` syntax issue классифицируется environment issue.
- **FR-046:** kernel умеет диагностировать actual Python/mypy target/NumPy/stubs.
- **FR-047:** environment-only blocker завершается детерминированно без LLM.
- **FR-048:** bare shell command в chat path явно не выполняется.
- **FR-049:** provider fallback логирует `reason=provider_failure`.
- **FR-050:** protocol fallback логирует `reason=protocol_failure` и error code.
- **FR-051:** dependency manifests pyproject/requirements согласованы.
- **FR-052:** `/doctor` сообщает `strict_schema_compiler=v46`.
- **FR-053:** requested target фиксируется в TaskState и не подменяется после scope error.
- **FR-054:** baseline evidence валиден только для подтверждённой requested target.
- **FR-055:** model-facing `list_files` имеет отдельный entries/chars budget.
- **FR-056:** structural listing по умолчанию отсекает `.pytest-*`/coverage/temp artifacts.
- **FR-057:** context trim соблюдает budget при любом числе сообщений, включая 2–8.
- **FR-058:** oversized request не отправляется provider-у после final preflight guard.
- **FR-059:** context overflow повторяется один раз на том же provider после compaction.
- **FR-060:** model-load failure открывает session circuit breaker с configured cooldown.
- **FR-061:** configured model выбирается только по exact API ID без instruct/coder подмены.
- **FR-062:** LM Studio context/capabilities обнаруживаются через API до первого chat.
- **FR-063:** capability cache keyed по provider/base URL/exact model ID и инвалидируется
  при `/reload`, смене model/base URL или loaded instance.
- **FR-064:** effective input budget учитывает loaded context, output reserve и margin.
- **FR-065:** внутренний context limit может только сужать discovered provider limit.
- **FR-066:** `/doctor` публикует model capability, budget и circuit-breaker diagnostics.
- **FR-067:** простой structural audit использует root-first и targeted bounded reads.
- **FR-068:** giant tool evidence хранится отдельно от компактного model preview.
- **FR-069:** provider errors различают model load, context overflow, auth и transport.
- **FR-070:** текстовый self-report LLM о context window не считается evidence.
- **FR-071:** natural-language structural audit распознаётся без обязательной фразы
  «ничего не изменяй» и до любого provider call.
- **FR-072:** structural audit не запускает общий baseline и dependency remediation по
  умолчанию.
- **FR-073:** read-only TaskState механически блокирует все mutation/install tools.
- **FR-074:** structural PASS требует прочитанного ТЗ, root listing и evidence matrix.
- **FR-075:** green Ruff/compileall/mypy/pytest не заменяют structural compliance evidence.
- **FR-076:** physical read-only подтверждается full-path before/after manifests.
- **FR-077:** interrupted/protocol/round-limit task остаётся resumable и не получает done.
- **FR-078:** follow-up status/resume phrases привязываются к релевантному TaskState.
- **FR-079:** первый Ctrl+C отменяет текущий request без traceback и сохраняет checkpoint.
- **FR-080:** русский input даёт русский final; mixed-language drift проходит repair либо
  заменяется детерминированным русским fallback.
- **FR-081:** допустимый `tool_batch` alias нормализуется семантически нейтрально; любой
  неоднозначный unknown action остаётся fail-closed.
- **FR-082:** bare/incomplete shell fragment не вызывает Router и явно не исполняется.
- **FR-083:** простой structural audit имеет отдельный tool/LLM budget и не достигает
  общего потолка 36 rounds.
- **FR-084:** final audit report содержит scope, spec source/hash, evidence matrix, gaps,
  отдельно gates, mutation manifest comparison и итог PASS/FAIL/BLOCKED.
- **FR-085:** `files_changed=[]` формируется по filesystem manifest, а не только mutation
  journal.
- **FR-086:** модель не просит пользователя вручную выполнять доступные ей read-only
  действия и не выдаёт предложенную команду за результат.
- **FR-087:** одинаковые gates/install/read actions без новой evidence/revision пресекаются
  kernel-ом до следующего provider call.
- **FR-088:** поля capability diagnostics, введённые как обычный chat, не считаются
  результатом `/doctor` и не вызывают продолжение нерелевантной старой задачи.
- **FR-089:** state хранит последний failure code/message и указывает точную команду
  безопасного продолжения.
- **FR-090:** final не может содержать unsupported compliance claim или generic checklist
  вместо фактического результата.

## 34. Non-functional requirements

- PEP 8 / Ruff-compatible style;
- max Python line length 100;
- type hints production code;
- deterministic kernel branches;
- bounded logs/context;
- Python >=3.10;
- package/wheel build;
- no `.env`, caches, runtime Incident state in release ZIP;
- actionable errors;
- no unsupported PASS claims.
- provider-specific fail-closed context guard до любого сетевого LLM-вызова;
- bounded tool/event payloads независимо от количества сообщений;
- exact target identity и exact model identity;
- capability discovery не увеличивает внутренний memory budget автоматически.
- structural audit остаётся bounded, physically read-only и evidence-complete;
- русскоязычный task/follow-up не содержит необъяснимых фрагментов на другом языке;
- user cancellation не завершает CLI аварийно и не теряет TaskState;
- PASS/FAIL/BLOCKED имеют раздельные, проверяемые критерии и не подменяются `done`.

## 35. Mandatory automated tests V4.6

1. recursive strict schema has no optional declared properties;
2. exact `reason` field is required+nullable;
3. strict ToolCall/Final envelopes decode via Pydantic;
4. role-specific Pydantic schemas are strictified before Router;
5. NumPy third-party syntax error => environment issue, no `types-numpy`;
6. types-PyYAML remediation uses install -> pip check -> mypy only;
7. remediation can finalize green before LLM;
8. environment-only blocker finalizes without LLM;
9. bare shell command does not call Router;
10. dependency manifests remain consistent;
11. all V4.5 regression tests remain green;
12. five real-subprocess scenarios remain green.
13. trim соблюдает budget при двух крупных tool results и `len(messages) <= 8`;
14. `list_files` на 1500 entries даёт bounded model preview;
15. provider call не происходит выше effective input budget;
16. Yandex `got 85240` классифицируется как context overflow и retry same-provider;
17. внешний absolute path не заменяется active project;
18. baseline другого проекта не считается evidence requested target;
19. `.pytest-*`, `.pytest_*`, `.venv`, cache/build artifacts pruned из listing;
20. LM Studio model-load failure открывает session circuit breaker;
21. missing configured model ID останавливается до chat request;
22. exact `qwen2.5-7b-instruct` не заменяется coder-вариантом;
23. `/api/v1/models` loaded context имеет приоритет над theoretical maximum;
24. `/api/v0/models` используется как capability fallback;
25. output reserve и safety margin входят в effective budget;
26. capability cache keyed и инвалидируется при смене модели/`/reload`;
27. confirmed provider limit обновляет runtime capability;
28. scripted structural-audit scenario не превышает budget и сохраняет target scope.
29. фраза «проверь структуру файлов на соответствие ТЗ» без запрета mutation выбирает
    `READ_ONLY_AUDIT`, делает zero install/write calls и не вызывает общий baseline;
30. structural audit читает ТЗ, root listing и создаёт полную evidence matrix;
31. четыре green gates без structural evidence не позволяют получить structural PASS;
32. read-only tool allow-list отклоняет install/write/delete/terminal даже при таком
    action от LLM;
33. before/after manifests с полными relative paths подтверждают отсутствие mutations;
34. protocol/round-limit failure сохраняет resumable checkpoint и `/resume` работает
    после нового процесса;
35. «что теперь делать?» после failure возвращает last error и next safe action без
    нового generic chat;
36. русский follow-up не содержит CJK drift и не предлагает нерелевантный Poetry;
37. Ctrl+C во время mocked provider request не печатает traceback и сохраняет task;
38. exact `tool_batch` + valid calls нормализуется, malformed alias остаётся blocked;
39. incomplete PowerShell pipeline не вызывает provider;
40. повтор green gates/install request без revision отклоняется как no-progress;
41. final structural report различает structural status и quality-gate status;
42. isolated diagnostic key/value input не подделывает `/doctor` evidence;
43. live-like scripted scenario завершается до dedicated audit budget, без handoff и
    без механического потолка 36 rounds.

## 36. Acceptance criteria V4.6

Релиз готов, если:

1. full non-live normal/regression suite PASS;
2. 5/5 real-subprocess tests PASS отдельно;
3. compileall PASS;
4. AST parse всех Python-файлов PASS;
5. line length >100 = 0;
6. dependency manifests согласованы и не содержат `types-numpy`;
7. runtime dependencies импортируются в доступной test environment;
8. wheel 0.4.6 собирается и импортируется вне source tree;
9. production ZIP очищен от `.env`, cache/runtime state;
10. тесты повторены на распакованном production ZIP;
11. live LM Studio/Yandex tests остаются opt-in и не заявляются PASS без credentials/server;
12. недоступный внешний package index явно фиксируется как ограничение test environment.
13. requested target подтверждена до baseline и не подменяется после scope error;
14. ни один сериализованный LLM request не превышает effective input budget;
15. `list_files` и event log остаются bounded на 1500+ filesystem entries;
16. context overflow не объявляется общей недоступностью provider chain;
17. repeated LM Studio model-load failure не создаёт повторную 80–135 s задержку в
    пределах circuit-breaker cooldown;
18. рабочая конфигурация использует `LMSTUDIO_MODEL=qwen2.5-7b-instruct` для явно
    выбранной Qwen 2.5 7B Instruct Q4_K_M;
19. LM Studio API подтверждает для текущего окружения max/loaded context 32768;
20. input budget учитывает output reserve и safety margin, а internal limit 10000 не
    расширяется до 32768 автоматически;
21. `/doctor` содержит достаточную capability/budget/scope диагностику.
22. естественный structural audit завершается доказанным PASS/FAIL/BLOCKED и никогда не
    устанавливает packages;
23. structural PASS невозможен без requirement-to-evidence matrix;
24. `READ_ONLY_AUDIT` не меняет отфильтрованный filesystem manifest;
25. interrupted/failed audit остаётся доступным для `/state` и `/resume`;
26. Ctrl+C не завершает interactive CLI traceback-ом;
27. русский язык и requested target сохраняются во всех follow-up ответах;
28. не происходит повторов уже зелёных gates или одинаковых install attempts;
29. captured runtime regressions от 2026-08-16/17 представлены автоматизированными
    тестами и проходят вместе с полным regression suite.

## 37. Итоговый pipeline

```text
USER
 ├─ CHAT
 │   ├─ bare shell? -> deterministic "not executed"
 │   └─ quick/context -> LM Studio
 └─ ENGINEERING
     ├─ Incident
     ├─ confirm requested target == workspace project
     │   └─ mismatch -> deterministic PATH_OUTSIDE_WORKSPACE blocker
     ├─ classify structural READ_ONLY_AUDIT?
     │   └─ spec -> root list -> targeted reads -> evidence matrix
     │       ├─ before/after manifest equal -> PASS/FAIL report
     │       └─ missing spec/evidence -> resumable BLOCKED/INCOMPLETE
     ├─ READ-ONLY BASELINE
     ├─ FailureDigest
     ├─ plan + IAP
     ├─ allow-listed dependency issue?
     │   └─ install -> pip check -> affected mypy
     │       ├─ green -> kernel Final
     │       └─ environment-only -> diagnose -> kernel BLOCKED
     ├─ retrieval top-K
     ├─ bounded root-first listing / targeted reads
     ├─ provider capability discovery + cache
     ├─ effective input budget + final fail-closed guard
     ├─ strict_schema_compiler_v46
     ├─ LM Studio structured action
     │   ├─ model-load failure -> circuit breaker -> explicit Yandex escalation
     │   └─ context overflow -> compaction -> same-provider retry once
     ├─ scoped mutation
     ├─ targeted verification
     ├─ full gates
     ├─ Safety / Review
     └─ evidence-backed Final
```
